#include "core/Trees.h"
#include <cstdio>
#include <chrono>
int main(){
  auto t0=std::chrono::steady_clock::now();
  TreeLib lib;
  printf("TreeLib: %.2fs\n", std::chrono::duration<double>(std::chrono::steady_clock::now()-t0).count());
  const char* nm[]={"big","apple","orange","banana","palm","palmc"};
  for(int sp=0;sp<SP_COUNT;sp++){
    for(int v=0;v<TREE_VARIANTS[sp];v++) printf("%s v%d: LOD0 %zu tris, LOD1 %zu tris\n",nm[sp],v,lib.get(sp,v).lod[0].size()/3,lib.get(sp,v).lod[1].size()/3);
    for(int l=0;l<2;l++){ char fn[64]; snprintf(fn,64,"/tmp/tree_%s_%d.bin",nm[sp],l); FILE* f=fopen(fn,"wb"); auto& vv=lib.get(sp,0).lod[l]; fwrite(vv.data(),sizeof(Vtx),vv.size(),f); fclose(f);} 
  }
}
