#include "core/World.h"
#include <cstdio>
int main(){
  World::init();
  printf("shore (%.1f, %.1f)  start (%.1f, %.1f)\n", RoadNet::shoreX, RoadNet::shoreZ, RoadNet::startX, RoadNet::startZ);
  printf("bridge (%.1f, %.1f) dir (%.3f, %.3f) deckY=%.2f\n", Bridge::x, Bridge::z, Bridge::dx, Bridge::dz, Bridge::deckY);
  printf("h(0,0)=%.1f  h(start)=%.2f  h(250,0)=%.2f depth(0,0)=%.1f\n", World::heightAt(0,0), World::heightAt(RoadNet::startX,RoadNet::startZ), World::heightAt(250,0), Base::depth(0,0));
  // mapa ascii
  for (int j=-24;j<=24;j++){ for(int i=-24;i<=24;i++){ float x=i*20.f,z=j*20.f; float d=Base::depth(x,z); float h=World::heightAt(x,z); char c = d<=0?'~': (h>150?'#': h>60?'^': h>20?'+': d<40?'.':'"'); putchar(c);} putchar('\n'); }
}
