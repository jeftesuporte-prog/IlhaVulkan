#include "core/TexGen.h"
#include <cstdio>
#include <chrono>
static void save(const char* n, const TexGen::Image& im){ FILE* f=fopen(n,"wb"); fprintf(f,"P6\n%d %d\n255\n",im.w,im.h); for(int i=0;i<im.w*im.h;i++) fwrite(&im.rgba[i*4],1,3,f); fclose(f);}
int main(){
  using namespace std::chrono; auto t0=steady_clock::now();
  auto lap=[&](const char* s){ auto t=steady_clock::now(); printf("%s %.2fs\n",s,duration<double>(t-t0).count()); t0=t; };
  save("/tmp/grass.ppm",TexGen::grass()); lap("grass");
  save("/tmp/rock.ppm",TexGen::rock(false)); lap("rock");
  save("/tmp/rockm.ppm",TexGen::rock(true)); lap("rockmoss");
  save("/tmp/sand.ppm",TexGen::sand()); lap("sand");
  save("/tmp/forest.ppm",TexGen::forest()); lap("forest");
  save("/tmp/water.ppm",TexGen::water()); lap("water");
  auto m=TexGen::mipChain(TexGen::grass()); printf("mips=%zu last=%dx%d\n",m.size(),m.back().w,m.back().h);
}
