#include "core/ChunkBuilder.h"
#include "core/Game.h"
#include <cstdio>
#include <chrono>
int main(){
  World::init();
  auto t0=std::chrono::steady_clock::now();
  size_t tv=0, trees=0; int cnt[SP_COUNT]={}; size_t decoV=0; double tT=0,tD=0; SolidMap sm;
  for(int cz=0;cz<10;cz++) for(int cx=0;cx<10;cx++){
    auto a=std::chrono::steady_clock::now();
    Built t=ChunkBuilder::terrain(cx,cz); auto b=std::chrono::steady_clock::now();
    Built d=ChunkBuilder::decor(cx,cz); auto c=std::chrono::steady_clock::now();
    tT+=std::chrono::duration<double>(b-a).count(); tD+=std::chrono::duration<double>(c-b).count();
    for(auto&p:t.parts) tv+=p.v.size(); for(auto&p:d.parts) decoV+=p.v.size();
    for(auto&tr:d.trees){cnt[tr.species]++;trees++;}
    sm.set(d.key,d.solids);
  }
  printf("terreno: %zu tris (%.2fs) | decor: %zu tris baked (%.2fs)\n",tv/3,tT,decoV/3,tD);
  const char* nm[]={"big","apple","orange","banana","palm","palmc"};
  for(int i=0;i<SP_COUNT;i++) printf("  %s: %d\n",nm[i],cnt[i]); printf("  total arvores: %zu\n",trees);
  // jogador anda do pier ate o centro
  Player pl; pl.place(RoadNet::startX,RoadNet::startZ,0); float dx=-RoadNet::dirX, dz=-RoadNet::dirZ;
  for(int i=0;i<4000;i++){ pl.move(dx,dz,0.016f,4.5f,sm); pl.physics(0.016f);} 
  printf("jogador apos 64s andando: (%.1f, %.1f, %.1f)\n",pl.pos.x,pl.pos.y,pl.pos.z);
  SkyState sky; for(int i=0;i<1000;i++) sky.update(0.1f,0.f); printf("hora %.2f meteoros %zu\n",sky.tod,sky.meteors.size());
  MeshAccum p=Props::pier(),b=Props::bridge(),pp=Props::player(); printf("pier %zu bridge %zu player %zu tris\n",p.v.size()/3,b.v.size()/3,pp.v.size()/3);
}
