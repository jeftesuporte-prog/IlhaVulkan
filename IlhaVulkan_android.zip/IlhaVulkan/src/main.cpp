// Ilha Gigante - C++ / Vulkan
// Controles: WASD andar | mouse olhar | Shift correr | Espaço pular | Esc solta o mouse (clique recaptura)
//            1..4 hora do dia (amanhecer, meio-dia, pôr do sol, noite) | T acelera o tempo | F11 tela cheia
#include <vulkan/vulkan.h>

#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <future>
#include <string>
#include <thread>

#include "core/ChunkBuilder.h"
#include "core/Game.h"
#include "core/TexGen.h"
#include "core/Trees.h"
#include "core/World.h"
#include "vk/ChunkManager.h"
#include "vk/Renderer.h"

#ifndef ILHA_SHADER_DIR
#define ILHA_SHADER_DIR "shaders"
#endif

struct Input {
    double lastX = 0, lastY = 0;
    bool haveLast = false;
    float yaw = 0.f, pitch = 0.45f;
    bool captured = false;
};

static std::string exeDir(const char* argv0) {
    std::string s(argv0 ? argv0 : "");
    size_t p = s.find_last_of("/\\");
    return p == std::string::npos ? "." : s.substr(0, p);
}

static void setCapture(GLFWwindow* w, Input* in, bool on) {
    in->captured = on;
    in->haveLast = false;
    glfwSetInputMode(w, GLFW_CURSOR, on ? GLFW_CURSOR_DISABLED : GLFW_CURSOR_NORMAL);
    if (on && glfwRawMouseMotionSupported()) glfwSetInputMode(w, GLFW_RAW_MOUSE_MOTION, GLFW_TRUE);
}

int main(int argc, char** argv) {
    (void)argc;
    if (!glfwInit()) { std::fprintf(stderr, "Falha ao iniciar GLFW\n"); return 1; }
    if (!glfwVulkanSupported()) { std::fprintf(stderr, "Vulkan não disponível neste sistema (instale o driver/loader).\n"); return 1; }
    glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);
    GLFWwindow* win = glfwCreateWindow(1600, 900, "Ilha Gigante - C++ / Vulkan", nullptr, nullptr);
    if (!win) { std::fprintf(stderr, "Falha ao criar janela\n"); return 1; }

    Renderer renderer;
    glfwSetWindowUserPointer(win, &renderer);
    glfwSetFramebufferSizeCallback(win, [](GLFWwindow* w, int, int) { static_cast<Renderer*>(glfwGetWindowUserPointer(w))->setFramebufferResized(); });

    // ---- mundo + texturas + árvores (em paralelo) ----
    auto t0 = std::chrono::steady_clock::now();
    World::init();
    auto fGrass = std::async(std::launch::async, [] { return TexGen::grass(); });
    auto fRock = std::async(std::launch::async, [] { return TexGen::rock(false); });
    auto fMoss = std::async(std::launch::async, [] { return TexGen::rock(true); });
    auto fSand = std::async(std::launch::async, [] { return TexGen::sand(); });
    auto fForest = std::async(std::launch::async, [] { return TexGen::forest(); });
    TreeLib trees;
    std::vector<TexGen::Image> terrainTex = {fSand.get(), fGrass.get(), fRock.get(), fMoss.get(), fForest.get()};
    TexGen::Image white;
    white.w = white.h = TexGen::S;
    white.rgba.assign((size_t)TexGen::S * TexGen::S * 4, 255);
    terrainTex.push_back(std::move(white));  // camada 5: "sem textura" (árvores, píer, ponte, boneco, flores)
    TexGen::Image waterImg = TexGen::water(), glitImg = TexGen::glitter();
    std::printf("Mundo/texturas/árvores: %.2fs\n", std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());

    std::string shaderDir = std::getenv("ILHA_SHADER_DIR") ? std::getenv("ILHA_SHADER_DIR") : ILHA_SHADER_DIR;
    if (!renderer.init(win, shaderDir)) return 1;
    renderer.uploadStatic(trees, terrainTex, waterImg, glitImg);

    SolidMap solids;
    int nth = std::clamp((int)std::thread::hardware_concurrency() - 1, 1, 6);
    ChunkManager chunks(renderer, solids, nth);
    Player player;
    player.place(RoadNet::startX, RoadNet::startZ, 0.f);
    chunks.warmup(player.pos.x, player.pos.z, 170.f);
    std::printf("Chunks iniciais prontos: %.2fs\n", std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());

    Input in;
    in.yaw = std::atan2(-0.6f, 0.8f);  // olhando para dentro da ilha
    setCapture(win, &in, true);
    SkyState sky;
    bool fullscreen = false;
    int wx = 0, wy = 0, ww = 0, wh = 0;

    double last = glfwGetTime(), titleT = 0.0;
    int frames = 0;
    float time = 0.f;
    bool prevKey[512] = {};

    while (!glfwWindowShouldClose(win)) {
        glfwPollEvents();
        int fbw = 0, fbh = 0;
        glfwGetFramebufferSize(win, &fbw, &fbh);
        while ((fbw == 0 || fbh == 0) && !glfwWindowShouldClose(win)) {  // minimizado: espera
            glfwWaitEvents();
            glfwGetFramebufferSize(win, &fbw, &fbh);
            last = glfwGetTime();
        }
        double now = glfwGetTime();
        float dt = std::min((float)(now - last), 0.05f);
        last = now;
        time += dt;

        auto pressed = [&](int key) { return glfwGetKey(win, key) == GLFW_PRESS; };
        auto edge = [&](int key) {
            bool p = pressed(key), r = p && !prevKey[key];
            prevKey[key] = p;
            return r;
        };

        // ---- mouse ----
        if (in.captured) {
            double mx, my;
            glfwGetCursorPos(win, &mx, &my);
            if (in.haveLast) {
                in.yaw += (float)(mx - in.lastX) * 0.0030f;
                in.pitch = clampf(in.pitch + (float)(my - in.lastY) * 0.0030f, -0.9f, 1.2f);
            }
            in.lastX = mx; in.lastY = my; in.haveLast = true;
        } else if (glfwGetMouseButton(win, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS) {
            setCapture(win, &in, true);
        }
        if (edge(GLFW_KEY_ESCAPE)) setCapture(win, &in, false);
        if (edge(GLFW_KEY_F11)) {
            fullscreen = !fullscreen;
            if (fullscreen) {
                glfwGetWindowPos(win, &wx, &wy);
                glfwGetWindowSize(win, &ww, &wh);
                GLFWmonitor* m = glfwGetPrimaryMonitor();
                const GLFWvidmode* vm = glfwGetVideoMode(m);
                glfwSetWindowMonitor(win, m, 0, 0, vm->width, vm->height, vm->refreshRate);
            } else {
                glfwSetWindowMonitor(win, nullptr, wx, wy, ww, wh, 0);
            }
        }
        if (edge(GLFW_KEY_1)) sky.tod = 6.2f;
        if (edge(GLFW_KEY_2)) sky.tod = 12.f;
        if (edge(GLFW_KEY_3)) sky.tod = 18.2f;
        if (edge(GLFW_KEY_4)) sky.tod = 23.f;

        // ---- movimento ----
        float fx = std::cos(in.yaw), fz = std::sin(in.yaw);
        float mvY = (pressed(GLFW_KEY_W) ? 1.f : 0.f) - (pressed(GLFW_KEY_S) ? 1.f : 0.f);
        float mvX = (pressed(GLFW_KEY_D) ? 1.f : 0.f) - (pressed(GLFW_KEY_A) ? 1.f : 0.f);
        float dx = fx * mvY - fz * mvX, dz = fz * mvY + fx * mvX;
        float dl = std::sqrt(dx * dx + dz * dz);
        if (dl > 0.01f) {
            float speed = pressed(GLFW_KEY_LEFT_SHIFT) ? 8.f : 4.2f;
            player.move(dx / dl, dz / dl, dt, speed, solids);
        }
        if (pressed(GLFW_KEY_SPACE)) player.jump();
        player.physics(dt);

        sky.update(dt * (pressed(GLFW_KEY_T) ? 40.f : 1.f), in.yaw);
        chunks.update(player.pos.x, player.pos.z);

        // ---- câmera em 3ª pessoa ----
        Vec3 target(player.pos.x, player.pos.y + 1.4f, player.pos.z);
        const float dist = 5.5f;
        float cp = std::cos(in.pitch), sp = std::sin(in.pitch);
        Vec3 cam(target.x - fx * cp * dist, target.y + sp * dist, target.z - fz * cp * dist);
        cam.y = std::max(cam.y, std::max(World::heightAt(cam.x, cam.z), 0.f) + 0.6f);

        FrameParams fp;
        fp.view = Mat4::lookAt(cam, target, Vec3(0, 1, 0));
        fp.proj = Mat4::perspective(67.f * PI_F / 180.f, renderer.aspect(), 0.4f, 1000.f);
        fp.camPos = cam;
        fp.playerPos = player.pos;
        fp.playerHeadingDeg = player.heading;
        fp.time = time;
        fp.sky = &sky;
        if (!renderer.drawFrame(fp)) break;

        frames++;
        titleT += dt;
        if (titleT >= 0.5) {
            int hh = (int)sky.tod, mm = (int)((sky.tod - hh) * 60.f);
            char buf[200];
            std::snprintf(buf, sizeof(buf), "Ilha Gigante | %.0f FPS | %02d:%02d | alt %.0f m | chunks %d+%d | árvores %d | MSAA %dx", frames / titleT, hh, mm,
                          player.pos.y, renderer.stats().terrainChunks, renderer.stats().decoChunks, renderer.stats().drawnTreeInstances,
                          renderer.msaaSamples());
            glfwSetWindowTitle(win, buf);
            frames = 0;
            titleT = 0.0;
        }
    }

    renderer.waitIdle();
    renderer.shutdown();
    glfwDestroyWindow(win);
    glfwTerminate();
    return 0;
}
