#include "TexGen.h"

#include <cmath>

#include "JavaRandom.h"
#include "Math.h"

namespace TexGen {

static constexpr int K = S / 256;  // fator de escala dos detalhes em relação à receita original (256 px)

// ---------------- ruído periódico (tileável) ----------------
static float hash(int i, int j, int seed) {
    uint32_t h = (uint32_t)i * 374761393u + (uint32_t)j * 668265263u + (uint32_t)seed * 362437u;
    h = (h ^ (h >> 13)) * 1274126177u;
    h = h ^ (h >> 16);
    return (h & 0xFFFFu) / 65535.f;
}

static int wrapi(int a, int per) { return ((a % per) + per) % per; }

static float vnoise(float u, float v, int perX, int perY, int seed) {
    float x = u * perX;
    float y = v * perY;
    int xi = (int)std::floor(x);
    int yi = (int)std::floor(y);
    float fx = x - xi;
    float fy = y - yi;
    float sx = fx * fx * (3.f - 2.f * fx);
    float sy = fy * fy * (3.f - 2.f * fy);
    int x0 = wrapi(xi, perX), x1 = wrapi(xi + 1, perX);
    int y0 = wrapi(yi, perY), y1 = wrapi(yi + 1, perY);
    float a = hash(x0, y0, seed), b = hash(x1, y0, seed), c = hash(x0, y1, seed), d = hash(x1, y1, seed);
    float top = a + (b - a) * sx;
    float bot = c + (d - c) * sx;
    return top + (bot - top) * sy;
}

static float fbm(float u, float v, int per, int oct, int seed) {
    float amp = 0.5f, sum = 0.f, norm = 0.f;
    int p = per;
    for (int o = 0; o < oct; o++) {
        sum += vnoise(u, v, p, p, seed + o * 17) * amp;
        norm += amp;
        amp *= 0.5f;
        p *= 2;
    }
    return sum / norm;
}

static float sstep(float e0, float e1, float x) { return smooth(e0, e1, x); }

// ---------------- "tela" de pixels ----------------
struct Canvas {
    std::vector<float> r, g, b;
    Canvas() : r(S * S), g(S * S), b(S * S) {}
    void set(int x, int y, float cr, float cg, float cb) {
        int i = (y & (S - 1)) * S + (x & (S - 1));
        r[i] = cr; g[i] = cg; b[i] = cb;
    }
    void blend(int x, int y, float cr, float cg, float cb, float a) {
        int i = (y & (S - 1)) * S + (x & (S - 1));
        r[i] += (cr - r[i]) * a;
        g[i] += (cg - g[i]) * a;
        b[i] += (cb - b[i]) * a;
    }
    void ellipse(float cx, float cy, float len, float wid, float ang, float cr, float cg, float cb, float a) {
        float ca = std::cos(ang), sa = std::sin(ang);
        int m = (int)std::ceil(std::max(len, wid)) + 1;
        for (int dy = -m; dy <= m; dy++)
            for (int dx = -m; dx <= m; dx++) {
                float xr = dx * ca + dy * sa;
                float yr = -dx * sa + dy * ca;
                float e = (xr * xr) / (len * len) + (yr * yr) / (wid * wid);
                if (e <= 1.f) blend((int)cx + dx, (int)cy + dy, cr, cg, cb, a);
            }
    }
    Image toImage() const {
        Image im;
        im.w = im.h = S;
        im.rgba.resize((size_t)S * S * 4);
        for (int i = 0; i < S * S; i++) {
            im.rgba[i * 4 + 0] = (uint8_t)std::lround(clampf(r[i], 0.f, 1.f) * 255.f);
            im.rgba[i * 4 + 1] = (uint8_t)std::lround(clampf(g[i], 0.f, 1.f) * 255.f);
            im.rgba[i * 4 + 2] = (uint8_t)std::lround(clampf(b[i], 0.f, 1.f) * 255.f);
            im.rgba[i * 4 + 3] = 255;
        }
        return im;
    }
};

// =====================================================================
//  GRAMA  #5DBB35
// =====================================================================
Image grass() {
    Canvas c;
    JRandom rnd(11);
    for (int y = 0; y < S; y++)
        for (int x = 0; x < S; x++) {
            float u = (x + 0.5f) / S, v = (y + 0.5f) / S;
            float big = sstep(0.28f, 0.72f, fbm(u, v, 3, 4, 1));
            float mid = fbm(u, v, 12, 3, 2);
            float cr, cg, cb;
            if (big < 0.5f) {
                float t = big * 2.f;
                cr = lerpf(0.26f, 0.365f, t); cg = lerpf(0.63f, 0.733f, t); cb = lerpf(0.16f, 0.208f, t);
            } else {
                float t = (big - 0.5f) * 2.f;
                cr = lerpf(0.365f, 0.49f, t); cg = lerpf(0.733f, 0.86f, t); cb = lerpf(0.208f, 0.29f, t);
            }
            float k = 0.9f + 0.2f * mid + (hash(x, y, 5) - 0.5f) * 0.10f;
            c.set(x, y, cr * k, cg * k, cb * k);
        }
    // pelinhos de grama (riscos curtos, claros e escuros)
    for (int n = 0; n < 3200 * K * K; n++) {
        int x0 = rnd.nextInt(S), y0 = rnd.nextInt(S);
        int len = (4 + rnd.nextInt(7)) * K;
        float lean = (rnd.nextFloat() - 0.5f) * 0.7f;
        bool dark = rnd.nextFloat() < 0.45f;
        for (int k = 0; k < len; k++) {
            float a = 0.9f - (k / (float)K) * 0.07f;
            int px = x0 + (int)(lean * k), py = y0 + k;
            for (int w = 0; w < K; w++) {
                if (dark) c.blend(px + w, py, 0.17f, 0.50f, 0.11f, a);
                else c.blend(px + w, py, 0.58f, 0.92f, 0.33f, a);
            }
        }
    }
    // florzinhas minúsculas (branca, amarela, rosa)
    const float fl[3][3] = {{1.f, 1.f, 0.95f}, {1.f, 0.88f, 0.2f}, {1.f, 0.55f, 0.75f}};
    for (int i = 0; i < 9 * K * K; i++) {
        int x = rnd.nextInt(S), y = rnd.nextInt(S);
        const float* f = fl[i % 3];
        c.ellipse((float)x, (float)y, 1.7f * K, 1.7f * K, 0.f, f[0], f[1], f[2], 0.85f);
        c.ellipse((float)x, (float)y, 0.8f * K, 0.8f * K, 0.f, 1.f, 0.8f, 0.1f, 1.f);
    }
    // pedrinhas
    for (int i = 0; i < 6 * K * K; i++) {
        float x = (float)rnd.nextInt(S), y = (float)rnd.nextInt(S);
        c.ellipse(x + K, y + K, 3.2f * K, 2.2f * K, 0.f, 0.20f, 0.35f, 0.12f, 0.6f);
        c.ellipse(x, y, 3.f * K, 2.f * K, rnd.nextFloat() * 3.f, 0.62f, 0.62f, 0.60f, 1.f);
        c.ellipse(x - 0.7f * K, y - 0.6f * K, 1.4f * K, 0.9f * K, 0.f, 0.82f, 0.82f, 0.80f, 0.9f);
    }
    return c.toImage();
}

// =====================================================================
//  PEDRA  #5A5A5A (moss=true: com musgo #4A7C2E)
// =====================================================================
Image rock(bool moss) {
    Canvas c;
    JRandom rnd(moss ? 33 : 21);
    for (int y = 0; y < S; y++)
        for (int x = 0; x < S; x++) {
            float u = (x + 0.5f) / S, v = (y + 0.5f) / S;
            float big = fbm(u, v, 4, 5, 21);
            float strata = vnoise(u, v, 3, 22, 23);
            float gr = 0.30f + 0.26f * big + 0.12f * (strata - 0.5f);
            gr += (hash(x, y, 9) - 0.5f) * 0.09f;
            float cr = gr * 1.03f, cg = gr, cb = gr * 0.96f;
            float dp = sstep(0.56f, 0.74f, fbm(u, v, 5, 3, 44));
            cr = lerpf(cr, 0.47f * (0.8f + big * 0.4f), dp * 0.65f);
            cg = lerpf(cg, 0.34f * (0.8f + big * 0.4f), dp * 0.65f);
            cb = lerpf(cb, 0.21f * (0.8f + big * 0.4f), dp * 0.65f);
            float mp = moss ? sstep(0.40f, 0.58f, fbm(u, v, 6, 4, 55)) : sstep(0.70f, 0.80f, fbm(u, v, 6, 4, 55)) * 0.7f;
            float mk = 0.85f + 0.3f * fbm(u, v, 20, 2, 56);
            cr = lerpf(cr, 0.29f * mk, mp * 0.92f);
            cg = lerpf(cg, 0.49f * mk, mp * 0.92f);
            cb = lerpf(cb, 0.18f * mk, mp * 0.92f);
            float ridge = std::fabs(fbm(u, v, 5, 4, 33) - 0.5f) * 2.f;
            float crack = 1.f - sstep(0.f, 0.045f, ridge);
            float ridge2 = std::fabs(fbm(u, v, 9, 3, 34) - 0.5f) * 2.f;
            float crack2 = 1.f - sstep(0.f, 0.03f, ridge2);
            float dk = 1.f - 0.6f * std::max(crack, crack2 * 0.7f);
            c.set(x, y, cr * dk, cg * dk, cb * dk);
        }
    for (int n = 0; n < 120 * K * K; n++) {
        int x0 = rnd.nextInt(S), y0 = rnd.nextInt(S);
        int len = (6 + rnd.nextInt(16)) * K;
        float dx = rnd.nextFloat() * 2.f - 1.f, dy = rnd.nextFloat() * 2.f - 1.f;
        float l = std::max(0.01f, std::sqrt(dx * dx + dy * dy));
        bool light = rnd.nextFloat() < 0.3f;
        for (int k = 0; k < len; k++) {
            int px = x0 + (int)(dx / l * k), py = y0 + (int)(dy / l * k);
            if (light) c.blend(px, py, 0.7f, 0.7f, 0.68f, 0.35f);
            else c.blend(px, py, 0.1f, 0.1f, 0.1f, 0.45f);
        }
    }
    return c.toImage();
}

// =====================================================================
//  AREIA  #F5DEB3
// =====================================================================
Image sand() {
    Canvas c;
    JRandom rnd(5);
    for (int y = 0; y < S; y++)
        for (int x = 0; x < S; x++) {
            float u = (x + 0.5f) / S, v = (y + 0.5f) / S;
            float mott = 0.94f + 0.10f * fbm(u, v, 6, 3, 61);
            float grain = (hash(x, y, 7) - 0.5f) * 0.07f;
            float wv = std::sin((v * 8.f + 1.8f * (fbm(u, v, 3, 3, 62) - 0.5f)) * 6.2831855f);
            float ripple = 0.035f * wv;
            float k = mott + grain + ripple;
            c.set(x, y, 0.96f * k, 0.87f * k, 0.70f * k);
        }
    for (int n = 0; n < 160 * K * K; n++) {  // brilhinhos (quartzo)
        int x = rnd.nextInt(S), y = rnd.nextInt(S);
        for (int a = 0; a < K; a++)
            for (int b = 0; b < K; b++) c.blend(x + a, y + b, 1.f, 1.f, 0.93f, 0.95f);
    }
    for (int n = 0; n < 70 * K * K; n++) {  // grãos escuros / pedacinhos de concha
        int x = rnd.nextInt(S), y = rnd.nextInt(S);
        for (int a = 0; a < K; a++)
            for (int b = 0; b < K; b++) c.blend(x + a, y + b, 0.74f, 0.62f, 0.45f, 0.7f);
    }
    for (int n = 0; n < 5 * K * K; n++) {
        float x = (float)rnd.nextInt(S), y = (float)rnd.nextInt(S);
        c.ellipse(x, y, 2.5f * K, 1.6f * K, rnd.nextFloat() * 3.f, 0.98f, 0.93f, 0.86f, 0.95f);
    }
    return c.toImage();
}

// =====================================================================
//  CHÃO DA FLORESTA  #8B5A2B
// =====================================================================
Image forest() {
    Canvas c;
    JRandom rnd(77);
    for (int y = 0; y < S; y++)
        for (int x = 0; x < S; x++) {
            float u = (x + 0.5f) / S, v = (y + 0.5f) / S;
            float big = fbm(u, v, 4, 5, 71);
            float damp = sstep(0.42f, 0.70f, fbm(u, v, 5, 3, 72));
            float cr = lerpf(0.54f, 0.40f, big);
            float cg = lerpf(0.36f, 0.27f, big);
            float cb = lerpf(0.18f, 0.14f, big);
            float dk = 1.f - 0.38f * damp;
            float gr = (hash(x, y, 13) - 0.5f) * 0.10f;
            c.set(x, y, cr * dk + gr, cg * dk + gr * 0.8f, cb * dk + gr * 0.5f);
        }
    for (int n = 0; n < 9; n++) {  // raízes aparecendo
        float px = rnd.nextFloat() * S, py = rnd.nextFloat() * S;
        float ang = rnd.nextFloat() * 6.2831855f;
        int steps = (60 + rnd.nextInt(60)) * K;
        float th = (1.2f + rnd.nextFloat() * 1.2f) * K;
        for (int k = 0; k < steps; k++) {
            ang += (rnd.nextFloat() - 0.5f) * 0.45f / std::sqrt((float)K);
            px += std::cos(ang) * 1.1f;
            py += std::sin(ang) * 1.1f;
            c.ellipse(px, py, th, th, 0.f, 0.25f, 0.15f, 0.07f, 0.95f);
            c.ellipse(px - 0.9f * K, py - 0.9f * K, th * 0.5f, th * 0.5f, 0.f, 0.46f, 0.31f, 0.16f, 0.55f);
        }
    }
    const float leaf[5][3] = {{0.71f, 0.40f, 0.11f}, {0.63f, 0.32f, 0.16f}, {0.78f, 0.56f, 0.23f}, {0.55f, 0.41f, 0.08f}, {0.36f, 0.22f, 0.10f}};
    for (int n = 0; n < 260 * K * K; n++) {  // folhas secas caídas
        const float* f = leaf[rnd.nextInt(5)];
        float sh = 0.85f + rnd.nextFloat() * 0.3f;
        float a = rnd.nextFloat() * 3.1416f;
        float cx = (float)rnd.nextInt(S), cy = (float)rnd.nextInt(S);
        float len = (3.5f + rnd.nextFloat() * 3.5f) * K;
        c.ellipse(cx, cy, len, len * 0.45f, a, f[0] * sh, f[1] * sh, f[2] * sh, 0.95f);
        c.ellipse(cx, cy, len * 0.9f, 0.6f * K, a, f[0] * sh * 0.6f, f[1] * sh * 0.6f, f[2] * sh * 0.6f, 0.7f);
    }
    for (int n = 0; n < 40 * K * K; n++) {
        c.ellipse((float)rnd.nextInt(S), (float)rnd.nextInt(S), 2.2f * K, 1.6f * K, rnd.nextFloat() * 3.f, 0.26f, 0.42f, 0.14f, 0.85f);
    }
    return c.toImage();
}

// =====================================================================
//  ÁGUA (256x256) - mesma receita do Water.kt
// =====================================================================
struct RGBA {
    int w, h;
    std::vector<float> p;
    RGBA(int W, int H) : w(W), h(H), p((size_t)W * H * 4, 0.f) {}
    void blend(int x, int y, float r, float g, float b, float a) {
        if (x < 0 || y < 0 || x >= w || y >= h) return;
        float* q = &p[((size_t)y * w + x) * 4];
        q[0] = r * a + q[0] * (1.f - a);
        q[1] = g * a + q[1] * (1.f - a);
        q[2] = b * a + q[2] * (1.f - a);
        q[3] = a + q[3] * (1.f - a);
    }
    void fillCircle(int cx, int cy, int rad, float r, float g, float b, float a) {
        for (int dy = -rad; dy <= rad; dy++)
            for (int dx = -rad; dx <= rad; dx++)
                if (dx * dx + dy * dy <= rad * rad) blend(cx + dx, cy + dy, r, g, b, a);
    }
    Image toImage() const {
        Image im;
        im.w = w; im.h = h;
        im.rgba.resize((size_t)w * h * 4);
        for (size_t i = 0; i < (size_t)w * h * 4; i++) im.rgba[i] = (uint8_t)std::lround(clampf(p[i], 0.f, 1.f) * 255.f);
        return im;
    }
};

Image water() {
    RGBA pm(256, 256);
    for (int y = 0; y < 256; y++)
        for (int x = 0; x < 256; x++) {
            float* q = &pm.p[((size_t)y * 256 + x) * 4];
            q[0] = 0.f; q[1] = 191.f / 255.f; q[2] = 1.f; q[3] = 1.f;  // #00BFFF
        }
    JRandom rnd(7);
    for (int n = 0; n < 70; n++) {  // manchas claras/escuras suaves
        int x = rnd.nextInt(256), y = rnd.nextInt(256);
        int r = 6 + rnd.nextInt(14);
        float gg = 0.62f + rnd.nextFloat() * 0.2f;
        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++) pm.fillCircle(x + dx * 256, y + dy * 256, r, 0.f, gg, 1.f, 0.3f);
    }
    for (int n = 0; n < 80; n++) {  // riscos de onda brancos
        int x0 = rnd.nextInt(256), y0 = rnd.nextInt(256);
        int len = 10 + rnd.nextInt(20);
        for (int k = 0; k <= len; k++) {
            int x = (x0 + k) & 255;
            int y = (y0 + (int)(std::sin(k * 0.4f) * 2.f)) & 255;
            pm.blend(x, y, 1.f, 1.f, 1.f, 0.6f);
            pm.blend(x, (y + 1) & 255, 1.f, 1.f, 1.f, 0.6f);
        }
    }
    for (int n = 0; n < 170; n++) {  // brilhinhos do sol na água
        int x = rnd.nextInt(256), y = rnd.nextInt(256);
        for (int a = 0; a < 2; a++)
            for (int b = 0; b < 2; b++) pm.blend(x + a, y + b, 1.f, 1.f, 1.f, 0.85f);
        pm.blend((x + 2) & 255, y, 0.8f, 1.f, 1.f, 0.4f);
        pm.blend((x - 1) & 255, y, 0.8f, 1.f, 1.f, 0.4f);
    }
    return pm.toImage();
}

// =====================================================================
//  BRILHO DO SOL/LUA NA ÁGUA (64x256) - mesma receita do Sky.kt
// =====================================================================
Image glitter() {
    JRandom rnd(42);
    const int W = 64, H = 256, rows = 128;
    std::vector<float> rowB(rows), rowW(rows);
    for (int i = 0; i < rows; i++) rowB[i] = 0.2f + rnd.nextFloat() * 0.8f;
    for (int i = 0; i < rows; i++) rowW[i] = 0.35f + rnd.nextFloat() * 0.65f;
    Image im;
    im.w = W; im.h = H;
    im.rgba.assign((size_t)W * H * 4, 255);
    for (int y = 0; y < H; y++) {
        float far = y / 255.f;
        float fadeIn = smooth(0.f, 0.08f, far);
        float fadeOut = 1.f - smooth(0.7f, 1.f, far);
        float half = (0.16f + 0.5f * far) * rowW[y / 2];
        for (int x = 0; x < W; x++) {
            float d = std::fabs(x - 31.5f) / 32.f;
            float a = clampf(1.f - d / half, 0.f, 1.f);
            a = a * a * rowB[y / 2];
            a *= 0.55f + 0.45f * rnd.nextFloat();
            a *= fadeIn * fadeOut;
            im.rgba[((size_t)y * W + x) * 4 + 3] = (uint8_t)std::lround(clampf(a, 0.f, 1.f) * 255.f);
        }
    }
    return im;
}

std::vector<Image> mipChain(const Image& base) {
    std::vector<Image> out;
    out.push_back(base);
    while (out.back().w > 1 || out.back().h > 1) {
        const Image& s = out.back();
        Image d;
        d.w = std::max(1, s.w / 2);
        d.h = std::max(1, s.h / 2);
        d.rgba.resize((size_t)d.w * d.h * 4);
        for (int y = 0; y < d.h; y++)
            for (int x = 0; x < d.w; x++)
                for (int ch = 0; ch < 4; ch++) {
                    int x0 = std::min(x * 2, s.w - 1), x1 = std::min(x * 2 + 1, s.w - 1);
                    int y0 = std::min(y * 2, s.h - 1), y1 = std::min(y * 2 + 1, s.h - 1);
                    int sum = s.rgba[((size_t)y0 * s.w + x0) * 4 + ch] + s.rgba[((size_t)y0 * s.w + x1) * 4 + ch] +
                              s.rgba[((size_t)y1 * s.w + x0) * 4 + ch] + s.rgba[((size_t)y1 * s.w + x1) * 4 + ch];
                    d.rgba[((size_t)y * d.w + x) * 4 + ch] = (uint8_t)((sum + 2) / 4);
                }
        out.push_back(std::move(d));
    }
    return out;
}
}  // namespace TexGen
