// Constrói os dados de um chunk (100 x 100 m). Roda em threads de fundo (só funções puras).
#pragma once
#include <vector>
#include "MeshAccum.h"
#include "Trees.h"

enum ChunkMat { M_SAND = 0, M_GRASS, M_ROCK, M_ROCKMOSS, M_FOREST, M_DECO, M_DECOROCK, M_COUNT };

struct BuiltPart {
    int mat;
    std::vector<Vtx> v;
};

struct BuiltTree {
    uint8_t species, variant;
    TreeInst inst;
};

struct Built {
    int layer = 0;  // 0 = terreno, 1 = vegetação/pedras/flores
    int key = 0;
    std::vector<BuiltPart> parts;
    std::vector<BuiltTree> trees;
    float minY = 0, maxY = 0;
    std::vector<float> solids;  // círculos de colisão: x, z, raio
};

namespace ChunkBuilder {
Built terrain(int cx, int cz);
Built decor(int cx, int cz);
}  // namespace ChunkBuilder
