// As MESMAS árvores do app (floresta, bananeira, macieira, laranjeira, coqueiro reto e torto), agora muito mais detalhadas,
// seguindo as imagens de referência (low-poly facetado, folhas em losango dobradas, frutas redondas).
// Cada espécie tem várias variantes e 2 níveis de detalhe (LOD0 = perto/detalhado, LOD1 = longe/leve).
// O jogo desenha as árvores por INSTANCIAMENTO: 1 malha por variante, milhares de cópias.
#pragma once
#include <vector>
#include "MeshAccum.h"

enum Species { SP_BIG = 0, SP_APPLE, SP_ORANGE, SP_BANANA, SP_PALM, SP_PALMC, SP_COUNT };

constexpr int TREE_VARIANTS[SP_COUNT] = {6, 4, 4, 4, 5, 3};
/** altura (m) com que cada variante é modelada; a instância escala por hh / nominal */
constexpr float TREE_NOMINAL_H[SP_COUNT] = {8.f, 6.f, 5.5f, 5.2f, 10.f, 8.5f};

struct TreeInst {
    float x, y, z, scale, rot, tint, pad0, pad1;  // 32 bytes (vai direto para o buffer de instâncias)
};
static_assert(sizeof(TreeInst) == 32, "TreeInst deve ter 32 bytes");

/** Constrói uma árvore na origem (base em y=0). lod: 0 detalhado, 1 leve. */
void buildTree(MeshAccum& acc, int species, int variant, int lod);

struct TreeMesh {
    std::vector<Vtx> lod[2];
};

class TreeLib {
public:
    TreeLib();
    const TreeMesh& get(int species, int variant) const { return meshes_[species][variant]; }

private:
    std::vector<TreeMesh> meshes_[SP_COUNT];
};
