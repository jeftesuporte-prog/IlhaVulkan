// Simplex 2D idêntico ao SimplexNoise.java do app original (mesma permutação, mesma seed).
#pragma once
#include <cmath>
#include "JavaRandom.h"

class SimplexNoise {
    int perm_[512];
    static int fastFloor(double x) { int xi = (int)x; return x < xi ? xi - 1 : xi; }

public:
    explicit SimplexNoise(int64_t seed) {
        int p[256];
        for (int i = 0; i < 256; i++) p[i] = i;
        JRandom r(seed);
        for (int i = 255; i > 0; i--) {
            int j = r.nextInt(i + 1);
            int t = p[i]; p[i] = p[j]; p[j] = t;
        }
        for (int i = 0; i < 512; i++) perm_[i] = p[i & 255];
    }
    float noise(double xin, double yin) const {
        static const int G[8][2] = {{1, 1}, {-1, 1}, {1, -1}, {-1, -1}, {1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        const double F2 = 0.5 * (std::sqrt(3.0) - 1.0);
        const double G2 = (3.0 - std::sqrt(3.0)) / 6.0;
        double n0, n1, n2;
        double s = (xin + yin) * F2;
        int i = fastFloor(xin + s);
        int j = fastFloor(yin + s);
        double t = (i + j) * G2;
        double x0 = xin - (i - t);
        double y0 = yin - (j - t);
        int i1, j1;
        if (x0 > y0) { i1 = 1; j1 = 0; } else { i1 = 0; j1 = 1; }
        double x1 = x0 - i1 + G2;
        double y1 = y0 - j1 + G2;
        double x2 = x0 - 1.0 + 2.0 * G2;
        double y2 = y0 - 1.0 + 2.0 * G2;
        int ii = i & 255;
        int jj = j & 255;
        int gi0 = perm_[ii + perm_[jj]] & 7;
        int gi1 = perm_[ii + i1 + perm_[jj + j1]] & 7;
        int gi2 = perm_[ii + 1 + perm_[jj + 1]] & 7;
        double t0 = 0.5 - x0 * x0 - y0 * y0;
        if (t0 < 0) n0 = 0.0; else { t0 *= t0; n0 = t0 * t0 * (G[gi0][0] * x0 + G[gi0][1] * y0); }
        double t1 = 0.5 - x1 * x1 - y1 * y1;
        if (t1 < 0) n1 = 0.0; else { t1 *= t1; n1 = t1 * t1 * (G[gi1][0] * x1 + G[gi1][1] * y1); }
        double t2 = 0.5 - x2 * x2 - y2 * y2;
        if (t2 < 0) n2 = 0.0; else { t2 *= t2; n2 = t2 * t2 * (G[gi2][0] * x2 + G[gi2][1] * y2); }
        return (float)(70.0 * (n0 + n1 + n2));
    }
};
