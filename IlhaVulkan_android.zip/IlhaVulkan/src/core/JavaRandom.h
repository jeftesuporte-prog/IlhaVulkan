// java.util.Random reproduzido bit a bit: a ilha e a posição das árvores saem IGUAIS às do app original (Kotlin).
#pragma once
#include <cstdint>

class JRandom {
    uint64_t seed_;
    static constexpr uint64_t MASK = (1ULL << 48) - 1;
    int32_t next(int bits) {
        seed_ = (seed_ * 0x5DEECE66DULL + 0xBULL) & MASK;
        return (int32_t)(uint32_t)(seed_ >> (48 - bits));
    }

public:
    explicit JRandom(int64_t seed) : seed_(((uint64_t)seed ^ 0x5DEECE66DULL) & MASK) {}
    int32_t nextInt() { return next(32); }
    int32_t nextInt(int32_t bound) {
        int32_t r = next(31);
        int32_t m = bound - 1;
        if ((bound & m) == 0) {
            r = (int32_t)(((int64_t)bound * (int64_t)r) >> 31);
        } else {
            for (int32_t u = r; (int32_t)((uint32_t)u - (uint32_t)(r = u % bound) + (uint32_t)m) < 0; u = next(31)) {}
        }
        return r;
    }
    int64_t nextLong() {
        int64_t hi = (int64_t)next(32);
        int64_t lo = (int64_t)next(32);
        return (int64_t)(((uint64_t)hi << 32) + (uint64_t)lo);
    }
    float nextFloat() { return next(24) / (float)(1 << 24); }
};
