#include "Prims.h"

#include <array>
#include <map>

namespace {
struct Ico {
    std::vector<Vec3> v;
    std::vector<std::array<int, 3>> f;
};

Ico buildIco(int level) {
    Ico ico;
    float t = (1.f + std::sqrt(5.f)) / 2.f;
    const float raw[36] = {-1, t, 0, 1, t, 0, -1, -t, 0, 1, -t, 0, 0, -1, t, 0, 1, t, 0, -1, -t, 0, 1, -t, t, 0, -1, t, 0, 1, -t, 0, -1, -t, 0, 1};
    for (int i = 0; i < 12; i++) ico.v.push_back(Vec3(raw[i * 3], raw[i * 3 + 1], raw[i * 3 + 2]).nor());
    const int F[60] = {0, 11, 5, 0, 5, 1, 0, 1, 7, 0, 7, 10, 0, 10, 11, 1, 5, 9, 5, 11, 4, 11, 10, 2, 10, 7, 6, 7, 1, 8,
                       3, 9, 4, 3, 4, 2, 3, 2, 6, 3, 6, 8, 3, 8, 9, 4, 9, 5, 2, 4, 11, 6, 2, 10, 8, 6, 7, 9, 8, 1};
    for (int i = 0; i < 20; i++) ico.f.push_back({F[i * 3], F[i * 3 + 1], F[i * 3 + 2]});
    for (int l = 0; l < level; l++) {
        std::map<std::pair<int, int>, int> mid;
        auto midpoint = [&](int a, int b) {
            auto key = std::make_pair(std::min(a, b), std::max(a, b));
            auto it = mid.find(key);
            if (it != mid.end()) return it->second;
            ico.v.push_back(((ico.v[a] + ico.v[b]) * 0.5f).nor());
            int idx = (int)ico.v.size() - 1;
            mid[key] = idx;
            return idx;
        };
        std::vector<std::array<int, 3>> nf;
        for (auto& f : ico.f) {
            int ab = midpoint(f[0], f[1]), bc = midpoint(f[1], f[2]), ca = midpoint(f[2], f[0]);
            nf.push_back({f[0], ab, ca});
            nf.push_back({f[1], bc, ab});
            nf.push_back({f[2], ca, bc});
            nf.push_back({ab, bc, ca});
        }
        ico.f = nf;
    }
    return ico;
}

const std::array<Ico, 3>& icos() {
    static const std::array<Ico, 3> a = {buildIco(0), buildIco(1), buildIco(2)};
    return a;
}
}  // namespace

void blob(MeshAccum& acc, JRandom& rng, Vec3 c, Vec3 r, const Col& col, float jit, int level, float faceVar, bool uv) {
    const Ico& I = icos()[std::min(2, std::max(0, level))];
    std::vector<Vec3> P(I.v.size());
    for (size_t i = 0; i < I.v.size(); i++) {
        float j = 1.f + (rng.nextFloat() - 0.5f) * jit;
        P[i] = Vec3(c.x + I.v[i].x * r.x * j, c.y + I.v[i].y * r.y * j, c.z + I.v[i].z * r.z * j);
    }
    for (auto& f : I.f) {
        Col fc = col;
        if (faceVar > 0.f) {
            float k = 1.f + (rng.nextFloat() - 0.5f) * faceVar;
            fc = {col.r * k, col.g * k, col.b * k};
        }
        acc.triOut(P[f[0]], P[f[1]], P[f[2]], c, fc, uv);
    }
}

void prism(MeshAccum& acc, Vec3 p0, float r0, Vec3 p1, float r1, int sides, const Col& col) {
    float da = TAU_F / sides;
    Vec3 m = (p0 + p1) * 0.5f;
    for (int k = 0; k < sides; k++) {
        float a0 = k * da, a1 = (k + 1) * da;
        Vec3 b0(p0.x + std::cos(a0) * r0, p0.y, p0.z + std::sin(a0) * r0);
        Vec3 b1(p0.x + std::cos(a1) * r0, p0.y, p0.z + std::sin(a1) * r0);
        Vec3 t0(p1.x + std::cos(a0) * r1, p1.y, p1.z + std::sin(a0) * r1);
        Vec3 t1(p1.x + std::cos(a1) * r1, p1.y, p1.z + std::sin(a1) * r1);
        acc.triOut(b0, b1, t1, m, col);
        acc.triOut(b0, t1, t0, m, col);
    }
}

void spotOn(MeshAccum& acc, Vec3 c, Vec3 n, float dist, float size, const Col& col) {
    float l = std::max(std::sqrt(n.x * n.x + n.z * n.z), 1e-4f);
    bool flat = std::fabs(n.y) > 0.95f;
    float t1x = flat ? 1.f : n.z / l;
    float t1z = flat ? 0.f : -n.x / l;
    float t2x = n.y * t1z;
    float t2y = n.z * t1x - n.x * t1z;
    float t2z = -n.y * t1x;
    Vec3 p = c + n * dist;
    float w = size, h = size * 1.25f;
    Vec3 a(p.x + t1x * w, p.y, p.z + t1z * w);
    Vec3 b(p.x + t2x * h, p.y + t2y * h, p.z + t2z * h);
    Vec3 cc(p.x - t1x * w, p.y, p.z - t1z * w);
    Vec3 d(p.x - t2x * h, p.y - t2y * h, p.z - t2z * h);
    acc.triOut(a, b, cc, c, col);
    acc.triOut(a, cc, d, c, col);
}

void octa(MeshAccum& acc, Vec3 c, float r, const Col& col) {
    const float rx[4] = {r, 0.f, -r, 0.f};
    const float rz[4] = {0.f, r, 0.f, -r};
    for (int k = 0; k < 4; k++) {
        int a = k, b = (k + 1) % 4;
        Vec3 A(c.x + rx[a], c.y, c.z + rz[a]), B(c.x + rx[b], c.y, c.z + rz[b]);
        acc.triOut(A, B, Vec3(c.x, c.y + r * 0.8f, c.z), c, col);
        acc.triOut(A, B, Vec3(c.x, c.y - r * 0.5f, c.z), c, col);
    }
}

void box(MeshAccum& acc, Vec3 c, float w, float h, float d, const Col& col) {
    float x0 = c.x - w / 2, x1 = c.x + w / 2, y0 = c.y - h / 2, y1 = c.y + h / 2, z0 = c.z - d / 2, z1 = c.z + d / 2;
    Vec3 v[8] = {{x0, y0, z0}, {x1, y0, z0}, {x1, y1, z0}, {x0, y1, z0}, {x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}};
    const int q[6][4] = {{0, 3, 2, 1}, {4, 5, 6, 7}, {0, 4, 7, 3}, {1, 2, 6, 5}, {0, 1, 5, 4}, {3, 7, 6, 2}};
    for (auto& f : q) {
        acc.triOut(v[f[0]], v[f[1]], v[f[2]], c, col);
        acc.triOut(v[f[0]], v[f[2]], v[f[3]], c, col);
    }
}

void cylinder(MeshAccum& acc, Vec3 c, float w, float h, float d, int div, const Col& col) {
    float rx = w / 2, rz = d / 2, y0 = c.y - h / 2, y1 = c.y + h / 2;
    for (int k = 0; k < div; k++) {
        float a0 = TAU_F * k / div, a1 = TAU_F * (k + 1) / div;
        Vec3 b0(c.x + std::cos(a0) * rx, y0, c.z + std::sin(a0) * rz), b1(c.x + std::cos(a1) * rx, y0, c.z + std::sin(a1) * rz);
        Vec3 t0(b0.x, y1, b0.z), t1(b1.x, y1, b1.z);
        acc.triOut(b0, b1, t1, c, col);
        acc.triOut(b0, t1, t0, c, col);
        acc.triN(Vec3(c.x, y1, c.z), t0, t1, Vec3(0, 1, 0), col);
        acc.triN(Vec3(c.x, y0, c.z), b1, b0, Vec3(0, -1, 0), col);
    }
}
