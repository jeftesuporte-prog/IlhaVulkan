// Configurações do mundo. 1 unidade = 1 METRO. O boneco tem 1.75 m e é a régua de tudo.
// (mesmos valores do Cfg.kt original; só entram os ajustes de qualidade novos no fim)
#pragma once
#include <cstdint>

namespace Cfg {
constexpr float WORLD = 1000.f;
constexpr float HALF = 500.f;
constexpr float CHUNK = 100.f;
constexpr int CHUNKS = 10;
#ifdef __ANDROID__
constexpr int CELLS = 60;  // celular: 1.67 m por célula (menos CPU/GPU)
#else
constexpr int CELLS = 80;
#endif  // original: 40 (2.5 m). Agora 1.25 m: encostas mais suaves, bordas de bioma mais finas
constexpr float CELL = CHUNK / CELLS;

constexpr float PLAYER_H = 1.75f;
constexpr float BEACH = 40.f;
constexpr float A = 430.f;
constexpr float B = 380.f;

constexpr float MAIN_H = 210.f;
constexpr float MAIN_R = 150.f;

constexpr float ROAD_W = 6.f;
constexpr float TREE_SPACING = 9.f;

constexpr float TERRAIN_R = 430.f;
#ifdef __ANDROID__
constexpr float DECO_R = 190.f;  // celular: vegetação até 190 m
#else
constexpr float DECO_R = 250.f;
#endif

constexpr float DAY_SECONDS = 600.f;
constexpr float START_HOUR = 6.2f;
constexpr float TILE = 6.25f;

constexpr float RIVER_HALF = 5.f;
constexpr float RIVER_BANK = 7.f;
constexpr float RIVER_BED = -1.3f;
constexpr float BRIDGE_HALF_LEN = 13.f;
constexpr float BRIDGE_HALF_W = 1.7f;
constexpr float WADE_LIMIT = -1.9f;
constexpr float GROVE_X = 50.f;
constexpr float GROVE_Z = 230.f;
constexpr float GROVE_R = 75.f;
constexpr float ORCHARD_X = 240.f;
constexpr float ORCHARD_Z = -170.f;
constexpr float ORCHARD_R = 70.f;
constexpr float PLAYER_R = 0.35f;

constexpr int64_t SEED = 1337;

// ---- qualidade (novo) ----
#ifdef __ANDROID__
constexpr float LOD0_DIST = 55.f;
constexpr int SHADOW_RES = 1024;
constexpr float SHADOW_EXTENT = 90.f;
#else
constexpr float LOD0_DIST = 85.f;       // chunks de árvores mais perto que isso usam o modelo DETALHADO
constexpr int SHADOW_RES = 2048;
constexpr float SHADOW_EXTENT = 110.f;  // meia-largura da área com sombra em volta do boneco (m)
#endif
constexpr int MSAA = 4;
}  // namespace Cfg
