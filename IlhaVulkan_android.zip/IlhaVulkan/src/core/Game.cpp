#include "Game.h"

#include "Prims.h"

// =====================================================================
//  Colisão
// =====================================================================
void SolidMap::pushOut(float* out, float pr) const {
    const int n = Cfg::CHUNKS;
    int ccx = (int)std::floor((out[0] + Cfg::HALF) / Cfg::CHUNK);
    int ccz = (int)std::floor((out[1] + Cfg::HALF) / Cfg::CHUNK);
    for (int rep = 0; rep < 2; rep++)
        for (int j = ccz - 1; j <= ccz + 1; j++)
            for (int i = ccx - 1; i <= ccx + 1; i++) {
                if (i < 0 || j < 0 || i >= n || j >= n) continue;
                auto it = m_.find(j * n + i);
                if (it == m_.end()) continue;
                const std::vector<float>& arr = it->second;
                for (size_t k = 0; k + 2 < arr.size(); k += 3) {
                    float sx = arr[k], sz = arr[k + 1], rr = arr[k + 2] + pr;
                    float dx = out[0] - sx, dz = out[1] - sz;
                    float d2 = dx * dx + dz * dz;
                    if (d2 < rr * rr) {
                        if (d2 < 1e-6f) {
                            out[0] = sx + rr;
                        } else {
                            float d = std::sqrt(d2);
                            out[0] = sx + dx / d * rr;
                            out[1] = sz + dz / d * rr;
                        }
                    }
                }
            }
}

// =====================================================================
//  Boneco
// =====================================================================
void Player::place(float x, float z, float headingDeg) {
    pos = Vec3(x, World::groundAt(x, z), z);
    heading = headingDeg;
}

void Player::move(float dx, float dz, float dt, float speed, const SolidMap& solids) {
    float step = speed * dt;
    float tx = pos.x + dx * step, tz = pos.z + dz * step;
    if (!attempt(tx, tz, solids)) {
        if (!attempt(tx, pos.z, solids)) attempt(pos.x, tz, solids);
    }
    heading = std::atan2(dx, dz) * 180.f / PI_F;
}

bool Player::attempt(float tx0, float tz0, const SolidMap& solids) {
    float t[2] = {clampf(tx0, -Cfg::HALF + 5.f, Cfg::HALF - 5.f), clampf(tz0, -Cfg::HALF + 5.f, Cfg::HALF - 5.f)};

    // 1) grades da ponte: quem está no deck fica no deck, quem está fora não entra pelo lado
    float aN = Bridge::along(t[0], t[1]);
    if (std::fabs(aN) < Cfg::BRIDGE_HALF_LEN) {
        float cO = Bridge::across(pos.x, pos.z);
        float cN = Bridge::across(t[0], t[1]);
        float inner = Cfg::BRIDGE_HALF_W - Cfg::PLAYER_R;
        float outer = Cfg::BRIDGE_HALF_W + Cfg::PLAYER_R;
        bool changed = false;
        if (std::fabs(cO) < Cfg::BRIDGE_HALF_W) {
            if (std::fabs(cN) > inner) { cN = cN > 0.f ? inner : -inner; changed = true; }
        } else if (std::fabs(cN) < outer) {
            cN = cO > 0.f ? outer : -outer;
            changed = true;
        }
        if (changed) {
            t[0] = Bridge::x + Bridge::dx * aN - Bridge::dz * cN;
            t[1] = Bridge::z + Bridge::dz * aN + Bridge::dx * cN;
        }
    }

    // 2) troncos e pedras
    solids.pushOut(t, Cfg::PLAYER_R);
    float nx = t[0], nz = t[1];

    // 3) terreno: água funda, rio sem ponte, parede íngreme
    bool deckTarget = World::onDeck(nx, nz);
    float g1 = World::groundAt(nx, nz);
    if (g1 < Cfg::WADE_LIMIT) return false;
    float rise = g1 - pos.y;
    if (rise > 0.05f) {
        float moved = std::hypot(nx - pos.x, nz - pos.z);
        bool ok = deckTarget ? rise <= 1.2f : (moved > 1e-4f && rise / moved <= 1.15f);
        if (!ok) return false;
    }
    pos.x = nx;
    pos.z = nz;
    if (pos.y < g1) { pos.y = g1; vy_ = 0.f; }
    return true;
}

void Player::jump() {
    if (grounded) {
        vy_ = 6.5f;
        grounded = false;
    }
}

void Player::physics(float dt) {
    float g = World::groundAt(pos.x, pos.z);
    if (grounded && vy_ <= 0.f && pos.y - g <= 0.35f) {
        pos.y = g;
    } else {
        grounded = false;
        vy_ -= 18.f * dt;
        pos.y += vy_ * dt;
        if (pos.y <= g && vy_ <= 0.f) {
            pos.y = g;
            vy_ = 0.f;
            grounded = true;
        }
    }
}

// =====================================================================
//  Céu: hora | topo RGB | horizonte RGB | ambiente RGB | luz principal RGB  (tabela do Sky.kt)
// =====================================================================
static const float KEY[][13] = {
    {0.0f, 0.02f, 0.03f, 0.10f, 0.05f, 0.08f, 0.20f, 0.22f, 0.27f, 0.42f, 0.34f, 0.42f, 0.68f},
    {4.5f, 0.04f, 0.06f, 0.20f, 0.22f, 0.17f, 0.38f, 0.24f, 0.28f, 0.44f, 0.34f, 0.40f, 0.64f},
    {5.4f, 0.22f, 0.32f, 0.68f, 1.00f, 0.52f, 0.58f, 0.42f, 0.42f, 0.60f, 0.85f, 0.52f, 0.52f},
    {6.3f, 0.36f, 0.58f, 0.90f, 1.00f, 0.72f, 0.66f, 0.50f, 0.52f, 0.66f, 1.00f, 0.72f, 0.52f},
    {7.5f, 0.50f, 0.76f, 0.93f, 0.85f, 0.90f, 1.00f, 0.55f, 0.62f, 0.72f, 1.00f, 0.90f, 0.68f},
    {9.0f, 0.53f, 0.81f, 0.92f, 0.78f, 0.91f, 1.00f, 0.55f, 0.62f, 0.72f, 1.00f, 0.93f, 0.70f},
    {15.5f, 0.53f, 0.81f, 0.92f, 0.78f, 0.91f, 1.00f, 0.55f, 0.62f, 0.72f, 1.00f, 0.93f, 0.70f},
    {17.2f, 0.45f, 0.65f, 0.90f, 0.95f, 0.85f, 0.72f, 0.55f, 0.58f, 0.68f, 1.00f, 0.85f, 0.58f},
    {18.0f, 0.34f, 0.44f, 0.80f, 1.00f, 0.55f, 0.38f, 0.48f, 0.42f, 0.56f, 1.00f, 0.58f, 0.36f},
    {18.6f, 0.22f, 0.24f, 0.58f, 0.95f, 0.38f, 0.52f, 0.36f, 0.34f, 0.52f, 0.62f, 0.40f, 0.52f},
    {19.4f, 0.09f, 0.10f, 0.34f, 0.55f, 0.25f, 0.46f, 0.26f, 0.28f, 0.46f, 0.36f, 0.40f, 0.64f},
    {20.5f, 0.03f, 0.05f, 0.14f, 0.07f, 0.11f, 0.26f, 0.22f, 0.27f, 0.42f, 0.34f, 0.42f, 0.68f},
    {24.0f, 0.02f, 0.03f, 0.10f, 0.05f, 0.08f, 0.20f, 0.22f, 0.27f, 0.42f, 0.34f, 0.42f, 0.68f},
};
static const int NKEY = sizeof(KEY) / sizeof(KEY[0]);

SkyState::SkyState() { recompute(); }

void SkyState::recompute() {
    float a = (tod - 6.f) * PI_F / 12.f;
    toSun = Vec3(std::cos(a), std::sin(a), -0.28f).nor();
    toMoon = toSun * -1.f;
    sunE = toSun.y;
    float k = smooth(0.10f, -0.10f, sunE);
    toLight = (toSun * (1.f - k) + toMoon * k).nor();

    int i = 0;
    while (i < NKEY - 2 && tod >= KEY[i + 1][0]) i++;
    const float* p = KEY[i];
    const float* q = KEY[i + 1];
    float f = clampf((tod - p[0]) / (q[0] - p[0]), 0.f, 1.f);
    float s = f * f * (3.f - 2.f * f);
    auto L = [&](int o) { return Col{lerpf(p[o], q[o], s), lerpf(p[o + 1], q[o + 1], s), lerpf(p[o + 2], q[o + 2], s)}; };
    top = L(1);
    hor = L(4);
    ambient = L(7);
    lightC = L(10);
    fog = hor;
}

void SkyState::update(float dt, float camAz) {
    tod = std::fmod(tod + dt * 24.f / Cfg::DAY_SECONDS, 24.f);
    recompute();
    if (nightK() > 0.7f) {
        meteorTimer_ -= dt;
        if (meteorTimer_ <= 0.f) {
            meteorTimer_ = 25.f + rnd_.nextFloat() * 45.f;
            float az = camAz + (rnd_.nextFloat() - 0.5f) * 1.6f;
            float y = 0.35f + rnd_.nextFloat() * 0.5f;
            float rr = std::sqrt(1.f - y * y);
            Vec3 d0(rr * std::cos(az), y, rr * std::sin(az));
            Vec3 r(rnd_.nextFloat() - 0.5f, rnd_.nextFloat() - 0.7f, rnd_.nextFloat() - 0.5f);
            Vec3 tv = (r - d0 * r.dot(d0)).nor();
            if (tv.y > 0.f) tv = tv * -1.f;
            meteors.push_back({d0, tv, 0.9f + rnd_.nextFloat() * 0.6f, 0.8f + rnd_.nextFloat() * 0.5f});
        }
    }
    for (size_t i = 0; i < meteors.size();) {
        meteors[i].age += dt;
        if (meteors[i].age > meteors[i].life) meteors.erase(meteors.begin() + i);
        else i++;
    }
}

// =====================================================================
//  Props: píer, ponte, boneco
// =====================================================================
namespace Props {

MeshAccum pier() {
    MeshAccum a;
    int k = 0;
    for (float z = -8.f; z < 30.f; z += 0.5f, k++) {
        float tone = 0.92f + 0.10f * (float)((k * 7) % 5) / 4.f;
        box(a, Vec3(0, 0.9f, z + 0.25f), 3.2f, 0.14f, 0.42f, scaled(hexCol(0xA9743F), tone));
    }
    const float pzs[8] = {-6, -1, 4, 9, 14, 19, 24, 29};
    for (float pz : pzs) {
        for (float px : {-1.5f, 1.5f}) cylinder(a, Vec3(px, -1.5f, pz), 0.4f, 6.f, 0.4f, 8, hexCol(0x6B3E1C));
        box(a, Vec3(0, 0.7f, pz), 3.4f, 0.15f, 0.25f, hexCol(0x6B3E1C));
    }
    // barquinho #8B4513 com vela
    box(a, Vec3(3.0f, 0.1f, 22.f), 1.5f, 0.55f, 3.0f, hexCol(0x8B4513));
    cylinder(a, Vec3(3.0f, 0.1f, 24.0f), 1.485f, 0.55f, 1.485f, 4, hexCol(0x8B4513));
    cylinder(a, Vec3(3.0f, 1.9f, 22.3f), 0.12f, 3.2f, 0.12f, 6, hexCol(0x5C3A1E));
    box(a, Vec3(3.0f, 2.2f, 21.4f), 0.05f, 2.2f, 1.6f, Col{1, 1, 1});
    return a;
}

MeshAccum bridge() {
    MeshAccum a;
    const float hl = Cfg::BRIDGE_HALF_LEN, hw = Cfg::BRIDGE_HALF_W;
    int k = 0;
    for (float z = -hl + 0.25f; z < hl; z += 0.5f, k++) {
        float tone = (k % 2 == 0) ? 0.f : -0.05f;
        box(a, Vec3(0, -0.07f + tone * 0.2f, z), hw * 2.f + 0.3f, 0.14f, 0.46f, scaled(hexCol(0xB07F45), 0.94f + 0.08f * (float)((k * 5) % 4) / 3.f));
    }
    Col wood = hexCol(0x6B3E1C);
    for (float sx : {-1.2f, 1.2f}) box(a, Vec3(sx, -0.38f, 0), 0.22f, 0.3f, hl * 2.f, wood);
    for (float pz : {-8.f, -2.7f, 2.7f, 8.f})
        for (float px : {-1.4f, 1.4f}) cylinder(a, Vec3(px, -2.2f, pz), 0.38f, 4.4f, 0.38f, 8, wood);
    for (float pz = -hl + 0.3f; pz <= hl; pz += 2.2f)
        for (float px : {-hw, hw}) box(a, Vec3(px, 0.55f, pz), 0.16f, 1.1f, 0.16f, wood);
    for (float px : {-hw, hw}) {
        box(a, Vec3(px, 1.08f, 0), 0.12f, 0.1f, hl * 2.f, wood);
        box(a, Vec3(px, 0.55f, 0), 0.08f, 0.08f, hl * 2.f, wood);
    }
    return a;
}

MeshAccum player() {
    MeshAccum a;
    box(a, Vec3(-0.12f, 0.425f, 0), 0.2f, 0.85f, 0.22f, hexCol(0x1D3557));
    box(a, Vec3(0.12f, 0.425f, 0), 0.2f, 0.85f, 0.22f, hexCol(0x1D3557));
    box(a, Vec3(0, 1.15f, 0), 0.5f, 0.6f, 0.28f, hexCol(0xE63946));
    box(a, Vec3(-0.31f, 1.15f, 0), 0.12f, 0.6f, 0.14f, hexCol(0xF1C27D));
    box(a, Vec3(0.31f, 1.15f, 0), 0.12f, 0.6f, 0.14f, hexCol(0xF1C27D));
    box(a, Vec3(0, 1.60f, 0), 0.3f, 0.3f, 0.3f, hexCol(0xF1C27D));
    box(a, Vec3(0, 1.63f, 0.151f), 0.2f, 0.05f, 0.02f, hexCol(0x222222));
    return a;
}

Mat4 pierTransform() {
    float theta = std::atan2(RoadNet::dirX, RoadNet::dirZ);
    return Mat4::mul(Mat4::translate(RoadNet::shoreX, 0.f, RoadNet::shoreZ), Mat4::rotY(theta));
}
Mat4 bridgeTransform() {
    float theta = std::atan2(Bridge::dx, Bridge::dz);
    return Mat4::mul(Mat4::translate(Bridge::x, Bridge::deckY, Bridge::z), Mat4::rotY(theta));
}
}  // namespace Props
