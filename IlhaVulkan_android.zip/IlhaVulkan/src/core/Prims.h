// Primitivas low-poly usadas por árvores, pedras, arbustos, píer, ponte e boneco.
#pragma once
#include "JavaRandom.h"
#include "MeshAccum.h"

inline Col bcol(float r, float g, float b, float k = 1.f) { return {std::min(1.f, r * k), std::min(1.f, g * k), std::min(1.f, b * k)}; }

/** Esfera facetada. level 0 = icosaedro (20 faces), 1 = 80 faces, 2 = 320 faces. Vértices jitterados = formato orgânico. */
void blob(MeshAccum& acc, JRandom& rng, Vec3 c, Vec3 r, const Col& col, float jit, int level = 0, float faceVar = 0.f, bool uv = false);

/** Tronco/cone entre dois círculos (horizontais) com `sides` lados. */
void prism(MeshAccum& acc, Vec3 p0, float r0, Vec3 p1, float r1, int sides, const Col& col);

/** Mancha (losango) colada na superfície: c = centro do objeto, n = normal unitária, dist = distância até a superfície. */
void spotOn(MeshAccum& acc, Vec3 c, Vec3 n, float dist, float size, const Col& col);

/** Octaedro (flores). */
void octa(MeshAccum& acc, Vec3 c, float r, const Col& col);

/** Caixa alinhada aos eixos (w,h,d = tamanho total), centro em c. */
void box(MeshAccum& acc, Vec3 c, float w, float h, float d, const Col& col);

/** Cilindro com eixo Y (w,d = diâmetros em X/Z, h = altura), com tampas. */
void cylinder(MeshAccum& acc, Vec3 c, float w, float h, float d, int div, const Col& col);
