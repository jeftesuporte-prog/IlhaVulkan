// Forma da ilha, montanhas, estrada, rio, ponte, píer e cores de terreno.
// Port 1:1 do World.kt original: tudo é função pura depois de World::init() => thread-safe.
#pragma once
#include <cstdint>
#include <vector>
#include "Cfg.h"
#include "Math.h"

struct Col {
    float r = 1, g = 1, b = 1;
};
inline Col hexCol(uint32_t h) { return {((h >> 16) & 255) / 255.f, ((h >> 8) & 255) / 255.f, (h & 255) / 255.f}; }
inline Col scaled(Col c, float k) { return {std::min(1.f, c.r * k), std::min(1.f, c.g * k), std::min(1.f, c.b * k)}; }

/** Paleta do documento oficial (as MESMAS cores do app). */
namespace Pal {
inline Col GRASS() { return hexCol(0x5DBB35); }
inline Col SAND() { return hexCol(0xF5DEB3); }
inline Col WET() { return hexCol(0xD8BE8A); }
inline Col SEABED() { return hexCol(0xE3CF9E); }
inline Col ROCK() { return hexCol(0x5A5A5A); }
inline Col MOSS() { return hexCol(0x4A7C2E); }
inline Col DIRT() { return hexCol(0x8B5A2B); }
inline Col TRUNK() { return hexCol(0x8B4513); }
inline Col CROWN() { return hexCol(0x2E8B57); }
inline Col PALM_TRUNK() { return hexCol(0xA0703C); }
inline Col PALM_LEAF() { return hexCol(0x2FB84A); }
inline Col BUSH() { return hexCol(0x3FA34D); }
inline Col PINK() { return hexCol(0xFF69B4); }
inline Col YELLOW() { return hexCol(0xFFE135); }
inline Col BLUE() { return hexCol(0x4D9BFF); }
}  // namespace Pal

struct Peak {
    float x, z, h, r;
};

namespace Base {
extern std::vector<Peak> peaks;
float n(float x, float z);
float shape(float x, float z);
/** Distância aproximada (m) da linha d'água: positivo em terra, negativo no mar. */
float depth(float x, float z);
float forestW(float x, float z, float d, float h);
float orchard(float x, float z);
float grove(float x, float z);
float baseHeight(float x, float z);
}  // namespace Base

namespace RoadNet {
constexpr float dirX = -0.8f;
constexpr float dirZ = 0.6f;
extern float shoreX, shoreZ, startX, startZ, bridgeX, bridgeZ, bridgeTX, bridgeTZ;
void init();
/** out[0] = distância até o eixo da estrada (1e9 se longe), out[1] = altura da estrada ali. */
void query(float x, float z, float* out);
bool nearPier(float x, float z);
}  // namespace RoadNet

namespace River {
float dist(float x, float z);
float w2d(float x, float z);
}  // namespace River

namespace Bridge {
extern float x, z, dx, dz, deckY;
inline float along(float px, float pz) { return (px - x) * dx + (pz - z) * dz; }
inline float across(float px, float pz) { return -(px - x) * dz + (pz - z) * dx; }
inline bool onDeck(float px, float pz) {
    return std::fabs(along(px, pz)) <= Cfg::BRIDGE_HALF_LEN && std::fabs(across(px, pz)) <= Cfg::BRIDGE_HALF_W;
}
}  // namespace Bridge

namespace Pier {
constexpr float TOP = 0.97f;
constexpr float HALF_W = 1.6f;
float along(float x, float z);
float across(float x, float z);
bool onDeck(float x, float z);
}  // namespace Pier

namespace World {
void init();  // chame UMA vez, antes de qualquer outra coisa
float heightAt(float x, float z);
float groundAt(float x, float z);
bool onDeck(float x, float z);
bool inRiver(float x, float z);
bool reserved(float x, float z);

constexpr int SN = 10;  // floats por amostra
/**
 * o[k..k+2] = tom (multiplica a textura), o[k+3]=pedra, o[k+4]=musgo, o[k+5]=areia,
 * o[k+6]=floresta, o[k+7]=estrada, o[k+8]=rio, o[k+9]=distância da água (m).
 */
void sample(float x, float z, float h, float ny, float* o, int k);
}  // namespace World
