#include "ChunkBuilder.h"

#include "JavaRandom.h"
#include "Prims.h"
#include "World.h"

namespace ChunkBuilder {

// =====================================================================
//  TERRENO (5 materiais: areia, grama, pedra, pedra c/ musgo, chão de floresta)
// =====================================================================
Built terrain(int cx, int cz) {
    const int n = Cfg::CELLS;
    const float s = Cfg::CELL;
    const float x0 = cx * Cfg::CHUNK - Cfg::HALF;
    const float z0 = cz * Cfg::CHUNK - Cfg::HALF;
    const int w = n + 1;
    const int m = n + 3;  // grade com 1 de margem (normais nas bordas)
    std::vector<float> big((size_t)m * m);
    for (int j = -1; j <= n + 1; j++)
        for (int i = -1; i <= n + 1; i++) big[(j + 1) * m + (i + 1)] = World::heightAt(x0 + i * s, z0 + j * s);

    std::vector<float> hs((size_t)w * w);
    const int sn = World::SN;
    std::vector<float> inf((size_t)w * w * sn);
    float minY = 1e9f, maxY = -1e9f;
    for (int j = 0; j <= n; j++)
        for (int i = 0; i <= n; i++) {
            float h = big[(j + 1) * m + (i + 1)];
            hs[j * w + i] = h;
            minY = std::min(minY, h);
            maxY = std::max(maxY, h);
            float gx = (big[(j + 1) * m + (i + 2)] - big[(j + 1) * m + i]) / (2.f * s);
            float gz = (big[(j + 2) * m + (i + 1)] - big[j * m + (i + 1)]) / (2.f * s);
            float ny = 1.f / std::sqrt(1.f + gx * gx + gz * gz);
            World::sample(x0 + i * s, z0 + j * s, h, ny, &inf[(size_t)(j * w + i) * sn], 0);
        }

    MeshAccum accs[5];
    const float inv = 1.f / Cfg::TILE;

    auto emit = [&](int a, int b, int c) {
        Vec3 A(x0 + (a % w) * s, hs[a], z0 + (a / w) * s);
        Vec3 B(x0 + (b % w) * s, hs[b], z0 + (b / w) * s);
        Vec3 C(x0 + (c % w) * s, hs[c], z0 + (c / w) * s);
        Vec3 nn = (B - A).cross(C - A);
        float l = nn.len();
        if (l < 1e-9f) return;
        nn = nn * (1.f / l);
        const float* ia = &inf[(size_t)a * sn];
        const float* ib = &inf[(size_t)b * sn];
        const float* ic = &inf[(size_t)c * sn];
        float d = (ia[9] + ib[9] + ic[9]) / 3.f;
        float rock = (ia[3] + ib[3] + ic[3]) / 3.f;
        float moss = (ia[4] + ib[4] + ic[4]) / 3.f;
        float sand = (ia[5] + ib[5] + ic[5]) / 3.f;
        float fw = (ia[6] + ib[6] + ic[6]) / 3.f;
        float road = (ia[7] + ib[7] + ic[7]) / 3.f;
        float jit = 0.22f * Base::n((A.x + B.x + C.x) * 0.27f, (A.z + B.z + C.z) * 0.27f);
        int mat;
        if (d <= 0.f) mat = M_SAND;
        else if (road > 0.5f) mat = M_FOREST;
        else if (rock > 0.5f) mat = moss > 0.4f ? M_ROCKMOSS : M_ROCK;
        else if (sand + jit * 0.8f > 0.5f) mat = M_SAND;
        else if (fw + jit > 0.5f) mat = M_FOREST;
        else mat = M_GRASS;
        accs[mat].triVC(A, packC(ia[0], ia[1], ia[2]), (A.x - x0) * inv, (A.z - z0) * inv,
                        B, packC(ib[0], ib[1], ib[2]), (B.x - x0) * inv, (B.z - z0) * inv,
                        C, packC(ic[0], ic[1], ic[2]), (C.x - x0) * inv, (C.z - z0) * inv, nn);
    };

    for (int j = 0; j < n; j++)
        for (int i = 0; i < n; i++) {
            int i00 = j * w + i, i10 = i00 + 1, i01 = i00 + w, i11 = i01 + 1;
            if ((i + j) % 2 == 0) {
                emit(i00, i01, i11);
                emit(i00, i11, i10);
            } else {
                emit(i00, i01, i10);
                emit(i10, i01, i11);
            }
        }

    Built b;
    b.layer = 0;
    b.key = cz * Cfg::CHUNKS + cx;
    b.minY = minY;
    b.maxY = maxY;
    for (int k = 0; k < 5; k++)
        if (!accs[k].v.empty()) b.parts.push_back({k, std::move(accs[k].v)});
    return b;
}

// =====================================================================
//  VEGETAÇÃO / PEDRAS / FLORES
// =====================================================================
/** p[0]=altura, p[1]=normalY, p[2]=distância da água (m), p[3]=distância da estrada, p[4]=peso de floresta */
static void probe(float x, float z, float* p) {
    p[0] = World::heightAt(x, z);
    float gx = (World::heightAt(x + 1.2f, z) - World::heightAt(x - 1.2f, z)) / 2.4f;
    float gz = (World::heightAt(x, z + 1.2f) - World::heightAt(x, z - 1.2f)) / 2.4f;
    p[1] = 1.f / std::sqrt(1.f + gx * gx + gz * gz);
    p[2] = Base::depth(x, z);
    float q[2];
    RoadNet::query(x, z, q);
    p[3] = q[0];
    p[4] = Base::forestW(x, z, p[2], p[0]);
}

static void addTree(Built& b, int species, float x, float y, float z, float hh, int64_t seed, float solidR) {
    JRandom r(seed);
    BuiltTree t;
    t.species = (uint8_t)species;
    t.variant = (uint8_t)r.nextInt(TREE_VARIANTS[species]);
    t.inst = {x, y, z, hh / TREE_NOMINAL_H[species], r.nextFloat() * TAU_F, 0.92f + 0.16f * r.nextFloat(), 0.f, 0.f};
    b.trees.push_back(t);
    b.solids.push_back(x);
    b.solids.push_back(z);
    b.solids.push_back(solidR);
}

static void addSolid(Built& b, float x, float z, float r) {
    b.solids.push_back(x);
    b.solids.push_back(z);
    b.solids.push_back(r);
}

Built decor(int cx, int cz) {
    MeshAccum acc;   // arbustos, flores (cor de vértice)
    MeshAccum racc;  // pedras (textura de pedra)
    Built out;
    out.layer = 1;
    out.key = cz * Cfg::CHUNKS + cx;
    const float x0 = cx * Cfg::CHUNK - Cfg::HALF;
    const float z0 = cz * Cfg::CHUNK - Cfg::HALF;
    JRandom rng(Cfg::SEED * 31LL + (int64_t)cx * 7919LL + (int64_t)cz * 104729LL);
    float p[5];
    const float roadClear = Cfg::ROAD_W * 0.5f + 3.f;

    // ---- árvores da floresta (TREE_01): tronco com colisão, copa atravessável ----
    const float sp = Cfg::TREE_SPACING;
    const int cnt = (int)std::ceil(Cfg::CHUNK / sp);
    for (int gz = 0; gz < cnt; gz++)
        for (int gx = 0; gx < cnt; gx++) {
            float x = x0 + (gx + 0.5f) * sp + (rng.nextFloat() - 0.5f) * sp * 0.8f;
            float z = z0 + (gz + 0.5f) * sp + (rng.nextFloat() - 0.5f) * sp * 0.8f;
            float roll = rng.nextFloat();
            float hh = 7.f + rng.nextFloat() * 2.f;
            int64_t tseed = rng.nextLong();
            if (x >= x0 + Cfg::CHUNK || z >= z0 + Cfg::CHUNK) continue;
            if (std::max(Base::grove(x, z), Base::orchard(x, z)) > 0.2f) continue;
            if (World::reserved(x, z)) continue;
            probe(x, z, p);
            if (p[2] < Cfg::BEACH + 4.f || p[3] < roadClear + 1.f || p[0] > 70.f || p[1] < 0.78f) continue;
            float dens = 0.5f + 0.5f * Base::n(x * 0.02f + 3.f, z * 0.02f);
            float prob = (0.08f + 0.92f * p[4]) * (0.7f + 0.3f * dens) * (1.f - smooth(35.f, 70.f, p[0]));
            if (roll > prob) continue;
            addTree(out, SP_BIG, x, p[0], z, hh, tseed, 0.75f);
        }

    // ---- bananal ----
    const float bsp = 6.5f;
    const int bcnt = (int)std::ceil(Cfg::CHUNK / bsp);
    for (int gz = 0; gz < bcnt; gz++)
        for (int gx = 0; gx < bcnt; gx++) {
            float x = x0 + (gx + 0.5f) * bsp + (rng.nextFloat() - 0.5f) * bsp * 0.7f;
            float z = z0 + (gz + 0.5f) * bsp + (rng.nextFloat() - 0.5f) * bsp * 0.7f;
            float roll = rng.nextFloat();
            float hh = 4.5f + rng.nextFloat() * 1.5f;
            int64_t bseed = rng.nextLong();
            if (x >= x0 + Cfg::CHUNK || z >= z0 + Cfg::CHUNK) continue;
            if (Base::grove(x, z) < 0.25f || roll > 0.85f) continue;
            if (World::reserved(x, z)) continue;
            probe(x, z, p);
            if (p[2] < Cfg::BEACH + 4.f || p[3] < roadClear || p[1] < 0.8f) continue;
            addTree(out, SP_BANANA, x, p[0], z, hh, bseed, 0.4f);
        }

    // ---- pomar: macieiras e laranjeiras em XADREZ ----
    const float osp = 9.5f;
    const float ox = Cfg::ORCHARD_X - Cfg::ORCHARD_R;
    const float oz = Cfg::ORCHARD_Z - Cfg::ORCHARD_R;
    if (x0 + Cfg::CHUNK > ox && x0 < ox + 2.f * Cfg::ORCHARD_R && z0 + Cfg::CHUNK > oz && z0 < oz + 2.f * Cfg::ORCHARD_R) {
        int ix0 = (int)std::floor((x0 - ox) / osp) - 1;
        int ix1 = (int)std::floor((x0 + Cfg::CHUNK - ox) / osp) + 1;
        int iz0 = (int)std::floor((z0 - oz) / osp) - 1;
        int iz1 = (int)std::floor((z0 + Cfg::CHUNK - oz) / osp) + 1;
        for (int iz = iz0; iz <= iz1; iz++)
            for (int ix = ix0; ix <= ix1; ix++) {
                JRandom cr((int64_t)ix * 73856093LL + (int64_t)iz * 19349663LL + Cfg::SEED * 83492791LL);
                float x = ox + (ix + 0.5f) * osp + (cr.nextFloat() - 0.5f) * osp * 0.5f;
                float z = oz + (iz + 0.5f) * osp + (cr.nextFloat() - 0.5f) * osp * 0.5f;
                float hh = 5.f + cr.nextFloat() * 1.2f;
                int64_t tseed = cr.nextLong();
                if (x < x0 || x >= x0 + Cfg::CHUNK || z < z0 || z >= z0 + Cfg::CHUNK) continue;
                if (Base::orchard(x, z) < 0.3f) continue;
                if (World::reserved(x, z)) continue;
                probe(x, z, p);
                if (p[2] < Cfg::BEACH + 4.f || p[3] < roadClear + 1.f || p[1] < 0.8f) continue;
                if (((ix + iz) & 1) == 0) addTree(out, SP_APPLE, x, p[0], z, hh, tseed, 0.7f);
                else addTree(out, SP_ORANGE, x, p[0], z, hh, tseed, 0.85f);
            }
    }

    // ---- coqueiros da praia: 8-12 m. TRONCO TEM COLISÃO ----
    const float pg = 9.f;
    const int pc = (int)(Cfg::CHUNK / pg);
    for (int gz = 0; gz < pc; gz++)
        for (int gx = 0; gx < pc; gx++) {
            float x = x0 + (gx + 0.5f) * pg + (rng.nextFloat() - 0.5f) * 5.f;
            float z = z0 + (gz + 0.5f) * pg + (rng.nextFloat() - 0.5f) * 5.f;
            float roll = rng.nextFloat();
            float hh = 8.f + rng.nextFloat() * 4.f;
            int64_t seed = rng.nextLong();
            if (roll > 0.6f || World::reserved(x, z)) continue;
            probe(x, z, p);
            if (p[2] < 5.f || p[2] > 37.f || p[3] < 5.f || p[0] < 0.3f) continue;
            JRandom r(seed);
            bool curved = r.nextFloat() < 0.3f;
            BuiltTree t;
            t.species = curved ? SP_PALMC : SP_PALM;
            t.variant = (uint8_t)r.nextInt(TREE_VARIANTS[t.species]);
            t.inst = {x, p[0], z, hh / 10.f, r.nextFloat() * TAU_F, 0.92f + 0.16f * r.nextFloat(), 0.f, 0.f};
            out.trees.push_back(t);
            addSolid(out, x, z, 0.4f);
        }

    // ---- arbustos 1-2 m (sem colisão) ----
    for (int i = 0; i < 70; i++) {
        float x = x0 + rng.nextFloat() * Cfg::CHUNK;
        float z = z0 + rng.nextFloat() * Cfg::CHUNK;
        float rx = 0.6f + rng.nextFloat() * 0.5f;
        float ry = 0.55f + rng.nextFloat() * 0.45f;
        float br = 0.85f + rng.nextFloat() * 0.3f;
        probe(x, z, p);
        if (p[2] > Cfg::BEACH + 2.f && p[3] > 5.f && p[0] < 90.f && p[1] > 0.8f && !World::reserved(x, z)) {
            blob(acc, rng, Vec3(x, p[0] + ry * 0.8f, z), Vec3(rx, ry, rx), scaled(Pal::BUSH(), br), 0.4f, 1, 0.14f);
        }
    }

    // ---- pedras grandes (>= 2.4 m): textura de pedra + COLISÃO ----
    for (int i = 0; i < 14; i++) {
        float x = x0 + rng.nextFloat() * Cfg::CHUNK;
        float z = z0 + rng.nextFloat() * Cfg::CHUNK;
        float hh = 2.4f + rng.nextFloat() * 1.6f;
        float wd = 1.1f + rng.nextFloat() * 0.6f;
        float br = 0.78f + rng.nextFloat() * 0.22f;
        probe(x, z, p);
        if (p[2] > 8.f && p[3] > 6.f && !World::reserved(x, z)) {
            float rx = hh * wd * 0.5f;
            blob(racc, rng, Vec3(x, p[0] + hh * 0.3f, z), Vec3(rx, hh * 0.55f, rx), Col{br, br, br}, 0.5f, 1, 0.12f, true);
            addSolid(out, x, z, rx * 0.85f);
        }
    }

    // ---- pedrinhas pequenas (enfeite) ----
    for (int i = 0; i < 45; i++) {
        float x = x0 + rng.nextFloat() * Cfg::CHUNK;
        float z = z0 + rng.nextFloat() * Cfg::CHUNK;
        float r = 0.18f + rng.nextFloat() * 0.3f;
        float br = 0.7f + rng.nextFloat() * 0.3f;
        probe(x, z, p);
        if (p[2] > Cfg::BEACH + 4.f && p[3] > 3.5f && p[0] < 60.f && !World::reserved(x, z)) {
            blob(racc, rng, Vec3(x, p[0] + r * 0.35f, z), Vec3(r * 1.2f, r * 0.7f, r), Col{br, br, br}, 0.4f, 0, 0.1f, true);
        }
    }

    // ---- flores pequenas em tufos: rosa, amarela, azul ----
    for (int i = 0; i < 42; i++) {
        float bx = x0 + rng.nextFloat() * Cfg::CHUNK;
        float bz = z0 + rng.nextFloat() * Cfg::CHUNK;
        int k = rng.nextInt(3);
        Col c = k == 0 ? Pal::PINK() : (k == 1 ? Pal::YELLOW() : Pal::BLUE());
        for (int f = 0; f < 4; f++) {
            float x = bx + (rng.nextFloat() - 0.5f) * 3.f;
            float z = bz + (rng.nextFloat() - 0.5f) * 3.f;
            probe(x, z, p);
            if (p[2] > Cfg::BEACH + 6.f && p[3] > 4.5f && p[0] < 40.f && p[1] > 0.85f && p[4] < 0.45f && !World::reserved(x, z)) {
                octa(acc, Vec3(x, p[0] + 0.24f, z), 0.2f, c);
            }
        }
    }

    if (!acc.v.empty()) out.parts.push_back({M_DECO, std::move(acc.v)});
    if (!racc.v.empty()) out.parts.push_back({M_DECOROCK, std::move(racc.v)});
    out.minY = -5.f;
    out.maxY = 240.f;
    return out;
}

}  // namespace ChunkBuilder
