#include "Trees.h"

#include "Prims.h"

namespace {

// Dois geradores: `shape` decide a FORMA da árvore (consome igual nos dois LODs => mesmo desenho, só muda o detalhe)
// e `det` decide o detalhe fino (folhas, tons) e pode consumir diferente por LOD.
struct Ctx {
    MeshAccum& acc;
    JRandom shape;
    JRandom det;
    int lod;
    Ctx(MeshAccum& a, int64_t seed, int l) : acc(a), shape(seed), det(seed ^ (int64_t)0x9E3779B97F4A7C15ULL), lod(l) {}
    int cnt(float n) const { return lod == 0 ? std::max(1, (int)n) : std::max(1, (int)(n * 0.18f)); }
    float ls() const { return lod == 0 ? 1.f : 2.0f; }  // folhas do LOD1: menos, porém maiores
    int sides(int hi, int lo) const { return lod == 0 ? hi : lo; }
    int lvl() const { return lod == 0 ? 1 : 0; }
    float sh() { return shape.nextFloat(); }
    float dt() { return det.nextFloat(); }
};

inline Col mix(const Col& a, const Col& b, float t) { return {lerpf(a.r, b.r, t), lerpf(a.g, b.g, t), lerpf(a.b, b.b, t)}; }
inline Vec3 V(float x, float y, float z) { return Vec3(x, y, z); }

// ---------------------------------------------------------------------
//  Troncos e galhos: tubos facetados com casca "rochosa" (anéis jitterados, sulcos, torção)
// ---------------------------------------------------------------------
struct Ring {
    std::vector<Vec3> p;
};

Ring makeRing(Ctx& c, Vec3 ctr, Vec3 axis, float r, float ang, int sides, float jit, float ridge, Vec3 ref) {
    Vec3 a = axis.nor();
    Vec3 u = ref.cross(a).nor();
    Vec3 v = a.cross(u);
    Ring R;
    R.p.resize(sides);
    for (int s = 0; s < sides; s++) {
        float th = ang + s * TAU_F / sides;
        float rr = r * (1.f + (c.dt() - 0.5f) * jit + ((s & 1) ? ridge : -ridge));
        R.p[s] = ctr + (u * std::cos(th) + v * std::sin(th)) * rr;
    }
    return R;
}

void tube(Ctx& c, const std::vector<Vec3>& pts, const std::vector<float>& rad, int sides, float twist, float a0, Col base, float k,
          float jit = 0.10f, float ridge = 0.05f) {
    int n = (int)pts.size();
    if (n < 2) return;
    Vec3 ax0 = (pts[1] - pts[0]).nor();
    Vec3 ref = std::fabs(ax0.y) < 0.7f ? Vec3(0, 1, 0) : Vec3(1, 0, 0);
    std::vector<Ring> R(n);
    for (int i = 0; i < n; i++) {
        Vec3 axis = i == 0 ? pts[1] - pts[0] : (i == n - 1 ? pts[n - 1] - pts[n - 2] : pts[i + 1] - pts[i - 1]);
        R[i] = makeRing(c, pts[i], axis, rad[i], a0 + twist * i, sides, jit, ridge, ref);
    }
    for (int i = 0; i < n - 1; i++) {
        Vec3 mid = (pts[i] + pts[i + 1]) * 0.5f;
        int ns = (int)R[i].p.size();
        for (int s = 0; s < ns; s++) {
            int s1 = (s + 1) % ns;
            Col col = bcol(base.r, base.g, base.b, k * (0.8f + c.dt() * 0.55f));
            c.acc.triOut(R[i].p[s], R[i].p[s1], R[i + 1].p[s1], mid, col);
            c.acc.triOut(R[i].p[s], R[i + 1].p[s1], R[i + 1].p[s], mid, col);
        }
    }
}

// ---------------------------------------------------------------------
//  Folhas em losango DOBRADAS (4 triângulos): nervura central erguida, bordas caídas
// ---------------------------------------------------------------------
void leafQuad(Ctx& c, Vec3 p, Vec3 mid, Vec3 side, Vec3 down, Vec3 tip, Vec3 origin, const Col& col) {
    Vec3 L = mid + side - down;
    Vec3 R = mid - side - down;
    Col dark = {col.r * 0.86f, col.g * 0.86f, col.b * 0.86f};
    c.acc.triOut(p, L, mid, origin, col);
    c.acc.triOut(L, tip, mid, origin, col);
    c.acc.triOut(p, mid, R, origin, dark);
    c.acc.triOut(mid, tip, R, origin, dark);
}

/** Folha colada na superfície de um elipsoide (centro ctr, raios rad): nasce em d, aponta para phi, ponta levantada (lift). */
void leafOn(Ctx& c, Vec3 ctr, Vec3 rad, Vec3 d, float len, float wid, float phi, const Col& col, float lift) {
    float lh = std::max(std::sqrt(d.x * d.x + d.z * d.z), 1e-4f);
    bool flat = std::fabs(d.y) > 0.95f;
    float t1x = flat ? 1.f : d.z / lh;
    float t1z = flat ? 0.f : -d.x / lh;
    float t2x = d.y * t1z;
    float t2y = d.z * t1x - d.x * t1z;
    float t2z = -d.y * t1x;
    float cph = std::cos(phi), sph = std::sin(phi);
    Vec3 u(t1x * cph + t2x * sph, t2y * sph, t1z * cph + t2z * sph);
    Vec3 v(-t1x * sph + t2x * cph, t2y * cph, -t1z * sph + t2z * cph);
    Vec3 p(ctr.x + d.x * rad.x, ctr.y + d.y * rad.y, ctr.z + d.z * rad.z);
    wid *= 1.5f;   // losangos largos como nas imagens de referência
    lift *= 0.45f; // deitadas na superfície da copa
    Vec3 tip = p + u * len + d * (len * lift);
    Vec3 mid = p + u * (len * 0.5f) + d * (len * lift * 0.5f + wid * 0.25f);
    leafQuad(c, p, mid, v * wid, d * (wid * 0.35f), tip, ctr, col);
}

/** Folhas densas sobre um elipsoide (copa de macieira/laranjeira): n folhas entre o tom escuro e o claro. */
void leafShell(Ctx& c, Vec3 ctr, Vec3 rad, int n, float len, float wid, const Col& dk, const Col& lt, float yMin = -0.5f) {
    int count = c.cnt((float)n * 1.5f);
    for (int i = 0; i < count; i++) {
        float dx = c.dt() * 2.f - 1.f;
        float dz = c.dt() * 2.f - 1.f;
        float dy = yMin + c.dt() * (1.f - yMin);
        float l = std::sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 0.1f) continue;
        float q = c.dt();
        float s = 0.75f + c.dt() * 0.5f;
        leafOn(c, ctr, rad, V(dx / l, dy / l, dz / l), len * s * c.ls(), wid * s * c.ls(), c.dt() * TAU_F, mix(dk, lt, q), 0.3f);
    }
}

/** Bolota de folhas (modelo TREE_01): esfera low-poly verde-escura coberta de placas-folha mais claras. */
void leafBall(Ctx& c, Vec3 ctr, float r, float t) {
    float tt = clampf(t, 0.f, 1.f);
    Vec3 rad(r, r * 0.92f, r);
    blob(c.acc, c.det, ctr, rad, bcol(0.09f + 0.14f * tt, 0.30f + 0.20f * tt, 0.10f + 0.06f * tt), 0.3f, 0, 0.12f);
    int n = c.cnt(30.f * r * r + 6.f);
    for (int i = 0; i < n; i++) {
        float dx = c.dt() * 2.f - 1.f, dz = c.dt() * 2.f - 1.f, dy = c.dt() * 1.4f - 0.25f;
        float l = std::max(std::sqrt(dx * dx + dy * dy + dz * dz), 0.1f);
        float q = c.dt();
        Col col = bcol(0.12f + 0.20f * q + 0.08f * tt, 0.42f + 0.30f * q, 0.12f + 0.10f * q);
        leafOn(c, ctr, rad, V(dx / l, dy / l, dz / l), (r * 0.5f + 0.18f) * c.ls(), (r * 0.2f + 0.07f) * c.ls(), c.dt() * TAU_F, col, 0.25f);
    }
}

void fruit(Ctx& c, Vec3 p, float r, float ry, const Col& col) { blob(c.acc, c.det, p, Vec3(r, ry, r), col, 0.05f, c.lvl(), 0.10f); }

// =====================================================================
//  ÁRVORE GRANDE (TREE_01): tronco grosso torcido com raízes, galhos e copa de bolotas de folhas  [8 m]
// =====================================================================
void buildBig(Ctx& c) {
    const float hh = 8.f;
    float la = c.sh() * TAU_F;
    float lx = std::cos(la) * 0.5f, lz = std::sin(la) * 0.5f;
    float twist = (0.7f + c.sh() * 0.5f) * 3.f;
    float a0 = c.sh() * TAU_F;
    const float ts[6] = {-0.05f, 0.05f, 0.18f, 0.38f, 0.60f, 0.78f};
    const float rs[6] = {1.25f, 0.82f, 0.62f, 0.52f, 0.44f, 0.38f};
    auto radiusAt = [&](float t) {
        for (int i = 0; i < 5; i++)
            if (t <= ts[i + 1]) return lerpf(rs[i], rs[i + 1], clampf((t - ts[i]) / (ts[i + 1] - ts[i]), 0.f, 1.f));
        return rs[5];
    };
    auto trunkPt = [&](float t) { return V(lx * t * t, hh * t, lz * t * t); };

    // tronco: raízes largas que afinam, torção, sulcos de casca
    int nT = c.lod == 0 ? 12 : 5;
    std::vector<Vec3> pts;
    std::vector<float> rad;
    for (int i = 0; i < nT; i++) {
        float t = -0.05f + 0.83f * i / (nT - 1);
        pts.push_back(trunkPt(t));
        rad.push_back(radiusAt(t) * (1.f + 0.40f * std::exp(-(t + 0.05f) * 14.f)));
    }
    Col bark = bcol(0.46f, 0.30f, 0.17f);
    tube(c, pts, rad, c.sides(13, 7), twist * 0.83f / (nT - 1), a0, bark, 1.f, 0.12f, 0.07f);

    // raízes saindo da base
    for (int i = 0; i < 5; i++) {
        float ra = i * TAU_F / 5.f + c.sh() * 0.6f;
        if (c.lod != 0) continue;
        float cs = std::cos(ra), sn = std::sin(ra);
        tube(c, {V(cs * 0.45f, 0.55f, sn * 0.45f), V(cs * 1.2f, 0.2f, sn * 1.2f), V(cs * 2.1f, -0.02f, sn * 2.1f), V(cs * 2.8f, -0.18f, sn * 2.8f)},
             {0.42f, 0.30f, 0.18f, 0.08f}, 7, 0.f, 0.f, bark, 1.f, 0.12f, 0.05f);
    }

    Vec3 tp = trunkPt(0.78f);
    const int nb = 4;
    Vec3 tipP[nb];
    for (int i = 0; i < nb; i++) {
        float ba = i * TAU_F / nb + c.sh() * 0.8f;
        float bt = 0.5f + c.sh() * 0.2f;
        Vec3 p0 = V(lx * bt * bt + std::cos(ba) * 0.3f, hh * bt, lz * bt * bt + std::sin(ba) * 0.3f);
        float len = 1.9f + c.sh() * 1.0f;
        Vec3 p1 = p0 + V(std::cos(ba) * len * 0.55f, 0.9f, std::sin(ba) * len * 0.55f);
        Vec3 p2 = V(p0.x + std::cos(ba) * len, p1.y + 0.9f, p0.z + std::sin(ba) * len);
        tube(c, {p0, p1, p2}, {0.26f, 0.17f, 0.10f}, c.sides(7, 4), 0.f, 0.f, bark, 1.05f, 0.08f, 0.05f);
        tipP[i] = p2;
        // galhinhos finos com bolotinha na ponta
        for (int tw = 0; tw < 2; tw++) {
            float ta = ba + (tw ? 0.9f : -0.9f) + (c.sh() - 0.5f) * 0.4f;
            Vec3 e = p1 + V(std::cos(ta) * 0.9f, 0.6f, std::sin(ta) * 0.9f);
            if (c.lod == 0) {
                tube(c, {p1, e}, {0.09f, 0.04f}, 5, 0.f, 0.f, bark, 1.05f, 0.05f, 0.f);
                leafBall(c, e + V(0, 0.25f, 0), 0.62f, 0.3f + c.dt() * 0.4f);
            }
        }
    }

    // copa: cume, anel interno, anel externo (mais baixo/escuro), pontas dos galhos
    float cy = hh * 0.70f;
    leafBall(c, V(tp.x, cy + 1.0f, tp.z), 1.4f, 0.85f + c.sh() * 0.15f);
    float off1 = c.sh() * TAU_F;
    for (int i = 0; i < 5; i++) {
        float a = off1 + i * TAU_F / 5.f;
        float dy = c.sh() * 0.6f - 0.1f;
        leafBall(c, V(tp.x + std::cos(a) * 1.8f, cy + dy, tp.z + std::sin(a) * 1.8f), 1.15f + c.sh() * 0.3f, 0.5f + dy * 0.4f + c.sh() * 0.25f);
    }
    float off2 = c.sh() * TAU_F;
    for (int i = 0; i < 5; i++) {
        float a = off2 + i * TAU_F / 5.f;
        leafBall(c, V(tp.x + std::cos(a) * 3.1f, cy - 0.9f, tp.z + std::sin(a) * 3.1f), 1.0f + c.sh() * 0.3f, 0.2f + c.sh() * 0.3f);
    }
    for (int i = 0; i < nb; i++) leafBall(c, tipP[i] + V(0, 0.5f, 0), 1.05f, 0.3f + c.sh() * 0.4f);
    // bolotas extras entre os anéis: copa mais cheia (só no LOD detalhado)
    float off3 = c.sh() * TAU_F;
    for (int i = 0; i < 6; i++) {
        float a = off3 + i * TAU_F / 6.f;
        float rr = 2.4f + c.sh() * 0.4f;
        float yy = cy + 0.2f + c.sh() * 1.0f;
        float rb = 0.9f + c.sh() * 0.25f, tt = 0.35f + c.sh() * 0.4f;
        if (c.lod == 0) leafBall(c, V(tp.x + std::cos(a) * rr, yy, tp.z + std::sin(a) * rr), rb, tt);
    }
    // moitas de folhas na base
    int nbush = 2 + c.shape.nextInt(2);
    for (int i = 0; i < nbush; i++) {
        float a = c.sh() * TAU_F, d = 1.4f + c.sh() * 0.9f;
        float rb = 0.4f + c.sh() * 0.35f, tt = 0.55f + c.sh() * 0.4f;
        leafBall(c, V(std::cos(a) * d, 0.35f, std::sin(a) * d), rb, tt);
    }
}

// =====================================================================
//  MACIEIRA: base larga e rochosa, tronco que abre em V, copa enorme irregular, ~12 maçãs  [6 m]
// =====================================================================
void buildApple(Ctx& c) {
    const float ys[5] = {-0.25f, 0.15f, 0.9f, 1.8f, 2.5f};
    const float rs[5] = {1.7f, 1.2f, 0.98f, 0.88f, 0.80f};
    float a0 = c.sh() * TAU_F;
    Col bark = bcol(0.42f, 0.27f, 0.15f);
    std::vector<Vec3> pts;
    std::vector<float> rad;
    for (int i = 0; i < 5; i++) { pts.push_back(V(0, ys[i], 0)); rad.push_back(rs[i]); }
    tube(c, pts, rad, c.sides(11, 7), 0.2f, a0, bark, 0.95f, 0.14f, 0.06f);
    for (int i = 0; i < 4; i++) {  // nós do tronco
        float sa = c.sh() * TAU_F, yy = (0.6f + c.sh() * 1.6f);
        spotOn(c.acc, V(0, yy, 0), V(std::cos(sa), 0, std::sin(sa)), 0.92f, 0.16f, bcol(0.50f, 0.33f, 0.18f));
    }
    float top = 2.5f;
    Vec3 tipP[5];
    float bo = c.sh() * TAU_F;
    for (int i = 0; i < 3; i++) {  // galhos principais em V
        float ba = bo + i * TAU_F / 3.f + (c.sh() - 0.5f) * 0.4f;
        float cs = std::cos(ba), sn = std::sin(ba);
        Vec3 s0 = V(cs * 0.35f, top - 0.1f, sn * 0.35f);
        Vec3 m = s0 + V(cs * 1.3f, 1.5f, sn * 1.3f);
        Vec3 e = s0 + V(cs * 2.4f, 2.6f, sn * 2.4f);
        tube(c, {s0, m, e}, {0.45f, 0.32f, 0.18f}, c.sides(8, 5), 0.f, 0.f, bark, 0.95f, 0.08f, 0.04f);
        tipP[i] = e;
    }
    for (int i = 0; i < 2; i++) {  // galhos laterais mais baixos
        float ba = bo + 0.9f + i * 3.1f + c.sh() * 0.5f;
        float cs = std::cos(ba), sn = std::sin(ba);
        Vec3 s0 = V(cs * 0.7f, 1.5f + c.sh() * 0.4f, sn * 0.7f);
        Vec3 e = s0 + V(cs * 2.3f, 0.9f, sn * 2.3f);
        tube(c, {s0, e}, {0.30f, 0.12f}, c.sides(7, 4), 0.f, 0.f, bark, 0.95f, 0.08f, 0.04f);
        tipP[3 + i] = e;
    }
    // copa: 1 central grande + anel de 4 + pontas dos galhos
    Vec3 cc[10];
    float cr[10];
    cc[0] = V(0, top + 2.7f, 0); cr[0] = 2.3f;
    float mo = c.sh() * TAU_F;
    for (int i = 0; i < 4; i++) {
        float a = mo + i * TAU_F / 4.f;
        cc[1 + i] = V(std::cos(a) * 2.2f, top + 2.0f, std::sin(a) * 2.2f);
        cr[1 + i] = 1.8f;
    }
    for (int i = 0; i < 3; i++) { cc[5 + i] = tipP[i] + V(0, 0.5f, 0); cr[5 + i] = 1.4f; }
    for (int i = 0; i < 2; i++) { cc[8 + i] = tipP[3 + i] + V(0, 0.3f, 0); cr[8 + i] = 0.95f; }
    Col dk = {0.06f, 0.40f, 0.13f}, lt = {0.46f, 0.60f, 0.17f};
    for (int i = 0; i < 10; i++) {
        float r = cr[i];
        blob(c.acc, c.det, cc[i], V(r * 0.92f, r * 0.85f, r * 0.92f), bcol(0.14f, 0.40f, 0.14f), 0.25f, 0, 0.12f);
        leafShell(c, cc[i], V(r * 0.98f, r * 0.92f, r * 0.98f), (int)(r * 40.f), 0.85f, 0.26f, dk, lt);
    }
    // maçãs redondas com cabinho, na superfície da copa
    for (int k = 0; k < 14; k++) {
        int i = c.shape.nextInt(8);
        float dx = c.sh() * 2.f - 1.f, dz = c.sh() * 2.f - 1.f, dy = c.sh() * 1.0f - 0.45f;
        float l = std::max(std::sqrt(dx * dx + dy * dy + dz * dz), 0.1f);
        Vec3 ap(cc[i].x + dx / l * cr[i] * 1.13f, cc[i].y + dy / l * cr[i] * 1.13f, cc[i].z + dz / l * cr[i] * 1.13f);
        fruit(c, ap, 0.23f, 0.22f, bcol(0.88f, 0.10f, 0.12f, 0.9f + c.dt() * 0.2f));
        prism(c.acc, ap + V(0, 0.2f, 0), 0.02f, ap + V(0.03f, 0.38f, 0), 0.015f, 4, bcol(0.35f, 0.22f, 0.10f));
    }
}

// =====================================================================
//  LARANJEIRA: tronco curto, MUITO grosso e retorcido, base em lobos de pedra, copa em cúpula, ~16 laranjas  [5.5 m]
// =====================================================================
void buildOrange(Ctx& c) {
    const float ys[5] = {-0.15f, 0.4f, 1.0f, 1.7f, 2.4f};
    const float rs[5] = {1.6f, 1.15f, 0.92f, 0.86f, 0.82f};
    float a0 = c.sh() * TAU_F;
    std::vector<Vec3> pts;
    std::vector<float> rad;
    for (int i = 0; i < 5; i++) { pts.push_back(V(0, ys[i], 0)); rad.push_back(rs[i]); }
    tube(c, pts, rad, c.sides(11, 6), 0.6f, a0, bcol(0.50f, 0.30f, 0.14f), 0.95f, 0.16f, 0.07f);
    for (int k = 0; k < 3; k++) {  // lobos grandes na base (como rochas)
        float a = a0 + k * 2.1f + c.sh() * 0.5f;
        float rd = 1.15f;
        blob(c.acc, c.det, V(std::cos(a) * rd, 0.25f, std::sin(a) * rd), V(0.75f, 0.55f, 0.75f), bcol(0.52f, 0.31f, 0.14f, 0.9f + c.dt() * 0.3f), 0.25f, c.lvl(), 0.15f);
    }
    for (int k = 0; k < 4; k++) {  // caroços no meio do tronco
        float a = c.sh() * TAU_F;
        float yy = 0.9f + k * 0.4f;
        blob(c.acc, c.det, V(std::cos(a) * 0.8f, yy, std::sin(a) * 0.8f), V(0.32f, 0.45f, 0.32f), bcol(0.44f, 0.26f, 0.12f, 0.9f + c.dt() * 0.3f), 0.2f, 0, 0.15f);
    }
    float ccy = 4.2f, rx = 2.7f, ry = 2.0f;
    blob(c.acc, c.det, V(0, ccy, 0), V(rx * 0.95f, ry * 0.95f, rx * 0.95f), bcol(0.12f, 0.36f, 0.14f), 0.12f, 0, 0.1f);
    leafShell(c, V(0, ccy, 0), V(rx, ry, rx), 600, 0.8f, 0.2f, {0.06f, 0.48f, 0.20f}, {0.55f, 0.86f, 0.22f}, -0.35f);
    for (int k = 0; k < 20; k++) {  // laranjas redondas na superfície
        float dx = c.sh() * 2.f - 1.f, dz = c.sh() * 2.f - 1.f, dy = c.sh() * 1.4f - 0.35f;
        float l = std::max(std::sqrt(dx * dx + dy * dy + dz * dz), 0.1f);
        fruit(c, V(dx / l * rx * 1.09f, ccy + dy / l * ry * 1.09f, dz / l * rx * 1.09f), 0.3f, 0.3f, bcol(0.97f, 0.45f, 0.08f, 0.9f + c.dt() * 0.2f));
    }
}

// =====================================================================
//  BANANEIRA: tronco reto em gomos com musgo, 8 folhas largas arqueadas, 1 cacho  [5.2 m]
// =====================================================================
void bananaLeaf(Ctx& c, Vec3 b, float a, float len, float hw, bool steep) {
    float dx = std::cos(a), dz = std::sin(a);
    float sx = -dz, sz = dx;
    float kU = steep ? 2.0f : 1.25f, droop = steep ? 1.2f : 1.35f, reach = steep ? 0.45f : 0.85f;
    float g = c.dt();
    float r = 0.28f + 0.14f * g, gg = 0.78f + 0.14f * g, bl = 0.20f;
    int n = c.lod == 0 ? 8 : 4;
    std::vector<Vec3> P(n + 1);
    std::vector<float> W(n + 1);
    for (int j = 0; j <= n; j++) {
        float u = j / (float)n;
        P[j] = V(b.x + dx * len * reach * u, b.y + len * (kU * u - droop * u * u), b.z + dz * len * reach * u);
        W[j] = hw * (0.12f + 0.88f * std::pow(std::max(0.f, std::sin(PI_F * (0.08f + 0.92f * u))), 0.65f));
    }
    Col rib = bcol(0.12f, 0.46f, 0.11f);
    for (int j = 0; j < n; j++) {
        float kk = 0.88f + 0.22f * (float)((j * 37 + (int)(g * 10.f)) % 5) / 4.f;
        Col colL = bcol(r, gg, bl, kk), colR = bcol(r, gg, bl, kk * 0.82f);
        float w0 = W[j], w1 = W[j + 1];
        Vec3 c0(P[j].x, P[j].y + 0.14f * w0, P[j].z), c1(P[j + 1].x, P[j + 1].y + 0.14f * w1, P[j + 1].z);
        Vec3 l0(P[j].x + sx * w0, P[j].y - 0.22f * w0, P[j].z + sz * w0), l1(P[j + 1].x + sx * w1, P[j + 1].y - 0.22f * w1, P[j + 1].z + sz * w1);
        Vec3 r0(P[j].x - sx * w0, l0.y, P[j].z - sz * w0), r1(P[j + 1].x - sx * w1, l1.y, P[j + 1].z - sz * w1);
        c.acc.triUp(c0, l0, l1, colL);
        c.acc.triUp(c0, l1, c1, colL);
        c.acc.triUp(c0, r0, r1, colR);
        c.acc.triUp(c0, r1, c1, colR);
        Vec3 o0(sx * 0.05f, 0.02f, sz * 0.05f);
        c.acc.triUp(c0 - V(sx * 0.05f, -0.02f, sz * 0.05f), c0 + V(sx * 0.05f, 0.02f, sz * 0.05f), c1 + V(sx * 0.05f, 0.02f, sz * 0.05f), rib);
        c.acc.triUp(c0 - V(sx * 0.05f, -0.02f, sz * 0.05f), c1 + V(sx * 0.05f, 0.02f, sz * 0.05f), c1 - V(sx * 0.05f, -0.02f, sz * 0.05f), rib);
        (void)o0;
    }
}

void bananaBunch(Ctx& c, Vec3 s0, float da) {
    Vec3 e(s0.x + std::cos(da) * 0.55f, s0.y - 1.8f, s0.z + std::sin(da) * 0.55f);
    prism(c.acc, s0, 0.06f, e, 0.05f, 4, bcol(0.22f, 0.40f, 0.10f));
    for (int h = 0; h < 3; h++) {
        float t = 0.38f + h * 0.25f;
        Vec3 cp = s0 + (e - s0) * t;
        for (int k = 0; k < 7; k++) {
            float ph = k * TAU_F / 7.f + h * 0.4f;
            Vec3 b0(cp.x + std::cos(ph) * 0.13f, cp.y - 0.3f, cp.z + std::sin(ph) * 0.13f);
            Vec3 b1(cp.x + std::cos(ph) * 0.24f, cp.y + 0.22f, cp.z + std::sin(ph) * 0.24f);
            prism(c.acc, b0, 0.035f, b1, 0.062f, c.sides(5, 3), bcol(0.60f, 0.76f, 0.19f, 0.85f + c.dt() * 0.3f));
        }
    }
}

void buildBanana(Ctx& c) {
    const float hh = 5.2f, rBase = 0.36f, rTop = 0.27f;
    int nseg = std::max(6, (int)(hh / 0.62f));
    for (int i = 0; i < nseg; i++) {
        float t0 = i / (float)nseg, t1 = (i + 1) / (float)nseg;
        float r0 = (rBase + (rTop - rBase) * t0) * 0.86f, r1 = (rBase + (rTop - rBase) * t1) * 1.03f;
        float y0 = hh * t0 - (i == 0 ? 0.2f : 0.f), y1 = hh * t1;
        tube(c, {V(0, y0, 0), V(0, y1, 0)}, {r0, r1}, c.sides(11, 7), 0.f, i * 0.4f, bcol(0.53f, 0.42f, 0.32f), 1.f, 0.08f, 0.03f);
        int ns = 3 + (int)(c.dt() * 2.f);
        for (int k = 0; k < ns; k++) {
            float sa = c.dt() * TAU_F, tt = 0.12f + c.dt() * 0.76f;
            float rr = r0 + (r1 - r0) * tt;
            spotOn(c.acc, V(0, y0 + (y1 - y0) * tt, 0), V(std::cos(sa), 0, std::sin(sa)), rr + 0.02f, 0.12f + c.dt() * 0.14f,
                   bcol(0.30f, 0.42f, 0.10f, 0.8f + c.dt() * 0.4f));
        }
    }
    int nl = 8;
    float off = c.sh() * TAU_F;
    for (int i = 0; i < nl; i++) {
        float a = off + i * TAU_F / nl + (c.sh() - 0.5f) * 0.3f;
        bananaLeaf(c, V(0, hh + 0.05f, 0), a, 3.0f + c.sh() * 0.6f, 0.68f + c.sh() * 0.15f, i % 4 == 0);
    }
    float da = c.sh() * TAU_F;
    if (c.sh() < 0.9f) bananaBunch(c, V(0, hh - 0.15f, 0), da);
}

// =====================================================================
//  COQUEIROS: 70% retos (tronco fino alto em anéis, manchas pretas, folhas-pena longas) e 30% tortos (grosso, curvo, folíolos largos)
// =====================================================================
void frond(Ctx& c, Vec3 b, float a, float len, bool steep, bool curved) {
    float dx = std::cos(a), dz = std::sin(a);
    float sx = -dz, sz = dx;
    float kU = steep ? 1.7f : (curved ? 0.95f : 0.8f);
    float reach = steep ? 0.5f : 1.f;
    float droop = curved ? 1.0f : 1.1f;
    float gr = c.dt();
    float baseR = curved ? 0.18f + 0.30f * gr : 0.08f + 0.12f * gr;
    float baseG = curved ? 0.62f + 0.22f * gr : 0.50f + 0.22f * gr;
    float baseB = curved ? 0.14f + 0.08f * gr : 0.08f + 0.06f * gr;
    Col rachis = curved ? bcol(0.12f, 0.50f, 0.12f) : bcol(0.14f, 0.62f, 0.14f);
    float rw = curved ? 0.055f : 0.10f;
    auto P = [&](float u) { return V(b.x + dx * len * reach * u, b.y + len * (kU * u - droop * u * u), b.z + dz * len * reach * u); };

    int n = c.lod == 0 ? 9 : 5;
    for (int j = 0; j < n; j++) {
        float u0 = j / (float)n, u1 = (j + 1) / (float)n;
        Vec3 p0 = P(u0), p1 = P(u1);
        float w0 = rw * (1.f - 0.5f * u0), w1 = rw * (1.f - 0.5f * u1);
        Vec3 s(sx, 0, sz);
        c.acc.triUp(p0 - s * w0, p0 + s * w0, p1 + s * w1, rachis);
        c.acc.triUp(p0 - s * w0, p1 + s * w1, p1 - s * w1, rachis);
    }
    int m = curved ? (c.lod == 0 ? 15 : 7) : (c.lod == 0 ? 28 : 11);
    float wide = c.lod == 0 ? 1.f : 1.5f;
    for (int j = 0; j < m; j++) {
        float u = 0.12f + 0.86f * j / (float)(m - 1);
        Vec3 p = P(u);
        Vec3 T = V(dx * len * reach, len * (kU - 2.f * droop * u), dz * len * reach).nor();
        float ll = curved ? 0.95f * (1.f - 0.5f * u) + 0.3f : 1.55f * (1.f - 0.55f * u) + 0.25f;
        float dn = steep ? 0.12f : (curved ? 0.30f : 0.50f);
        for (int side = -1; side <= 1; side += 2) {
            float k = 0.85f + c.dt() * 0.3f;
            float tint = curved ? 0.8f + 0.5f * u : 1.f;
            Col col = bcol(baseR * tint, baseG * (0.9f + 0.1f * tint), baseB, k);
            float spread = curved ? 0.85f : 0.72f;
            Vec3 tip(p.x + sx * side * ll * spread + T.x * ll * (curved ? 0.5f : 0.38f), p.y + T.y * ll * 0.4f - ll * dn,
                     p.z + sz * side * ll * spread + T.z * ll * (curved ? 0.5f : 0.38f));
            if (curved) {
                Vec3 mid = p + (tip - p) * 0.5f;
                float wd = (0.14f + 0.12f * (1.f - u)) * wide;
                c.acc.triUp(p, mid + T * wd, tip, col);
                c.acc.triUp(p, tip, mid - T * wd, col);
            } else {
                float w0 = 0.06f * wide, w1 = 0.04f * wide;
                c.acc.triUp(p + T * w0, p - T * w0, tip - T * w1, col);
                c.acc.triUp(p + T * w0, tip - T * w1, tip + T * w1, col);
            }
        }
    }
}

void buildPalm(Ctx& c, bool curved) {
    float hh = curved ? 10.f * 0.85f : 10.f;
    float lean = curved ? 2.6f + c.sh() * 1.6f : (c.sh() - 0.5f) * 0.5f;
    float ang = c.sh() * TAU_F;
    float lx = std::cos(ang) * lean, lz = std::sin(ang) * lean;
    float rBase = curved ? 0.50f : 0.32f, rTop = curved ? 0.34f : 0.20f;
    int sides = c.sides(10, 6);
    int nseg = std::max(8, (int)(hh / (curved ? 0.72f : 0.62f)));
    Col spotCol = curved ? bcol(0.33f, 0.19f, 0.10f) : bcol(0.07f, 0.05f, 0.04f);
    for (int i = 0; i < nseg; i++) {
        float t0 = i / (float)nseg, t1 = (i + 1) / (float)nseg;
        float r0 = (rBase + (rTop - rBase) * t0) * 0.85f, r1 = (rBase + (rTop - rBase) * t1) * 1.04f;
        Vec3 p0(lx * t0 * t0, hh * t0 - (i == 0 ? 0.2f : 0.f), lz * t0 * t0);
        Vec3 p1(lx * t1 * t1, hh * t1, lz * t1 * t1);
        tube(c, {p0, p1}, {r0, r1}, sides, 0.f, i * 0.35f, bcol(0.47f, 0.32f, 0.19f), 1.f, 0.07f, 0.04f);
        int ns = curved ? 1 + (int)(c.dt() * 2.f) : 2 + (int)(c.dt() * 2.f);
        for (int k = 0; k < ns; k++) {
            float sa = c.dt() * TAU_F, tt = 0.2f + c.dt() * 0.6f;
            Vec3 cs = p0 + (p1 - p0) * tt;
            float rr = r0 + (r1 - r0) * tt;
            float big = curved ? 0.12f + c.dt() * 0.10f : 0.05f + c.dt() * 0.11f * (1.f - 0.6f * t0);
            spotOn(c.acc, cs, V(std::cos(sa), 0, std::sin(sa)), rr + 0.02f, big, spotCol);
        }
    }
    Vec3 top(lx, hh, lz);
    int nf = curved ? 8 : 10;
    float off = c.sh() * TAU_F;
    for (int i = 0; i < nf; i++) {
        float a = off + i * TAU_F / nf + (c.sh() - 0.5f) * 0.3f;
        float len = curved ? 3.6f + c.sh() * 0.7f : 4.2f + c.sh() * 0.9f;
        frond(c, top + V(0, 0.1f, 0), a, len, i % 4 == 0, curved);
    }
    float cr = curved ? 0.38f : 0.28f;
    int nc = 4 + c.shape.nextInt(2);
    for (int k = 0; k < nc; k++) {
        float ca = c.sh() * TAU_F, rd = 0.5f + c.sh() * 0.5f;
        float cyo = 0.35f + c.sh() * 0.5f;
        Vec3 cp(top.x + std::cos(ca) * rd, top.y - cyo, top.z + std::sin(ca) * rd);
        fruit(c, cp, cr, cr * 1.15f, bcol(0.50f, 0.32f, 0.17f, 0.9f + c.dt() * 0.25f));
        if (curved)
            for (int s = 0; s < 2; s++) {
                float sa = c.dt() * TAU_F;
                spotOn(c.acc, cp, V(std::cos(sa) * 0.9f, 0.3f, std::sin(sa) * 0.9f).nor(), cr * 0.95f, 0.07f, bcol(0.30f, 0.17f, 0.08f));
            }
    }
}

}  // namespace

void buildTree(MeshAccum& acc, int species, int variant, int lod) {
    int64_t seed = 7919LL * (species + 1) + 104729LL * (variant + 1) + 13LL;
    Ctx c(acc, seed, lod);
    switch (species) {
        case SP_BIG: buildBig(c); break;
        case SP_APPLE: buildApple(c); break;
        case SP_ORANGE: buildOrange(c); break;
        case SP_BANANA: buildBanana(c); break;
        case SP_PALM: buildPalm(c, false); break;
        case SP_PALMC: buildPalm(c, true); break;
        default: break;
    }
}

TreeLib::TreeLib() {
    for (int sp = 0; sp < SP_COUNT; sp++) {
        meshes_[sp].resize(TREE_VARIANTS[sp]);
        for (int v = 0; v < TREE_VARIANTS[sp]; v++)
            for (int l = 0; l < 2; l++) {
                MeshAccum acc;
                buildTree(acc, sp, v, l);
                meshes_[sp][v].lod[l] = std::move(acc.v);
            }
    }
}
