// Lógica de jogo sem gráficos: colisão de troncos, boneco (física), ciclo dia/noite e malhas de píer/ponte/boneco.
#pragma once
#include <unordered_map>
#include <vector>
#include "JavaRandom.h"
#include "MeshAccum.h"
#include "World.h"

/** Círculos de colisão (troncos e pedras) por chunk de vegetação: x, z, raio. */
class SolidMap {
public:
    void set(int key, std::vector<float> s) { m_[key] = std::move(s); }
    void remove(int key) { m_.erase(key); }
    /** Empurra (x,z) para fora de qualquer tronco/pedra a menos de `pr` metros. Duas passadas para não prender entre duas árvores. */
    void pushOut(float* xz, float pr) const;

private:
    std::unordered_map<int, std::vector<float>> m_;
};

/** Boneco de 1.75 m - a régua de todo o mapa. */
class Player {
public:
    Vec3 pos;
    float heading = 0.f;  // graus
    bool grounded = true;

    void place(float x, float z, float headingDeg);
    void move(float dx, float dz, float dt, float speed, const SolidMap& solids);
    void jump();
    void physics(float dt);

private:
    float vy_ = 0.f;
    bool attempt(float tx, float tz, const SolidMap& solids);
};

/** Ciclo de 24 h do jogo em Cfg::DAY_SECONDS: amanhecer, dia, pôr do sol, noite. Mesmas cores do Sky.kt. */
struct Meteor {
    Vec3 d0, tv;
    float speed, life, age = 0.f;
};

class SkyState {
public:
    float tod = Cfg::START_HOUR;
    Vec3 toSun{1, 0.3f, -0.28f}, toMoon, toLight;
    float sunE = 0.3f;
    Col top, hor, fog, ambient, lightC;
    std::vector<Meteor> meteors;

    SkyState();
    void update(float dt, float camAz);
    float nightK() const { return 1.f - smooth(-0.22f, 0.f, sunE); }

private:
    JRandom rnd_{42};
    float meteorTimer_ = 14.f;
    void recompute();
};

namespace Props {
MeshAccum pier();    // +Z = rumo ao mar, origem na linha da costa
MeshAccum bridge();  // +Z = ao longo da ponte, origem no centro do deck (y=0 = topo)
MeshAccum player();  // boneco, pés em y=0
Mat4 pierTransform();
Mat4 bridgeTransform();
}  // namespace Props
