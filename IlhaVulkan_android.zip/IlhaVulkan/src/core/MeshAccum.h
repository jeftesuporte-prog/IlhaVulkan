// Acumula triângulos "soltos" (3 vértices por triângulo => flat shading low-poly), igual ao MeshAccum.kt.
// Vértice de 28 bytes: posição | normal (snorm8x4) | cor (unorm8x4) | uv.
#pragma once
#include <cstdint>
#include <vector>
#include "Math.h"
#include "World.h"

struct Vtx {
    float x, y, z;
    uint32_t n;
    uint32_t c;
    float u, v;
};
static_assert(sizeof(Vtx) == 28, "Vtx deve ter 28 bytes");

inline uint32_t packN(const Vec3& n) {
    auto q = [](float f) { return (uint32_t)(int8_t)std::lround(clampf(f, -1.f, 1.f) * 127.f) & 0xFFu; };
    return q(n.x) | (q(n.y) << 8) | (q(n.z) << 16);
}
inline uint32_t packC(float r, float g, float b) {
    auto q = [](float f) { return (uint32_t)std::lround(clampf(f, 0.f, 1.f) * 255.f) & 0xFFu; };
    return q(r) | (q(g) << 8) | (q(b) << 16) | (255u << 24);
}
inline uint32_t packC(const Col& c) { return packC(c.r, c.g, c.b); }

class MeshAccum {
public:
    std::vector<Vtx> v;

    void put(const Vec3& p, uint32_t n, uint32_t c, float u = 0.f, float vv = 0.f) { v.push_back({p.x, p.y, p.z, n, c, u, vv}); }

    /** Triângulo com normal explícita. */
    void triN(const Vec3& a, const Vec3& b, const Vec3& c, const Vec3& n, const Col& col) {
        uint32_t pn = packN(n), pc = packC(col);
        put(a, pn, pc); put(b, pn, pc); put(c, pn, pc);
    }

    /** Normal pelo sentido dos vértices. */
    void tri(const Vec3& a, const Vec3& b, const Vec3& c, const Col& col) {
        Vec3 n = (b - a).cross(c - a);
        if (n.len() < 1e-9f) return;
        triN(a, b, c, n.nor(), col);
    }

    /** Normal apontando "para fora" do ponto o - independe do sentido dos vértices. uv=true gera UV de pedra (relativo a o). */
    void triOut(const Vec3& a, const Vec3& b, const Vec3& c, const Vec3& o, const Col& col, bool uv = false) {
        Vec3 n = (b - a).cross(c - a);
        float l = n.len();
        if (l < 1e-9f) return;
        n = n * (1.f / l);
        Vec3 m = (a + b + c) * (1.f / 3.f) - o;
        if (n.dot(m) < 0.f) n = n * -1.f;
        uint32_t pn = packN(n), pc = packC(col);
        const float k = 0.35f, ky = 0.2f;
        auto U = [&](const Vec3& p) { return uv ? (p.x - o.x) * k + (p.y - o.y) * ky : 0.f; };
        auto V = [&](const Vec3& p) { return uv ? (p.z - o.z) * k + (p.y - o.y) * ky : 0.f; };
        put(a, pn, pc, U(a), V(a)); put(b, pn, pc, U(b), V(b)); put(c, pn, pc, U(c), V(c));
    }

    /** Normal sempre para cima (folhas iluminadas dos dois lados). */
    void triUp(const Vec3& a, const Vec3& b, const Vec3& c, const Col& col) {
        Vec3 n = (b - a).cross(c - a);
        float l = n.len();
        if (l < 1e-9f) return;
        n = n * (1.f / l);
        if (n.y < 0.f) n = n * -1.f;
        triN(a, b, c, n, col);
    }

    /** Triângulo do terreno: normal chapada, UMA cor por vértice (degradê suave) e UV de textura. */
    void triVC(const Vec3& a, uint32_t ca, float ua, float va, const Vec3& b, uint32_t cb, float ub, float vb,
               const Vec3& c, uint32_t cc, float uc, float vc, const Vec3& n) {
        uint32_t pn = packN(n);
        put(a, pn, ca, ua, va); put(b, pn, cb, ub, vb); put(c, pn, cc, uc, vc);
    }
};
