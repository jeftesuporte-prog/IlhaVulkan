// Texturas procedurais tileáveis (sem arquivo de imagem). Mesma receita do TexGen.kt, agora em 512x512 (original: 256).
#pragma once
#include <cstdint>
#include <vector>

namespace TexGen {
constexpr int S = 512;

struct Image {
    int w = 0, h = 0;
    std::vector<uint8_t> rgba;
};

Image grass();
Image rock(bool moss);
Image sand();
Image forest();
Image water();    // 256x256, mar turquesa #00BFFF com ondas brancas
Image glitter();  // 64x256, faixa de brilhos do sol/lua na água

/** Cadeia de mipmaps (filtro de caixa), do nível 0 (original) até 1x1. */
std::vector<Image> mipChain(const Image& base);
}  // namespace TexGen
