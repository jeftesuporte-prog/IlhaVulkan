#include "World.h"

#include <memory>
#include <unordered_map>

#include "Simplex.h"

static std::unique_ptr<SimplexNoise> g_noise;

// =====================================================================
//  Base: forma da ilha + altura "crua"
// =====================================================================
namespace Base {
std::vector<Peak> peaks;

float n(float x, float z) { return g_noise->noise((double)x, (double)z); }

float shape(float x, float z) {
    float w = n(x * 0.0035f, z * 0.0035f) * 0.075f + n(x * 0.011f + 40.f, z * 0.011f) * 0.025f;
    float nx = x / Cfg::A;
    float nz = z / Cfg::B;
    return std::sqrt(nx * nx + nz * nz) * (1.f + w);
}

float depth(float x, float z) {
    float s = shape(x, z);
    float gx = x / (Cfg::A * Cfg::A);
    float gz = z / (Cfg::B * Cfg::B);
    float nx = x / Cfg::A;
    float nz = z / Cfg::B;
    float r0 = std::sqrt(nx * nx + nz * nz);
    float m = r0 > 1e-3f ? std::sqrt(gx * gx + gz * gz) / r0 : 1.f / Cfg::B;
    return (1.f - s) / std::max(m, 1e-4f);
}

float orchard(float x, float z) {
    float dx = x - Cfg::ORCHARD_X;
    float dz = z - Cfg::ORCHARD_Z;
    return 1.f - smooth(Cfg::ORCHARD_R * 0.7f, Cfg::ORCHARD_R, std::sqrt(dx * dx + dz * dz));
}

float grove(float x, float z) {
    float dx = x - Cfg::GROVE_X;
    float dz = z - Cfg::GROVE_Z;
    return 1.f - smooth(Cfg::GROVE_R * 0.7f, Cfg::GROVE_R, std::sqrt(dx * dx + dz * dz));
}

float forestW(float x, float z, float d, float h) {
    if (d <= 0.f) return 0.f;
    float inland = smooth(Cfg::BEACH + 6.f, Cfg::BEACH + 30.f, d);
    float alt = 1.f - smooth(35.f, 60.f, h);
    float clump = smooth(-0.5f, 0.f, n(x * 0.010f + 11.f, z * 0.010f - 4.f));
    return inland * alt * clump * (1.f - std::max(grove(x, z), orchard(x, z)));
}

float baseHeight(float x, float z) {
    float d = depth(x, z);
    if (d <= 0.f) return std::max(-14.f, d * 0.12f);

    float beach = d * 0.03f;
    float land = std::max(1.f, 2.5f + 2.5f * n(x * 0.012f, z * 0.012f) + 1.2f * n(x * 0.04f, z * 0.04f));
    float w = smooth(Cfg::BEACH - 10.f, Cfg::BEACH + 20.f, d);
    float h = beach + (land - beach) * w;

    float m = 0.f;
    for (const Peak& p : peaks) {
        float dx = x - p.x;
        float dz = z - p.z;
        float warp = 1.f + 0.16f * n(x * 0.008f + p.x, z * 0.008f + p.z);
        float rr = std::sqrt(dx * dx + dz * dz) * warp;
        float t = clampf(1.f - rr / p.r, 0.f, 1.f);
        if (t > 0.f) {
            float prof = std::pow(t, 1.35f);
            float crag = 1.f - std::fabs(n(x * 0.03f + p.x, z * 0.03f + p.z));
            float hm = p.h * 0.95f * prof + crag * p.h * 0.05f * std::sqrt(prof);
            if (hm > m) m = hm;
        }
    }
    return h + m;
}
}  // namespace Base

// =====================================================================
//  Estrada
// =====================================================================
namespace RoadNet {
float shoreX, shoreZ, startX, startZ, bridgeX, bridgeZ, bridgeTX, bridgeTZ;
static std::vector<float> xs, zs, hs;
static std::unordered_map<int, std::vector<int>> grid;

static int key(int i, int j) { return (i + 200) * 1000 + (j + 200); }

static float cr(float a, float b, float c, float d, float t) {
    float t2 = t * t;
    float t3 = t2 * t;
    return 0.5f * ((2.f * b) + (-a + c) * t + (2.f * a - 5.f * b + 4.f * c - d) * t2 + (-a + 3.f * b - 3.f * c + d) * t3);
}

void init() {
    xs.clear(); zs.clear(); hs.clear(); grid.clear();
    // 1) acha a costa na direção do píer
    float t = 0.f;
    while (t < 800.f && Base::depth(dirX * t, dirZ * t) > 0.f) t += 1.f;
    shoreX = dirX * t;
    shoreZ = dirZ * t;
    startX = shoreX - dirX * 12.f;
    startZ = shoreZ - dirZ * 12.f;

    // 2) pontos de controle
    std::vector<std::pair<float, float>> ctrl;
    ctrl.push_back({startX, startZ});
    float th0 = std::atan2(dirZ, dirX);
    float r0 = 148.f;
    float ex = r0 * std::cos(th0);
    float ez = r0 * std::sin(th0);
    float fx = ex - startX;
    float fz = ez - startZ;
    float fl = std::sqrt(fx * fx + fz * fz);
    float px = -fz / fl;
    float pz = fx / fl;
    const int nf = 12;
    for (int i = 1; i < nf; i++) {  // trecho sinuoso pela floresta
        float u = i / (float)nf;
        float off = 45.f * std::sin(u * 6.9f) * std::sin(u * 3.14159f);
        ctrl.push_back({startX + fx * u + px * off, startZ + fz * u + pz * off});
    }
    const int steps = 72;  // espiral subindo a montanha (2.6 voltas)
    const float turns = 2.6f;
    for (int i = 0; i <= steps; i++) {
        float u = i / (float)steps;
        float ang = th0 + u * turns * 6.2831855f;
        float r = 148.f + (14.f - 148.f) * u + 5.f * std::sin(u * 17.f);
        ctrl.push_back({r * std::cos(ang), r * std::sin(ang)});
    }

    // 3) Catmull-Rom a cada ~2.5 m
    std::vector<float> sx, sz;
    int forestEnd = 0;
    int cn = (int)ctrl.size();
    for (int i = 0; i < cn - 1; i++) {
        auto& p0 = ctrl[std::max(i - 1, 0)];
        auto& p1 = ctrl[i];
        auto& p2 = ctrl[i + 1];
        auto& p3 = ctrl[std::min(i + 2, cn - 1)];
        float len = std::hypot(p2.first - p1.first, p2.second - p1.second);
        int st = std::max(2, (int)(len / 2.5f));
        for (int s = 0; s < st; s++) {
            float tt = s / (float)st;
            sx.push_back(cr(p0.first, p1.first, p2.first, p3.first, tt));
            sz.push_back(cr(p0.second, p1.second, p2.second, p3.second, tt));
        }
        if (i == nf - 1) forestEnd = (int)sx.size();
    }
    sx.push_back(ctrl.back().first);
    sz.push_back(ctrl.back().second);
    int n = (int)sx.size();
    std::vector<float> lx = sx, lz = sz, h(n);
    for (int i = 0; i < n; i++) h[i] = Base::baseHeight(lx[i], lz[i]);

    // 4) suaviza a altura ao longo da estrada (rampa contínua, sem degraus)
    for (int rep = 0; rep < 4; rep++) {
        std::vector<float> tmp = h;
        for (int i = 0; i < n; i++) {
            float s = 0.f;
            int c = 0;
            for (int k = -5; k <= 5; k++) {
                int j = i + k;
                if (j >= 0 && j < n) { s += tmp[j]; c++; }
            }
            h[i] = s / c;
        }
    }
    xs = lx; zs = lz; hs = h;

    // ponte: no meio do trecho de floresta da estrada
    int bi = std::min(std::max(forestEnd / 2, 4), n - 5);
    bridgeX = lx[bi];
    bridgeZ = lz[bi];
    float btx = lx[bi + 3] - lx[bi - 3];
    float btz = lz[bi + 3] - lz[bi - 3];
    float bl = std::sqrt(btx * btx + btz * btz);
    bridgeTX = btx / bl;
    bridgeTZ = btz / bl;

    // 5) grade espacial p/ consulta rápida
    for (int i = 0; i < n; i++) {
        grid[key((int)std::floor(lx[i] / 16.f), (int)std::floor(lz[i] / 16.f))].push_back(i);
    }
}

void query(float x, float z, float* out) {
    float best = 1e9f;
    float bh = 0.f;
    int ci = (int)std::floor(x / 16.f);
    int cj = (int)std::floor(z / 16.f);
    int total = (int)xs.size();
    for (int i = ci - 1; i <= ci + 1; i++)
        for (int j = cj - 1; j <= cj + 1; j++) {
            auto it = grid.find(key(i, j));
            if (it == grid.end()) continue;
            for (int idx : it->second) {
                float ax = xs[idx];
                float az = zs[idx];
                if (idx >= total - 1) {
                    float d = std::hypot(x - ax, z - az);
                    if (d < best) { best = d; bh = hs[idx]; }
                    continue;
                }
                float bx = xs[idx + 1];
                float bz = zs[idx + 1];
                float vx = bx - ax;
                float vz = bz - az;
                float l2 = vx * vx + vz * vz;
                float u = l2 > 1e-6f ? ((x - ax) * vx + (z - az) * vz) / l2 : 0.f;
                u = clampf(u, 0.f, 1.f);
                float d = std::hypot(x - (ax + vx * u), z - (az + vz * u));
                if (d < best) { best = d; bh = hs[idx] + (hs[idx + 1] - hs[idx]) * u; }
            }
        }
    out[0] = best;
    out[1] = bh;
}

bool nearPier(float x, float z) {
    float rx = x - shoreX;
    float rz = z - shoreZ;
    float along = rx * dirX + rz * dirZ;
    float across = std::fabs(-rx * dirZ + rz * dirX);
    return along > -14.f && along < 36.f && across < 6.f;
}
}  // namespace RoadNet

// =====================================================================
//  Rio / Ponte / Píer
// =====================================================================
namespace River {
static constexpr float AMP = 16.f;
static constexpr float K = 0.03f;

float dist(float x, float z) {
    float tx = RoadNet::bridgeTX, tz = RoadNet::bridgeTZ;
    float rx = x - RoadNet::bridgeX;
    float rz = z - RoadNet::bridgeZ;
    float s = -rx * tz + rz * tx;  // posição ao longo do rio (perpendicular à estrada)
    float t = rx * tx + rz * tz;   // posição ao longo da estrada
    float off = AMP * (1.f - std::cos(K * s));
    float slope = AMP * K * std::sin(K * s);
    return std::fabs(t - off) / std::sqrt(1.f + slope * slope);
}

float w2d(float x, float z) { return 1.f - smooth(Cfg::RIVER_HALF, Cfg::RIVER_HALF + Cfg::RIVER_BANK, dist(x, z)); }
}  // namespace River

namespace Bridge {
float x, z, dx, dz, deckY;
}

namespace Pier {
float along(float x, float z) { return (x - RoadNet::shoreX) * RoadNet::dirX + (z - RoadNet::shoreZ) * RoadNet::dirZ; }
float across(float x, float z) { return -(x - RoadNet::shoreX) * RoadNet::dirZ + (z - RoadNet::shoreZ) * RoadNet::dirX; }
bool onDeck(float x, float z) {
    float a = along(x, z);
    return a >= -8.f && a <= 30.f && std::fabs(across(x, z)) <= HALF_W;
}
}  // namespace Pier

// =====================================================================
//  World
// =====================================================================
namespace World {

void init() {
    g_noise = std::make_unique<SimplexNoise>(Cfg::SEED);
    Base::peaks = {
        {0.f, 0.f, Cfg::MAIN_H, Cfg::MAIN_R},  // montanha principal no centro
        {-250.f, -150.f, 85.f, 75.f},
        {280.f, 140.f, 90.f, 75.f},
        {-30.f, -250.f, 75.f, 65.f},
        // removidas: a menor virou o bananal e a seguinte virou o pomar
    };
    RoadNet::init();
    Bridge::x = RoadNet::bridgeX;
    Bridge::z = RoadNet::bridgeZ;
    Bridge::dx = RoadNet::bridgeTX;
    Bridge::dz = RoadNet::bridgeTZ;
    float q[2];
    RoadNet::query(Bridge::x, Bridge::z, q);
    Bridge::deckY = q[1] + 0.2f;
}

float heightAt(float x, float z) {
    float b = Base::baseHeight(x, z);
    float q[2];
    RoadNet::query(x, z, q);
    float rd = q[0];
    float outer = Cfg::ROAD_W * 1.6f;
    float h = b;
    if (rd < outer) {
        float w = 1.f - smooth(Cfg::ROAD_W * 0.5f, outer, rd);
        h = b + (q[1] - b) * w;
    }
    float rw = River::w2d(x, z);
    if (rw > 0.f) {
        float d = Base::depth(x, z);
        if (d > 0.f) {
            float wf = rw * (1.f - smooth(8.f, 16.f, b));
            float bed = Cfg::RIVER_BED * smooth(0.f, 6.f, d);
            if (bed < h) h += (bed - h) * wf;
        }
    }
    return h;
}

float groundAt(float x, float z) {
    if (Bridge::onDeck(x, z)) return Bridge::deckY;
    if (Pier::onDeck(x, z)) return Pier::TOP;
    return heightAt(x, z);
}

bool onDeck(float x, float z) { return Bridge::onDeck(x, z) || Pier::onDeck(x, z); }
bool inRiver(float x, float z) { return River::w2d(x, z) > 0.3f; }

bool reserved(float x, float z) {
    if (RoadNet::nearPier(x, z)) return true;
    if (River::dist(x, z) < Cfg::RIVER_HALF + Cfg::RIVER_BANK + 1.5f) return true;
    return std::fabs(Bridge::along(x, z)) < Cfg::BRIDGE_HALF_LEN + 5.f && std::fabs(Bridge::across(x, z)) < 7.f;
}

void sample(float x, float z, float h, float ny, float* o, int k) {
    float d = Base::depth(x, z);
    o[k + 9] = d;
    if (d <= 0.f) {  // fundo do mar: areia que escurece e azula com a profundidade
        float df = smooth(0.f, 16.f, -d);
        o[k] = 0.95f - 0.50f * df;
        o[k + 1] = 0.97f - 0.28f * df;
        o[k + 2] = 1.f - 0.10f * df;
        for (int i = 3; i <= 8; i++) o[k + i] = 0.f;
        return;
    }
    float rv = River::w2d(x, z) * (1.f - smooth(8.f, 16.f, h));

    float steep = 1.f - smooth(0.62f, 0.86f, ny);
    float high = smooth(40.f, 95.f, h);
    float rock = std::max(steep, high) * (1.f - smooth(0.f, 0.25f, rv));
    float mossTop = smooth(150.f, 190.f, h) * (0.55f + 0.45f * smooth(0.4f, 0.8f, ny));
    float mossPatch = smooth(0.2f, 0.5f, Base::n(x * 0.045f - 31.f, z * 0.045f + 5.f)) * smooth(30.f, 90.f, h) * 0.9f;
    float moss = std::max(mossTop, mossPatch);

    float sandW = std::max(1.f - smooth(Cfg::BEACH - 4.f, Cfg::BEACH + 6.f, d), smooth(0.f, 0.15f, rv));
    float fw = Base::forestW(x, z, d, h);

    float q[2];
    RoadNet::query(x, z, q);
    float half = Cfg::ROAD_W * 0.5f;
    float road = (1.f - smooth(half - 0.3f, half + 0.8f, q[0])) * (1.f - smooth(0.1f, 0.4f, rv));

    float wetK = std::max(1.f - smooth(0.f, 7.f, d), smooth(0.f, 0.2f, rv)) * 0.9f;
    float sn = 0.97f + 0.03f * Base::n(x * 0.1f, z * 0.1f);
    float sandR = (1.f - 0.30f * wetK) * sn;
    float sandG = (1.f - 0.36f * wetK) * sn;
    float sandB = (1.f - 0.46f * wetK) * sn;
    float grassT = (0.84f + 0.16f * (0.5f + 0.5f * Base::n(x * 0.035f + 5.f, z * 0.035f))) * (1.f - 0.12f * fw);
    float forestT = 0.74f + 0.26f * (0.5f + 0.5f * Base::n(x * 0.05f + 9.f, z * 0.05f));
    float rockT = 0.66f + 0.34f * smooth(5.f, 190.f, h) + 0.05f * Base::n(x * 0.08f + 13.f, z * 0.08f);

    float w1 = 1.f - rock;
    float wS = w1 * sandW;
    float wRest = w1 * (1.f - sandW);
    float wF = wRest * fw;
    float wG = wRest - wF;
    float r = rock * rockT + wS * sandR + wF * forestT + wG * grassT;
    float g = rock * rockT + wS * sandG + wF * forestT + wG * grassT;
    float b = rock * rockT + wS * sandB + wF * forestT + wG * grassT;
    r += (1.f - r) * road * 0.95f;
    g += (1.f - g) * road * 0.95f;
    b += (1.f - b) * road * 0.95f;
    o[k] = std::min(1.f, r);
    o[k + 1] = std::min(1.f, g);
    o[k + 2] = std::min(1.f, b);
    o[k + 3] = rock;
    o[k + 4] = moss;
    o[k + 5] = wS;
    o[k + 6] = fw;
    o[k + 7] = road;
    o[k + 8] = rv;
}
}  // namespace World
