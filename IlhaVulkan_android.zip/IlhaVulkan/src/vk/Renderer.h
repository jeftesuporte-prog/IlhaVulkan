// Renderizador Vulkan: swapchain + MSAA, mapa de sombras, céu procedural, terreno/vegetação por chunks,
// árvores instanciadas com 2 LODs, água, espuma e brilho do sol/lua.
#pragma once
#include <vulkan/vulkan.h>

#include <algorithm>
#include <array>
#include <string>
#include <unordered_map>
#include <vector>

#include "../core/ChunkBuilder.h"
#include "../core/Game.h"
#include "../core/Math.h"
#include "../core/TexGen.h"
#include "../core/Trees.h"

#ifdef __ANDROID__
struct ANativeWindow;
struct AAssetManager;
using NativeWin = ANativeWindow;
#else
struct GLFWwindow;
using NativeWin = GLFWwindow;
#endif

struct GpuBuffer {
    VkBuffer buf = VK_NULL_HANDLE;
    VkDeviceMemory mem = VK_NULL_HANDLE;
    VkDeviceSize size = 0;
};

struct GpuImage {
    VkImage image = VK_NULL_HANDLE;
    VkDeviceMemory mem = VK_NULL_HANDLE;
    VkImageView view = VK_NULL_HANDLE;
};

/** Forma 2D do HUD de toque (disco ou anel) em coordenadas NDC (-1..1, y para baixo). */
struct HudShape {
    float cx, cy, rx, ry;  // centro e raios (NDC)
    float r, g, b, a;
    bool ring;
};

struct FrameParams {
    Mat4 view, proj;
    Vec3 camPos;
    Vec3 playerPos;
    float playerHeadingDeg = 0.f;
    float time = 0.f;
    const SkyState* sky = nullptr;
    std::vector<HudShape> hud;  // desenhado por cima de tudo (vazio no desktop)
};

struct RenderStats {
    int terrainChunks = 0, decoChunks = 0, drawnTreeInstances = 0;
};

class Renderer {
public:
    bool init(NativeWin* window, const std::string& shaderDir);
    void shutdown();
#ifdef __ANDROID__
    /** Os shaders (.spv) são lidos dos assets do APK. */
    static void setAssetManager(AAssetManager* am);
    /** Janela destruída (app em segundo plano): libera swapchain e surface, mantém todo o resto na GPU. */
    void releaseSurface();
    /** Nova janela (app voltou): recria surface + swapchain. */
    bool attachSurface(NativeWin* window);
    bool hasSurface() const { return surf_ != VK_NULL_HANDLE; }
#endif
    uint32_t width() const { return extent_.width; }
    uint32_t height() const { return extent_.height; }

    /** Envia ao GPU o que é fixo: texturas, árvores (todas as variantes/LODs), píer, ponte, boneco, mar, espuma. */
    void uploadStatic(const TreeLib& trees, const std::vector<TexGen::Image>& terrainTex /*6 camadas*/, const TexGen::Image& water,
                      const TexGen::Image& glitter);

    void addChunk(const Built& b);
    void removeChunk(int layer, int key);
    bool hasChunk(int layer, int key) const { return chunks_[layer].count(key) != 0; }

    /** Desenha um quadro. Retorna false em erro fatal. */
    bool drawFrame(const FrameParams& fp);
    float aspect() const { return (float)extent_.width / (float)std::max(1u, extent_.height); }
    void waitIdle() { if (dev_) vkDeviceWaitIdle(dev_); }
    const RenderStats& stats() const { return stats_; }
    void setFramebufferResized() { resized_ = true; }
    int msaaSamples() const { return (int)msaa_; }

private:
    static constexpr int FRAMES = 2;

    struct Range { uint32_t first, count; };
    struct Part { int mat; Range r; };
    struct Group { int sp, var; uint32_t first, count; };
    struct GpuChunk {
        GpuBuffer vb, inst;
        std::vector<Part> parts;
        std::vector<Group> groups;
        float bmin[3], bmax[3];
        float cx, cz;
    };
    struct StaticMesh {
        GpuBuffer vb;
        uint32_t count = 0;
    };
    struct PushC {
        float model[16];
        float p0[4];
        float p1[4];
    };
    struct PipeDesc;

    // ---- infraestrutura ----
    NativeWin* win_ = nullptr;
    std::string shaderDir_;
    VkInstance inst_ = VK_NULL_HANDLE;
    VkSurfaceKHR surf_ = VK_NULL_HANDLE;
    VkPhysicalDevice phys_ = VK_NULL_HANDLE;
    VkDevice dev_ = VK_NULL_HANDLE;
    VkQueue queue_ = VK_NULL_HANDLE;
    uint32_t qFamily_ = 0;
    VkPhysicalDeviceMemoryProperties memProps_{};
    VkPhysicalDeviceProperties props_{};
    bool anisotropy_ = false;

    VkSwapchainKHR swap_ = VK_NULL_HANDLE;
    VkFormat swapFmt_ = VK_FORMAT_UNDEFINED;
    VkExtent2D extent_{};
    std::vector<VkImage> swapImages_;
    std::vector<VkImageView> swapViews_;
    std::vector<VkFramebuffer> framebuffers_;
    VkFormat depthFmt_ = VK_FORMAT_UNDEFINED;
    VkSampleCountFlagBits msaa_ = VK_SAMPLE_COUNT_1_BIT;
    GpuImage depth_, msaaColor_;
    bool resized_ = false;

    VkRenderPass mainPass_ = VK_NULL_HANDLE, shadowPass_ = VK_NULL_HANDLE;
    std::array<GpuImage, FRAMES> shadowImg_;
    std::array<VkFramebuffer, FRAMES> shadowFb_{};

    VkDescriptorSetLayout dsl_ = VK_NULL_HANDLE;
    VkDescriptorPool pool_ = VK_NULL_HANDLE;
    std::array<VkDescriptorSet, FRAMES> sets_{};
    VkPipelineLayout pipeLayout_ = VK_NULL_HANDLE;
    VkSampler shadowSampler_ = VK_NULL_HANDLE, repeatSampler_ = VK_NULL_HANDLE, waterSampler_ = VK_NULL_HANDLE, clampSampler_ = VK_NULL_HANDLE;

    VkPipeline pSky_ = VK_NULL_HANDLE, pScene_ = VK_NULL_HANDLE, pTree_ = VK_NULL_HANDLE, pWater_ = VK_NULL_HANDLE, pFoam_ = VK_NULL_HANDLE,
               pGlit_ = VK_NULL_HANDLE, pShadow_ = VK_NULL_HANDLE, pShadowTree_ = VK_NULL_HANDLE, pHud_ = VK_NULL_HANDLE;

    VkCommandPool cmdPool_ = VK_NULL_HANDLE, upPool_ = VK_NULL_HANDLE;
    std::array<VkCommandBuffer, FRAMES> cmd_{};
    std::array<VkSemaphore, FRAMES> imageAvail_{};
    std::vector<VkSemaphore> renderDone_;
    std::array<VkFence, FRAMES> inFlight_{};
    VkFence upFence_ = VK_NULL_HANDLE;
    std::array<GpuBuffer, FRAMES> ubo_;
    std::array<void*, FRAMES> uboMap_{};
    int cur_ = 0;
    std::array<std::vector<GpuBuffer>, FRAMES> trash_;

    // ---- conteúdo ----
    GpuImage terrainTex_, waterTex_, glitTex_;
    GpuBuffer treeVb_;
    Range treeRange_[SP_COUNT][8][2]{};
    StaticMesh pier_, bridge_, player_, waterMesh_, foamMesh_, glitMesh_, hudDisc_, hudRing_;
    Range foamRing_[3]{};
    std::unordered_map<int, GpuChunk> chunks_[2];
    RenderStats stats_;

    // ---- helpers ----
    void framebufferSize(int& w, int& h) const;
    VkResult createSurface();
    bool createInstanceAndDevice();
    bool createSwapchain();
    void destroySwapchain();
    bool recreateSwapchain();
    bool createRenderPasses();
    bool createFramebuffers();
    bool createDescriptors();
    bool createPipelines();
    bool createSyncAndCommands();
    VkShaderModule loadShader(const std::string& name);
    VkPipeline makePipeline(const PipeDesc& d);
    uint32_t findMemType(uint32_t bits, VkMemoryPropertyFlags props) const;
    GpuBuffer createBuffer(VkDeviceSize size, VkBufferUsageFlags usage, VkMemoryPropertyFlags props);
    void destroyBuffer(GpuBuffer& b);
    void destroyBufferLater(GpuBuffer& b);
    GpuBuffer createDeviceBuffer(const void* data, VkDeviceSize size, VkBufferUsageFlags usage);
    GpuImage createImage(uint32_t w, uint32_t h, uint32_t layers, uint32_t mips, VkFormat fmt, VkSampleCountFlagBits samples, VkImageUsageFlags usage,
                         VkImageAspectFlags aspect, bool array);
    void destroyImage(GpuImage& i);
    GpuImage uploadTexture(const std::vector<std::vector<TexGen::Image>>& layerMips, bool array);
    VkCommandBuffer beginOneTime();
    void endOneTime(VkCommandBuffer c);
    StaticMesh uploadMesh(const std::vector<Vtx>& v);
    void buildWaterMeshes();
    void updateDescriptorSets();

    void recordShadow(VkCommandBuffer c, const FrameParams& fp, const float* frustum);
    void recordMain(VkCommandBuffer c, uint32_t imageIndex, const FrameParams& fp, const float* frustum);
    void push(VkCommandBuffer c, const float* model, float a, float b, float cc, float d, float e = 0.f);
};
