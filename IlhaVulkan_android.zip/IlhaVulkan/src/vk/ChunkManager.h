// Carrega/descarrega chunks conforme o boneco anda. Threads de fundo constroem as malhas (funções puras);
// a thread principal só envia ao GPU poucos chunks por quadro (sem engasgos).
#pragma once
#include <algorithm>
#include <atomic>
#include <condition_variable>
#include <deque>
#include <mutex>
#include <thread>
#include <unordered_set>
#include <vector>

#include "../core/ChunkBuilder.h"
#include "../core/Game.h"
#include "Renderer.h"

class ChunkManager {
public:
    ChunkManager(Renderer& r, SolidMap& solids, int threads) : r_(r), solids_(solids) {
        for (int i = 0; i < threads; i++) workers_.emplace_back([this] { work(); });
    }
    ~ChunkManager() {
        {
            std::lock_guard<std::mutex> lk(m_);
            stop_ = true;
        }
        cv_.notify_all();
        for (auto& t : workers_) t.join();
    }

    /** Constrói tudo perto do boneco ANTES do primeiro quadro (em paralelo), para a tela de início já estar completa. */
    void warmup(float px, float pz, float radius) {
        std::vector<Job> jobs = wanted(px, pz, radius, radius, true);
        std::vector<Built> out(jobs.size());
        std::atomic<size_t> next{0};
        int n = std::max(1, (int)workers_.size());
        std::vector<std::thread> th;
        for (int t = 0; t < n; t++)
            th.emplace_back([&] {
                for (size_t i; (i = next++) < jobs.size();) out[i] = build(jobs[i]);
            });
        for (auto& t : th) t.join();
        for (auto& b : out) install(b);
    }

    /** Chamar todo quadro. */
    void update(float px, float pz) {
        // 1) pedidos novos (os mais próximos primeiro)
        std::vector<Job> jobs = wanted(px, pz, Cfg::TERRAIN_R, Cfg::DECO_R, false);
        {
            std::lock_guard<std::mutex> lk(m_);
            for (auto& j : jobs) {
                if (queue_.size() >= 12) break;  // fila curta: os pedidos se renovam todo quadro, sempre os mais próximos
                int k = idOf(j);
                if (pending_.count(k)) continue;
                pending_.insert(k);
                queue_.push_back(j);
            }
        }
        cv_.notify_all();

        // 2) envia ao GPU os prontos (no máximo 3 por quadro)
        for (int i = 0; i < 3; i++) {
            Built b;
            {
                std::lock_guard<std::mutex> lk(m_);
                if (done_.empty()) break;
                b = std::move(done_.front());
                done_.pop_front();
                pending_.erase(b.layer * 100000 + b.key);
            }
            float cx = (b.key % Cfg::CHUNKS) * Cfg::CHUNK - Cfg::HALF + Cfg::CHUNK * 0.5f;
            float cz = (b.key / Cfg::CHUNKS) * Cfg::CHUNK - Cfg::HALF + Cfg::CHUNK * 0.5f;
            float R = (b.layer == 0 ? Cfg::TERRAIN_R : Cfg::DECO_R) + Cfg::CHUNK * 1.5f;
            if (std::hypot(cx - px, cz - pz) < R) install(b);  // se o boneco já se afastou, descarta
        }

        // 3) descarrega os distantes (com histerese)
        for (int layer = 0; layer < 2; layer++) {
            float R = (layer == 0 ? Cfg::TERRAIN_R : Cfg::DECO_R) + Cfg::CHUNK * 1.5f;
            for (int cz = 0; cz < Cfg::CHUNKS; cz++)
                for (int cx = 0; cx < Cfg::CHUNKS; cx++) {
                    int key = cz * Cfg::CHUNKS + cx;
                    if (!r_.hasChunk(layer, key)) continue;
                    float x = cx * Cfg::CHUNK - Cfg::HALF + Cfg::CHUNK * 0.5f;
                    float z = cz * Cfg::CHUNK - Cfg::HALF + Cfg::CHUNK * 0.5f;
                    if (std::hypot(x - px, z - pz) > R) {
                        r_.removeChunk(layer, key);
                        if (layer == 1) solids_.remove(key);
                    }
                }
        }
    }

private:
    struct Job {
        int layer, cx, cz;
        float dist;
    };
    Renderer& r_;
    SolidMap& solids_;
    std::vector<std::thread> workers_;
    std::mutex m_;
    std::condition_variable cv_;
    std::deque<Job> queue_;
    std::deque<Built> done_;
    std::unordered_set<int> pending_;
    bool stop_ = false;

    static int idOf(const Job& j) { return j.layer * 100000 + j.cz * Cfg::CHUNKS + j.cx; }

    static Built build(const Job& j) { return j.layer == 0 ? ChunkBuilder::terrain(j.cx, j.cz) : ChunkBuilder::decor(j.cx, j.cz); }

    void install(Built& b) {
        if (r_.hasChunk(b.layer, b.key)) return;
        r_.addChunk(b);
        if (b.layer == 1) solids_.set(b.key, b.solids);
    }

    std::vector<Job> wanted(float px, float pz, float rTerrain, float rDeco, bool all) const {
        std::vector<Job> v;
        for (int layer = 0; layer < 2; layer++) {
            float R = (layer == 0 ? rTerrain : rDeco) + Cfg::CHUNK * 0.7f;
            for (int cz = 0; cz < Cfg::CHUNKS; cz++)
                for (int cx = 0; cx < Cfg::CHUNKS; cx++) {
                    float x = cx * Cfg::CHUNK - Cfg::HALF + Cfg::CHUNK * 0.5f;
                    float z = cz * Cfg::CHUNK - Cfg::HALF + Cfg::CHUNK * 0.5f;
                    float d = std::hypot(x - px, z - pz);
                    if (d > R) continue;
                    if (!all && r_.hasChunk(layer, cz * Cfg::CHUNKS + cx)) continue;
                    v.push_back({layer, cx, cz, d});
                }
        }
        std::sort(v.begin(), v.end(), [](const Job& a, const Job& b) { return a.dist < b.dist; });
        return v;
    }

    void work() {
        for (;;) {
            Job j;
            {
                std::unique_lock<std::mutex> lk(m_);
                cv_.wait(lk, [this] { return stop_ || !queue_.empty(); });
                if (stop_) return;
                j = queue_.front();
                queue_.pop_front();
            }
            Built b = build(j);
            std::lock_guard<std::mutex> lk(m_);
            done_.push_back(std::move(b));
        }
    }
};
