#include "Renderer.h"

#ifdef __ANDROID__
#include <android/asset_manager.h>
#include <android/native_window.h>
static AAssetManager* g_assets = nullptr;
#else
#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>
#endif

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <set>

#include "../core/Cfg.h"
#include "../core/Prims.h"

#define VKC(x)                                                                                 \
    do {                                                                                       \
        VkResult r_ = (x);                                                                     \
        if (r_ != VK_SUCCESS) {                                                                \
            std::fprintf(stderr, "Vulkan erro %d em %s (%s:%d)\n", (int)r_, #x, __FILE__, __LINE__); \
            std::abort();                                                                      \
        }                                                                                      \
    } while (0)

// Layout std140 do bloco "Frame" dos shaders (tudo mat4/vec4: sem padding escondido).
struct FrameUBO {
    float viewProj[16];
    float invViewProj[16];
    float lightViewProj[16];
    float camPos[4];
    float lightDir[4];
    float lightColor[4];
    float ambient[4];
    float fogColor[4];
    float skyTop[4];
    float skyHor[4];
    float sunDir[4];
    float moonDir[4];
    float meteorA[4][4];
    float meteorB[4][4];
    float meteorC[4][4];
};

struct Renderer::PipeDesc {
    const char* vert;
    const char* frag;  // nullptr = só profundidade
    int vin;           // 0 nenhum, 1 Vtx, 2 Vtx + instância, 3 só posição (vec3)
    bool depthTest, depthWrite;
    int blend;  // 0 nenhum, 1 alfa, 2 aditivo
    VkRenderPass rp;
    VkSampleCountFlagBits samples;
    bool bias;
};

static const float CAM_FAR = 1000.f;

// ======================================================================
//  Utilidades
// ======================================================================
static void extractFrustum(const Mat4& vp, float* out) {
    auto row = [&](int r, float* v) { v[0] = vp.m[r]; v[1] = vp.m[4 + r]; v[2] = vp.m[8 + r]; v[3] = vp.m[12 + r]; };
    float r0[4], r1[4], r2[4], r3[4];
    row(0, r0); row(1, r1); row(2, r2); row(3, r3);
    for (int i = 0; i < 4; i++) {
        out[0 * 4 + i] = r3[i] + r0[i];  // esquerda
        out[1 * 4 + i] = r3[i] - r0[i];  // direita
        out[2 * 4 + i] = r3[i] + r1[i];  // baixo
        out[3 * 4 + i] = r3[i] - r1[i];  // cima
        out[4 * 4 + i] = r2[i];          // perto (profundidade 0..1)
        out[5 * 4 + i] = r3[i] - r2[i];  // longe
    }
}

static bool aabbVisible(const float* fr, const float* mn, const float* mx) {
    for (int p = 0; p < 6; p++) {
        const float* pl = fr + p * 4;
        float x = pl[0] > 0 ? mx[0] : mn[0];
        float y = pl[1] > 0 ? mx[1] : mn[1];
        float z = pl[2] > 0 ? mx[2] : mn[2];
        if (pl[0] * x + pl[1] * y + pl[2] * z + pl[3] < 0) return false;
    }
    return true;
}

static Mat4 lightMatrix(const Vec3& L, const Vec3& center) {
    float E = Cfg::SHADOW_EXTENT;
    Vec3 up = std::fabs(L.y) > 0.99f ? Vec3(0, 0, 1) : Vec3(0, 1, 0);
    float along = center.dot(L);
    Vec3 eye = L * (along + 250.f);
    Vec3 target = L * along;
    Mat4 view = Mat4::lookAt(eye, target, up);
    // "snap" do centro à grade de texels: a sombra não treme quando o boneco anda
    float texel = 2.f * E / (float)Cfg::SHADOW_RES;
    float px = view.m[0] * center.x + view.m[4] * center.y + view.m[8] * center.z;
    float py = view.m[1] * center.x + view.m[5] * center.y + view.m[9] * center.z;
    float sx = std::floor(px / texel) * texel;
    float sy = std::floor(py / texel) * texel;
    Mat4 proj = Mat4::ortho(sx - E, sx + E, sy - E, sy + E, 1.f, 500.f);
    return Mat4::mul(proj, view);
}

static int matLayer(int mat) { return mat == M_DECOROCK ? 2 : mat; }

// ======================================================================
//  Plataforma (janela / surface / arquivos)
// ======================================================================
void Renderer::framebufferSize(int& w, int& h) const {
#ifdef __ANDROID__
    w = win_ ? ANativeWindow_getWidth(win_) : 0;
    h = win_ ? ANativeWindow_getHeight(win_) : 0;
#else
    glfwGetFramebufferSize(win_, &w, &h);
#endif
}

VkResult Renderer::createSurface() {
#ifdef __ANDROID__
    VkAndroidSurfaceCreateInfoKHR sci{VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR};
    sci.window = win_;
    return vkCreateAndroidSurfaceKHR(inst_, &sci, nullptr, &surf_);
#else
    return glfwCreateWindowSurface(inst_, win_, nullptr, &surf_);
#endif
}

#ifdef __ANDROID__
void Renderer::setAssetManager(AAssetManager* am) { g_assets = am; }

void Renderer::releaseSurface() {
    if (!dev_) return;
    vkDeviceWaitIdle(dev_);
    destroySwapchain();
    extent_ = {0, 0};
    if (surf_) vkDestroySurfaceKHR(inst_, surf_, nullptr);
    surf_ = VK_NULL_HANDLE;
    win_ = nullptr;
}

bool Renderer::attachSurface(NativeWin* window) {
    if (!dev_) return false;
    win_ = window;
    if (surf_) { vkDeviceWaitIdle(dev_); destroySwapchain(); vkDestroySurfaceKHR(inst_, surf_, nullptr); surf_ = VK_NULL_HANDLE; }
    VkResult r = createSurface();
    if (r != VK_SUCCESS) { std::fprintf(stderr, "vkCreateAndroidSurfaceKHR: %d\n", (int)r); return false; }
    if (!createSwapchain()) return false;
    return createFramebuffers();
}
#endif

// ======================================================================
//  Instância, dispositivo
// ======================================================================
bool Renderer::createInstanceAndDevice() {
#ifdef __ANDROID__
    std::vector<const char*> iext = {VK_KHR_SURFACE_EXTENSION_NAME, VK_KHR_ANDROID_SURFACE_EXTENSION_NAME};
#else
    uint32_t n = 0;
    const char** ex = glfwGetRequiredInstanceExtensions(&n);
    if (!ex) { std::fprintf(stderr, "GLFW sem suporte a Vulkan.\n"); return false; }
    std::vector<const char*> iext(ex, ex + n);
#endif

    std::vector<const char*> layers;
    if (std::getenv("ILHA_VALIDATION")) {
        uint32_t lc = 0;
        vkEnumerateInstanceLayerProperties(&lc, nullptr);
        std::vector<VkLayerProperties> lp(lc);
        vkEnumerateInstanceLayerProperties(&lc, lp.data());
        for (auto& l : lp)
            if (std::strcmp(l.layerName, "VK_LAYER_KHRONOS_validation") == 0) layers.push_back("VK_LAYER_KHRONOS_validation");
    }

    VkApplicationInfo ai{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    ai.pApplicationName = "Ilha Gigante";
    ai.apiVersion = VK_API_VERSION_1_1;
    VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ci.pApplicationInfo = &ai;
    ci.enabledExtensionCount = (uint32_t)iext.size();
    ci.ppEnabledExtensionNames = iext.data();
    ci.enabledLayerCount = (uint32_t)layers.size();
    ci.ppEnabledLayerNames = layers.data();
    VKC(vkCreateInstance(&ci, nullptr, &inst_));
    VKC(createSurface());

    uint32_t dc = 0;
    vkEnumeratePhysicalDevices(inst_, &dc, nullptr);
    if (dc == 0) { std::fprintf(stderr, "Nenhuma GPU com Vulkan.\n"); return false; }
    std::vector<VkPhysicalDevice> devs(dc);
    vkEnumeratePhysicalDevices(inst_, &dc, devs.data());

    int bestScore = -1;
    for (VkPhysicalDevice pd : devs) {
        uint32_t ec = 0;
        vkEnumerateDeviceExtensionProperties(pd, nullptr, &ec, nullptr);
        std::vector<VkExtensionProperties> ep(ec);
        vkEnumerateDeviceExtensionProperties(pd, nullptr, &ec, ep.data());
        bool hasSwap = false;
        for (auto& e : ep)
            if (std::strcmp(e.extensionName, VK_KHR_SWAPCHAIN_EXTENSION_NAME) == 0) hasSwap = true;
        if (!hasSwap) continue;
        uint32_t qc = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qc, nullptr);
        std::vector<VkQueueFamilyProperties> qp(qc);
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qc, qp.data());
        for (uint32_t i = 0; i < qc; i++) {
            VkBool32 present = VK_FALSE;
            vkGetPhysicalDeviceSurfaceSupportKHR(pd, i, surf_, &present);
            if ((qp[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) && present) {
                VkPhysicalDeviceProperties pr;
                vkGetPhysicalDeviceProperties(pd, &pr);
                int score = (pr.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU ? 1000 : 0) + 1;
                if (score > bestScore) { bestScore = score; phys_ = pd; qFamily_ = i; }
                break;
            }
        }
    }
    if (!phys_) { std::fprintf(stderr, "Nenhuma GPU compatível (swapchain + fila gráfica).\n"); return false; }

    vkGetPhysicalDeviceProperties(phys_, &props_);
    vkGetPhysicalDeviceMemoryProperties(phys_, &memProps_);
    std::printf("GPU: %s\n", props_.deviceName);

    VkPhysicalDeviceFeatures supported{};
    vkGetPhysicalDeviceFeatures(phys_, &supported);
    anisotropy_ = supported.samplerAnisotropy == VK_TRUE;
    VkPhysicalDeviceFeatures enabled{};
    enabled.samplerAnisotropy = anisotropy_ ? VK_TRUE : VK_FALSE;

    float prio = 1.f;
    VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    qci.queueFamilyIndex = qFamily_;
    qci.queueCount = 1;
    qci.pQueuePriorities = &prio;
    const char* dext[] = {VK_KHR_SWAPCHAIN_EXTENSION_NAME};
    VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    dci.queueCreateInfoCount = 1;
    dci.pQueueCreateInfos = &qci;
    dci.enabledExtensionCount = 1;
    dci.ppEnabledExtensionNames = dext;
    dci.pEnabledFeatures = &enabled;
    VKC(vkCreateDevice(phys_, &dci, nullptr, &dev_));
    vkGetDeviceQueue(dev_, qFamily_, 0, &queue_);

    // formato de profundidade (precisa ser amostrável com filtro linear para o PCF por hardware)
    const VkFormat cand[] = {VK_FORMAT_D32_SFLOAT, VK_FORMAT_D32_SFLOAT_S8_UINT, VK_FORMAT_D24_UNORM_S8_UINT};
    for (VkFormat f : cand) {
        VkFormatProperties fp;
        vkGetPhysicalDeviceFormatProperties(phys_, f, &fp);
        VkFormatFeatureFlags need = VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT | VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT | VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT;
        if ((fp.optimalTilingFeatures & need) == need) { depthFmt_ = f; break; }
    }
    if (depthFmt_ == VK_FORMAT_UNDEFINED) { std::fprintf(stderr, "Sem formato de profundidade amostrável.\n"); return false; }

    // MSAA: o maior suportado até Cfg::MSAA
    VkSampleCountFlags sc = props_.limits.framebufferColorSampleCounts & props_.limits.framebufferDepthSampleCounts;
    msaa_ = VK_SAMPLE_COUNT_1_BIT;
    for (VkSampleCountFlagBits s : {VK_SAMPLE_COUNT_8_BIT, VK_SAMPLE_COUNT_4_BIT, VK_SAMPLE_COUNT_2_BIT})
        if ((int)s <= Cfg::MSAA && (sc & s)) { msaa_ = s; break; }
    return true;
}

// ======================================================================
//  Memória, buffers, imagens
// ======================================================================
uint32_t Renderer::findMemType(uint32_t bits, VkMemoryPropertyFlags props) const {
    for (uint32_t i = 0; i < memProps_.memoryTypeCount; i++)
        if ((bits & (1u << i)) && (memProps_.memoryTypes[i].propertyFlags & props) == props) return i;
    std::fprintf(stderr, "Tipo de memória não encontrado.\n");
    std::abort();
}

GpuBuffer Renderer::createBuffer(VkDeviceSize size, VkBufferUsageFlags usage, VkMemoryPropertyFlags props) {
    GpuBuffer b;
    b.size = size;
    VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bi.size = size;
    bi.usage = usage;
    bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    VKC(vkCreateBuffer(dev_, &bi, nullptr, &b.buf));
    VkMemoryRequirements mr;
    vkGetBufferMemoryRequirements(dev_, b.buf, &mr);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = mr.size;
    ai.memoryTypeIndex = findMemType(mr.memoryTypeBits, props);
    VKC(vkAllocateMemory(dev_, &ai, nullptr, &b.mem));
    VKC(vkBindBufferMemory(dev_, b.buf, b.mem, 0));
    return b;
}

void Renderer::destroyBuffer(GpuBuffer& b) {
    if (b.buf) vkDestroyBuffer(dev_, b.buf, nullptr);
    if (b.mem) vkFreeMemory(dev_, b.mem, nullptr);
    b = GpuBuffer{};
}

void Renderer::destroyBufferLater(GpuBuffer& b) {
    if (!b.buf) return;
    trash_[(cur_ + FRAMES - 1) % FRAMES].push_back(b);  // slot do último quadro enviado: só some depois que ele terminar
    b = GpuBuffer{};
}

VkCommandBuffer Renderer::beginOneTime() {
    VkCommandBufferAllocateInfo ai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    ai.commandPool = upPool_;
    ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    ai.commandBufferCount = 1;
    VkCommandBuffer c;
    VKC(vkAllocateCommandBuffers(dev_, &ai, &c));
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    VKC(vkBeginCommandBuffer(c, &bi));
    return c;
}

void Renderer::endOneTime(VkCommandBuffer c) {
    VKC(vkEndCommandBuffer(c));
    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.commandBufferCount = 1;
    si.pCommandBuffers = &c;
    VKC(vkQueueSubmit(queue_, 1, &si, upFence_));
    VKC(vkWaitForFences(dev_, 1, &upFence_, VK_TRUE, UINT64_MAX));
    VKC(vkResetFences(dev_, 1, &upFence_));
    vkFreeCommandBuffers(dev_, upPool_, 1, &c);
}

GpuBuffer Renderer::createDeviceBuffer(const void* data, VkDeviceSize size, VkBufferUsageFlags usage) {
    GpuBuffer st = createBuffer(size, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* p = nullptr;
    VKC(vkMapMemory(dev_, st.mem, 0, size, 0, &p));
    std::memcpy(p, data, (size_t)size);
    vkUnmapMemory(dev_, st.mem);
    GpuBuffer b = createBuffer(size, usage | VK_BUFFER_USAGE_TRANSFER_DST_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VkCommandBuffer c = beginOneTime();
    VkBufferCopy cp{0, 0, size};
    vkCmdCopyBuffer(c, st.buf, b.buf, 1, &cp);
    endOneTime(c);
    destroyBuffer(st);
    return b;
}

GpuImage Renderer::createImage(uint32_t w, uint32_t h, uint32_t layers, uint32_t mips, VkFormat fmt, VkSampleCountFlagBits samples,
                               VkImageUsageFlags usage, VkImageAspectFlags aspect, bool array) {
    GpuImage g;
    VkImageCreateInfo ii{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    ii.imageType = VK_IMAGE_TYPE_2D;
    ii.format = fmt;
    ii.extent = {w, h, 1};
    ii.mipLevels = mips;
    ii.arrayLayers = layers;
    ii.samples = samples;
    ii.tiling = VK_IMAGE_TILING_OPTIMAL;
    ii.usage = usage;
    ii.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    VKC(vkCreateImage(dev_, &ii, nullptr, &g.image));
    VkMemoryRequirements mr;
    vkGetImageMemoryRequirements(dev_, g.image, &mr);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = mr.size;
    ai.memoryTypeIndex = findMemType(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VKC(vkAllocateMemory(dev_, &ai, nullptr, &g.mem));
    VKC(vkBindImageMemory(dev_, g.image, g.mem, 0));
    VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    vi.image = g.image;
    vi.viewType = array ? VK_IMAGE_VIEW_TYPE_2D_ARRAY : VK_IMAGE_VIEW_TYPE_2D;
    vi.format = fmt;
    vi.subresourceRange = {aspect, 0, mips, 0, layers};
    VKC(vkCreateImageView(dev_, &vi, nullptr, &g.view));
    return g;
}

void Renderer::destroyImage(GpuImage& i) {
    if (i.view) vkDestroyImageView(dev_, i.view, nullptr);
    if (i.image) vkDestroyImage(dev_, i.image, nullptr);
    if (i.mem) vkFreeMemory(dev_, i.mem, nullptr);
    i = GpuImage{};
}

GpuImage Renderer::uploadTexture(const std::vector<std::vector<TexGen::Image>>& L, bool array) {
    uint32_t layers = (uint32_t)L.size();
    uint32_t mips = (uint32_t)L[0].size();
    uint32_t w = (uint32_t)L[0][0].w, h = (uint32_t)L[0][0].h;
    GpuImage img = createImage(w, h, layers, mips, VK_FORMAT_R8G8B8A8_UNORM, VK_SAMPLE_COUNT_1_BIT,
                               VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT, VK_IMAGE_ASPECT_COLOR_BIT, array);
    VkDeviceSize total = 0;
    for (auto& lay : L)
        for (auto& m : lay) total += m.rgba.size();
    GpuBuffer st = createBuffer(total, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    uint8_t* p = nullptr;
    VKC(vkMapMemory(dev_, st.mem, 0, total, 0, (void**)&p));
    std::vector<VkBufferImageCopy> regions;
    VkDeviceSize off = 0;
    for (uint32_t l = 0; l < layers; l++)
        for (uint32_t m = 0; m < mips; m++) {
            const TexGen::Image& im = L[l][m];
            std::memcpy(p + off, im.rgba.data(), im.rgba.size());
            VkBufferImageCopy r{};
            r.bufferOffset = off;
            r.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, m, l, 1};
            r.imageExtent = {(uint32_t)im.w, (uint32_t)im.h, 1};
            regions.push_back(r);
            off += im.rgba.size();
        }
    vkUnmapMemory(dev_, st.mem);

    VkCommandBuffer c = beginOneTime();
    VkImageMemoryBarrier b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    b.image = img.image;
    b.srcQueueFamilyIndex = b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    b.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, mips, 0, layers};
    b.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    b.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
    b.srcAccessMask = 0;
    b.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    vkCmdPipelineBarrier(c, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0, nullptr, 1, &b);
    vkCmdCopyBufferToImage(c, st.buf, img.image, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, (uint32_t)regions.size(), regions.data());
    b.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
    b.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    b.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    b.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    vkCmdPipelineBarrier(c, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, 0, 0, nullptr, 0, nullptr, 1, &b);
    endOneTime(c);
    destroyBuffer(st);
    return img;
}

// ======================================================================
//  Swapchain
// ======================================================================
bool Renderer::createSwapchain() {
    VkSurfaceCapabilitiesKHR caps;
    VKC(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(phys_, surf_, &caps));
    uint32_t fc = 0;
    vkGetPhysicalDeviceSurfaceFormatsKHR(phys_, surf_, &fc, nullptr);
    std::vector<VkSurfaceFormatKHR> fm(fc);
    vkGetPhysicalDeviceSurfaceFormatsKHR(phys_, surf_, &fc, fm.data());
    VkSurfaceFormatKHR chosen = fm[0];
    for (auto& f : fm)
        if (f.format == VK_FORMAT_B8G8R8A8_UNORM && f.colorSpace == VK_COLOR_SPACE_SRGB_NONLINEAR_KHR) { chosen = f; break; }
    if (chosen.format != VK_FORMAT_B8G8R8A8_UNORM)
        for (auto& f : fm)
            if (f.format == VK_FORMAT_R8G8B8A8_UNORM && f.colorSpace == VK_COLOR_SPACE_SRGB_NONLINEAR_KHR) { chosen = f; break; }
    // UNORM de propósito: as cores do original são escritas direto na tela (sem conversão sRGB), então ficam IGUAIS.
    swapFmt_ = chosen.format;

    uint32_t pc = 0;
    vkGetPhysicalDeviceSurfacePresentModesKHR(phys_, surf_, &pc, nullptr);
    std::vector<VkPresentModeKHR> pm(pc);
    vkGetPhysicalDeviceSurfacePresentModesKHR(phys_, surf_, &pc, pm.data());
    VkPresentModeKHR mode = VK_PRESENT_MODE_FIFO_KHR;
#ifndef __ANDROID__
    for (auto m : pm)
        if (m == VK_PRESENT_MODE_MAILBOX_KHR) mode = m;
#endif

    if (caps.currentExtent.width != UINT32_MAX) {
        extent_ = caps.currentExtent;
    } else {
        int w, h;
        framebufferSize(w, h);
        extent_.width = std::clamp((uint32_t)w, caps.minImageExtent.width, caps.maxImageExtent.width);
        extent_.height = std::clamp((uint32_t)h, caps.minImageExtent.height, caps.maxImageExtent.height);
    }
    VkSurfaceTransformFlagBitsKHR preTransform = caps.currentTransform;
#ifdef __ANDROID__
    // No Android o currentExtent vem na orientação NATIVA do aparelho (retrato). Usamos pré-transformação IDENTITY
    // (o compositor gira a imagem) e portanto trocamos largura/altura quando a tela está girada 90/270 graus.
    if (caps.supportedTransforms & VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR) {
        if (caps.currentTransform & (VK_SURFACE_TRANSFORM_ROTATE_90_BIT_KHR | VK_SURFACE_TRANSFORM_ROTATE_270_BIT_KHR))
            std::swap(extent_.width, extent_.height);
        preTransform = VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR;
    }
#endif
    if (extent_.width == 0 || extent_.height == 0) return true;  // minimizado

    uint32_t count = caps.minImageCount + 1;
    if (caps.maxImageCount > 0) count = std::min(count, caps.maxImageCount);
    VkSwapchainCreateInfoKHR si{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};
    si.surface = surf_;
    si.minImageCount = count;
    si.imageFormat = chosen.format;
    si.imageColorSpace = chosen.colorSpace;
    si.imageExtent = extent_;
    si.imageArrayLayers = 1;
    si.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    si.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
    si.preTransform = preTransform;
    si.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
    si.presentMode = mode;
    si.clipped = VK_TRUE;
    si.oldSwapchain = VK_NULL_HANDLE;
    VKC(vkCreateSwapchainKHR(dev_, &si, nullptr, &swap_));

    uint32_t ic = 0;
    vkGetSwapchainImagesKHR(dev_, swap_, &ic, nullptr);
    swapImages_.resize(ic);
    vkGetSwapchainImagesKHR(dev_, swap_, &ic, swapImages_.data());
    swapViews_.resize(ic);
    for (uint32_t i = 0; i < ic; i++) {
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        vi.image = swapImages_[i];
        vi.viewType = VK_IMAGE_VIEW_TYPE_2D;
        vi.format = swapFmt_;
        vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
        VKC(vkCreateImageView(dev_, &vi, nullptr, &swapViews_[i]));
    }

    VkImageAspectFlags depthAspect = VK_IMAGE_ASPECT_DEPTH_BIT;
    if (depthFmt_ != VK_FORMAT_D32_SFLOAT) depthAspect |= VK_IMAGE_ASPECT_STENCIL_BIT;  // vista de anexo: tem de cobrir os dois
    depth_ = createImage(extent_.width, extent_.height, 1, 1, depthFmt_, msaa_, VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT, depthAspect, false);
    if (msaa_ != VK_SAMPLE_COUNT_1_BIT)
        msaaColor_ = createImage(extent_.width, extent_.height, 1, 1, swapFmt_, msaa_,
                                 VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSIENT_ATTACHMENT_BIT, VK_IMAGE_ASPECT_COLOR_BIT, false);

    renderDone_.resize(ic);
    for (auto& s : renderDone_) {
        VkSemaphoreCreateInfo sci{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        VKC(vkCreateSemaphore(dev_, &sci, nullptr, &s));
    }
    return true;
}

void Renderer::destroySwapchain() {
    for (auto f : framebuffers_) vkDestroyFramebuffer(dev_, f, nullptr);
    framebuffers_.clear();
    destroyImage(msaaColor_);
    destroyImage(depth_);
    for (auto v : swapViews_) vkDestroyImageView(dev_, v, nullptr);
    swapViews_.clear();
    for (auto s : renderDone_) vkDestroySemaphore(dev_, s, nullptr);
    renderDone_.clear();
    if (swap_) vkDestroySwapchainKHR(dev_, swap_, nullptr);
    swap_ = VK_NULL_HANDLE;
}

bool Renderer::createFramebuffers() {
    if (extent_.width == 0 || extent_.height == 0) return true;
    framebuffers_.resize(swapViews_.size());
    for (size_t i = 0; i < swapViews_.size(); i++) {
        std::vector<VkImageView> att;
        if (msaa_ != VK_SAMPLE_COUNT_1_BIT) att = {msaaColor_.view, depth_.view, swapViews_[i]};
        else att = {swapViews_[i], depth_.view};
        VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
        fi.renderPass = mainPass_;
        fi.attachmentCount = (uint32_t)att.size();
        fi.pAttachments = att.data();
        fi.width = extent_.width;
        fi.height = extent_.height;
        fi.layers = 1;
        VKC(vkCreateFramebuffer(dev_, &fi, nullptr, &framebuffers_[i]));
    }
    return true;
}

bool Renderer::recreateSwapchain() {
    int w = 0, h = 0;
    framebufferSize(w, h);
    if (w == 0 || h == 0) { extent_ = {0, 0}; return true; }
    vkDeviceWaitIdle(dev_);
    destroySwapchain();
    if (!createSwapchain()) return false;
    return createFramebuffers();
}

// ======================================================================
//  Render passes
// ======================================================================
bool Renderer::createRenderPasses() {
    // ---- principal: cor (MSAA + resolve) + profundidade ----
    {
        std::vector<VkAttachmentDescription> att;
        VkAttachmentReference colRef{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
        VkAttachmentReference depRef{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
        VkAttachmentReference resRef{2, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
        bool ms = msaa_ != VK_SAMPLE_COUNT_1_BIT;

        VkAttachmentDescription c{};
        c.format = swapFmt_;
        c.samples = msaa_;
        c.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        c.storeOp = ms ? VK_ATTACHMENT_STORE_OP_DONT_CARE : VK_ATTACHMENT_STORE_OP_STORE;
        c.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        c.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        c.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        c.finalLayout = ms ? VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL : VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
        att.push_back(c);

        VkAttachmentDescription d{};
        d.format = depthFmt_;
        d.samples = msaa_;
        d.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        d.storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        d.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        d.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        d.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        d.finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
        att.push_back(d);

        if (ms) {
            VkAttachmentDescription r{};
            r.format = swapFmt_;
            r.samples = VK_SAMPLE_COUNT_1_BIT;
            r.loadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
            r.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
            r.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
            r.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
            r.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
            r.finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
            att.push_back(r);
        }
        VkSubpassDescription sp{};
        sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
        sp.colorAttachmentCount = 1;
        sp.pColorAttachments = &colRef;
        sp.pDepthStencilAttachment = &depRef;
        sp.pResolveAttachments = ms ? &resRef : nullptr;
        VkSubpassDependency dep{};
        dep.srcSubpass = VK_SUBPASS_EXTERNAL;
        dep.dstSubpass = 0;
        dep.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT | VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT;
        dep.dstStageMask = dep.srcStageMask;
        dep.srcAccessMask = VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
        dep.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
        VkRenderPassCreateInfo ri{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
        ri.attachmentCount = (uint32_t)att.size();
        ri.pAttachments = att.data();
        ri.subpassCount = 1;
        ri.pSubpasses = &sp;
        ri.dependencyCount = 1;
        ri.pDependencies = &dep;
        VKC(vkCreateRenderPass(dev_, &ri, nullptr, &mainPass_));
    }
    // ---- sombra: só profundidade, termina pronta para ser amostrada ----
    {
        VkAttachmentDescription d{};
        d.format = depthFmt_;
        d.samples = VK_SAMPLE_COUNT_1_BIT;
        d.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        d.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        d.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        d.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        d.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        d.finalLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
        VkAttachmentReference depRef{0, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
        VkSubpassDescription sp{};
        sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
        sp.pDepthStencilAttachment = &depRef;
        VkSubpassDependency deps[2]{};
        deps[0].srcSubpass = VK_SUBPASS_EXTERNAL;
        deps[0].dstSubpass = 0;
        deps[0].srcStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        deps[0].dstStageMask = VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT | VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT;
        deps[0].srcAccessMask = VK_ACCESS_SHADER_READ_BIT;
        deps[0].dstAccessMask = VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
        deps[1].srcSubpass = 0;
        deps[1].dstSubpass = VK_SUBPASS_EXTERNAL;
        deps[1].srcStageMask = VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT;
        deps[1].dstStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        deps[1].srcAccessMask = VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
        deps[1].dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
        VkRenderPassCreateInfo ri{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
        ri.attachmentCount = 1;
        ri.pAttachments = &d;
        ri.subpassCount = 1;
        ri.pSubpasses = &sp;
        ri.dependencyCount = 2;
        ri.pDependencies = deps;
        VKC(vkCreateRenderPass(dev_, &ri, nullptr, &shadowPass_));

        VkImageAspectFlags asp = VK_IMAGE_ASPECT_DEPTH_BIT;  // vista de amostragem: só a profundidade
        for (int i = 0; i < FRAMES; i++) {
            shadowImg_[i] = createImage(Cfg::SHADOW_RES, Cfg::SHADOW_RES, 1, 1, depthFmt_, VK_SAMPLE_COUNT_1_BIT,
                                        VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT, asp, false);
            VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
            fi.renderPass = shadowPass_;
            fi.attachmentCount = 1;
            fi.pAttachments = &shadowImg_[i].view;
            fi.width = fi.height = Cfg::SHADOW_RES;
            fi.layers = 1;
            VKC(vkCreateFramebuffer(dev_, &fi, nullptr, &shadowFb_[i]));
        }
    }
    return true;
}

// ======================================================================
//  Descritores
// ======================================================================
bool Renderer::createDescriptors() {
    VkDescriptorSetLayoutBinding b[5]{};
    b[0] = {0, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 1, VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT, nullptr};
    for (uint32_t i = 1; i < 5; i++) b[i] = {i, VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 1, VK_SHADER_STAGE_FRAGMENT_BIT, nullptr};
    VkDescriptorSetLayoutCreateInfo li{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    li.bindingCount = 5;
    li.pBindings = b;
    VKC(vkCreateDescriptorSetLayout(dev_, &li, nullptr, &dsl_));

    VkDescriptorPoolSize ps[2] = {{VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, FRAMES}, {VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 4 * FRAMES}};
    VkDescriptorPoolCreateInfo pi{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    pi.maxSets = FRAMES;
    pi.poolSizeCount = 2;
    pi.pPoolSizes = ps;
    VKC(vkCreateDescriptorPool(dev_, &pi, nullptr, &pool_));

    VkDescriptorSetLayout ls[FRAMES];
    for (int i = 0; i < FRAMES; i++) ls[i] = dsl_;
    VkDescriptorSetAllocateInfo ai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    ai.descriptorPool = pool_;
    ai.descriptorSetCount = FRAMES;
    ai.pSetLayouts = ls;
    VKC(vkAllocateDescriptorSets(dev_, &ai, sets_.data()));

    // samplers
    VkSamplerCreateInfo sci{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
    sci.magFilter = sci.minFilter = VK_FILTER_LINEAR;
    sci.mipmapMode = VK_SAMPLER_MIPMAP_MODE_LINEAR;
    sci.addressModeU = sci.addressModeV = sci.addressModeW = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_BORDER;
    sci.borderColor = VK_BORDER_COLOR_FLOAT_OPAQUE_WHITE;
    sci.compareEnable = VK_TRUE;
    sci.compareOp = VK_COMPARE_OP_LESS_OR_EQUAL;
    sci.maxLod = 0.f;
    VKC(vkCreateSampler(dev_, &sci, nullptr, &shadowSampler_));

    VkSamplerCreateInfo rs{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
    rs.magFilter = rs.minFilter = VK_FILTER_LINEAR;
    rs.mipmapMode = VK_SAMPLER_MIPMAP_MODE_LINEAR;
    rs.addressModeU = rs.addressModeV = rs.addressModeW = VK_SAMPLER_ADDRESS_MODE_REPEAT;
    rs.anisotropyEnable = anisotropy_ ? VK_TRUE : VK_FALSE;
    rs.maxAnisotropy = anisotropy_ ? std::min(16.f, props_.limits.maxSamplerAnisotropy) : 1.f;
    rs.maxLod = VK_LOD_CLAMP_NONE;
    VKC(vkCreateSampler(dev_, &rs, nullptr, &repeatSampler_));
    rs.maxAnisotropy = anisotropy_ ? std::min(8.f, props_.limits.maxSamplerAnisotropy) : 1.f;
    VKC(vkCreateSampler(dev_, &rs, nullptr, &waterSampler_));

    VkSamplerCreateInfo cs = rs;
    cs.addressModeU = cs.addressModeV = cs.addressModeW = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    cs.anisotropyEnable = VK_FALSE;
    cs.maxAnisotropy = 1.f;
    VKC(vkCreateSampler(dev_, &cs, nullptr, &clampSampler_));

    for (int i = 0; i < FRAMES; i++) {
        ubo_[i] = createBuffer(sizeof(FrameUBO), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
        VKC(vkMapMemory(dev_, ubo_[i].mem, 0, sizeof(FrameUBO), 0, &uboMap_[i]));
        std::memset(uboMap_[i], 0, sizeof(FrameUBO));
    }

    VkPushConstantRange pcr{VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT, 0, sizeof(PushC)};
    VkPipelineLayoutCreateInfo pl{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    pl.setLayoutCount = 1;
    pl.pSetLayouts = &dsl_;
    pl.pushConstantRangeCount = 1;
    pl.pPushConstantRanges = &pcr;
    VKC(vkCreatePipelineLayout(dev_, &pl, nullptr, &pipeLayout_));
    return true;
}

void Renderer::updateDescriptorSets() {
    for (int i = 0; i < FRAMES; i++) {
        VkDescriptorBufferInfo bi{ubo_[i].buf, 0, sizeof(FrameUBO)};
        VkDescriptorImageInfo sh{shadowSampler_, shadowImg_[i].view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
        VkDescriptorImageInfo tx{repeatSampler_, terrainTex_.view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
        VkDescriptorImageInfo wa{waterSampler_, waterTex_.view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
        VkDescriptorImageInfo gl{clampSampler_, glitTex_.view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
        VkWriteDescriptorSet w[5]{};
        for (int k = 0; k < 5; k++) {
            w[k].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
            w[k].dstSet = sets_[i];
            w[k].dstBinding = (uint32_t)k;
            w[k].descriptorCount = 1;
            w[k].descriptorType = k == 0 ? VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER : VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
        }
        w[0].pBufferInfo = &bi;
        w[1].pImageInfo = &sh;
        w[2].pImageInfo = &tx;
        w[3].pImageInfo = &wa;
        w[4].pImageInfo = &gl;
        vkUpdateDescriptorSets(dev_, 5, w, 0, nullptr);
    }
}

// ======================================================================
//  Pipelines
// ======================================================================
VkShaderModule Renderer::loadShader(const std::string& name) {
    std::string path = shaderDir_ + "/" + name + ".spv";
    size_t sz = 0;
    std::vector<uint32_t> code;
#ifdef __ANDROID__
    AAsset* asset = g_assets ? AAssetManager_open(g_assets, path.c_str(), AASSET_MODE_BUFFER) : nullptr;
    if (!asset) { std::fprintf(stderr, "Shader não encontrado nos assets: %s\n", path.c_str()); std::abort(); }
    sz = (size_t)AAsset_getLength(asset);
    code.resize((sz + 3) / 4);
    AAsset_read(asset, code.data(), sz);
    AAsset_close(asset);
#else
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) { std::fprintf(stderr, "Shader não encontrado: %s (compile com CMake: glslc)\n", path.c_str()); std::abort(); }
    sz = (size_t)f.tellg();
    code.resize((sz + 3) / 4);
    f.seekg(0);
    f.read((char*)code.data(), (std::streamsize)sz);
#endif
    VkShaderModuleCreateInfo mi{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    mi.codeSize = sz;
    mi.pCode = code.data();
    VkShaderModule m;
    VKC(vkCreateShaderModule(dev_, &mi, nullptr, &m));
    return m;
}

VkPipeline Renderer::makePipeline(const PipeDesc& d) {
    VkShaderModule vs = loadShader(d.vert);
    VkShaderModule fs = d.frag ? loadShader(d.frag) : VK_NULL_HANDLE;
    VkPipelineShaderStageCreateInfo st[2]{};
    st[0].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[0].stage = VK_SHADER_STAGE_VERTEX_BIT;
    st[0].module = vs;
    st[0].pName = "main";
    st[1] = st[0];
    st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT;
    st[1].module = fs;

    VkVertexInputBindingDescription bind[2] = {{0, sizeof(Vtx), VK_VERTEX_INPUT_RATE_VERTEX}, {1, sizeof(TreeInst), VK_VERTEX_INPUT_RATE_INSTANCE}};
    VkVertexInputAttributeDescription attr[6] = {
        {0, 0, VK_FORMAT_R32G32B32_SFLOAT, 0},   {1, 0, VK_FORMAT_R8G8B8A8_SNORM, 12},     {2, 0, VK_FORMAT_R8G8B8A8_UNORM, 16},
        {3, 0, VK_FORMAT_R32G32_SFLOAT, 20},     {4, 1, VK_FORMAT_R32G32B32A32_SFLOAT, 0}, {5, 1, VK_FORMAT_R32G32_SFLOAT, 16}};
    VkVertexInputBindingDescription pbind = {0, 12, VK_VERTEX_INPUT_RATE_VERTEX};
    VkVertexInputAttributeDescription pattr = {0, 0, VK_FORMAT_R32G32B32_SFLOAT, 0};
    VkPipelineVertexInputStateCreateInfo vi{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    if (d.vin == 1) { vi.vertexBindingDescriptionCount = 1; vi.pVertexBindingDescriptions = bind; vi.vertexAttributeDescriptionCount = 4; vi.pVertexAttributeDescriptions = attr; }
    else if (d.vin == 2) { vi.vertexBindingDescriptionCount = 2; vi.pVertexBindingDescriptions = bind; vi.vertexAttributeDescriptionCount = 6; vi.pVertexAttributeDescriptions = attr; }
    else if (d.vin == 3) { vi.vertexBindingDescriptionCount = 1; vi.pVertexBindingDescriptions = &pbind; vi.vertexAttributeDescriptionCount = 1; vi.pVertexAttributeDescriptions = &pattr; }

    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    vp.viewportCount = 1;
    vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    rs.polygonMode = VK_POLYGON_MODE_FILL;
    rs.cullMode = VK_CULL_MODE_NONE;  // folhas são de dois lados; o resto não precisa do ganho
    rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    rs.lineWidth = 1.f;
    rs.depthBiasEnable = d.bias ? VK_TRUE : VK_FALSE;
    rs.depthBiasConstantFactor = 1.5f;
    rs.depthBiasSlopeFactor = 2.0f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    ms.rasterizationSamples = d.samples;
    VkPipelineDepthStencilStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO};
    ds.depthTestEnable = d.depthTest ? VK_TRUE : VK_FALSE;
    ds.depthWriteEnable = d.depthWrite ? VK_TRUE : VK_FALSE;
    ds.depthCompareOp = VK_COMPARE_OP_LESS_OR_EQUAL;

    VkPipelineColorBlendAttachmentState ba{};
    ba.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
    if (d.blend != 0) {
        ba.blendEnable = VK_TRUE;
        ba.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
        ba.dstColorBlendFactor = d.blend == 1 ? VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA : VK_BLEND_FACTOR_ONE;
        ba.colorBlendOp = VK_BLEND_OP_ADD;
        ba.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
        ba.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;
        ba.alphaBlendOp = VK_BLEND_OP_ADD;
    }
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    cb.attachmentCount = d.frag ? 1 : 0;
    cb.pAttachments = &ba;
    VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo dy{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
    dy.dynamicStateCount = 2;
    dy.pDynamicStates = dyn;

    VkGraphicsPipelineCreateInfo gp{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
    gp.stageCount = d.frag ? 2 : 1;
    gp.pStages = st;
    gp.pVertexInputState = &vi;
    gp.pInputAssemblyState = &ia;
    gp.pViewportState = &vp;
    gp.pRasterizationState = &rs;
    gp.pMultisampleState = &ms;
    gp.pDepthStencilState = &ds;
    gp.pColorBlendState = &cb;
    gp.pDynamicState = &dy;
    gp.layout = pipeLayout_;
    gp.renderPass = d.rp;
    gp.subpass = 0;
    VkPipeline p;
    VKC(vkCreateGraphicsPipelines(dev_, VK_NULL_HANDLE, 1, &gp, nullptr, &p));
    vkDestroyShaderModule(dev_, vs, nullptr);
    if (fs) vkDestroyShaderModule(dev_, fs, nullptr);
    return p;
}

bool Renderer::createPipelines() {
    VkSampleCountFlagBits S = msaa_, S1 = VK_SAMPLE_COUNT_1_BIT;
    pSky_ = makePipeline({"sky.vert", "sky.frag", 0, false, false, 0, mainPass_, S, false});
    pScene_ = makePipeline({"scene.vert", "scene.frag", 1, true, true, 0, mainPass_, S, false});
    pTree_ = makePipeline({"tree.vert", "scene.frag", 2, true, true, 0, mainPass_, S, false});
    pWater_ = makePipeline({"water.vert", "water.frag", 3, true, false, 1, mainPass_, S, false});
    pFoam_ = makePipeline({"water.vert", "foam.frag", 3, true, false, 1, mainPass_, S, false});
    pGlit_ = makePipeline({"glitter.vert", "glitter.frag", 3, true, false, 2, mainPass_, S, false});
    pHud_ = makePipeline({"hud.vert", "hud.frag", 3, false, false, 1, mainPass_, S, false});
    pShadow_ = makePipeline({"shadow.vert", nullptr, 1, true, true, 0, shadowPass_, S1, true});
    pShadowTree_ = makePipeline({"shadow_tree.vert", nullptr, 2, true, true, 0, shadowPass_, S1, true});
    return true;
}

bool Renderer::createSyncAndCommands() {
    VkCommandPoolCreateInfo pi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    pi.queueFamilyIndex = qFamily_;
    pi.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    VKC(vkCreateCommandPool(dev_, &pi, nullptr, &cmdPool_));
    pi.flags = VK_COMMAND_POOL_CREATE_TRANSIENT_BIT;
    VKC(vkCreateCommandPool(dev_, &pi, nullptr, &upPool_));
    VkCommandBufferAllocateInfo ai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    ai.commandPool = cmdPool_;
    ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    ai.commandBufferCount = FRAMES;
    VKC(vkAllocateCommandBuffers(dev_, &ai, cmd_.data()));
    VkSemaphoreCreateInfo sci{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
    VkFenceCreateInfo fi{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    fi.flags = VK_FENCE_CREATE_SIGNALED_BIT;
    for (int i = 0; i < FRAMES; i++) {
        VKC(vkCreateSemaphore(dev_, &sci, nullptr, &imageAvail_[i]));
        VKC(vkCreateFence(dev_, &fi, nullptr, &inFlight_[i]));
    }
    VkFenceCreateInfo uf{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    VKC(vkCreateFence(dev_, &uf, nullptr, &upFence_));
    return true;
}

bool Renderer::init(NativeWin* w, const std::string& shaderDir) {
    win_ = w;
    shaderDir_ = shaderDir;
    if (!createInstanceAndDevice()) return false;
    if (!createSyncAndCommands()) return false;
    if (!createSwapchain()) return false;
    if (!createRenderPasses()) return false;
    if (!createFramebuffers()) return false;
    if (!createDescriptors()) return false;
    if (!createPipelines()) return false;
    std::printf("Vulkan pronto: %ux%u, MSAA %dx, sombra %d px\n", extent_.width, extent_.height, (int)msaa_, Cfg::SHADOW_RES);
    return true;
}

#include "RendererDraw.inc"
