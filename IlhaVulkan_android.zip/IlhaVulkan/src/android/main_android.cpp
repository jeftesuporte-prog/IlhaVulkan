// Ilha Gigante - versão Android (NativeActivity + android_native_app_glue + Vulkan).
// Controles de toque:
//   metade esquerda  : joystick flutuante (andar). Empurre até a borda para CORRER.
//   metade direita   : arraste para olhar em volta
//   botão grande     : pular
//   fileira do topo  : hora do dia (amanhecer, meio-dia, pôr do sol, noite) + acelerar o tempo (segurar)
#include <vulkan/vulkan.h>

#include <android/log.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <pthread.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <future>
#include <memory>
#include <string>
#include <thread>

#include "core/ChunkBuilder.h"
#include "core/Game.h"
#include "core/TexGen.h"
#include "core/Trees.h"
#include "core/World.h"
#include "vk/ChunkManager.h"
#include "vk/Renderer.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "IlhaVulkan", __VA_ARGS__)

// ---------------------------------------------------------------------------------------------
//  printf/fprintf -> logcat (o código compartilhado com o desktop usa printf)
// ---------------------------------------------------------------------------------------------
static int g_logPipe[2];
static void* logThread(void*) {
    char buf[1024];
    ssize_t n;
    while ((n = read(g_logPipe[0], buf, sizeof(buf) - 1)) > 0) {
        if (buf[n - 1] == '\n') n--;
        buf[n] = 0;
        __android_log_write(ANDROID_LOG_INFO, "IlhaVulkan", buf);
    }
    return nullptr;
}
static void redirectStdio() {
    setvbuf(stdout, nullptr, _IOLBF, 0);
    setvbuf(stderr, nullptr, _IONBF, 0);
    if (pipe(g_logPipe) != 0) return;
    dup2(g_logPipe[1], 1);
    dup2(g_logPipe[1], 2);
    pthread_t t;
    pthread_create(&t, nullptr, logThread, nullptr);
    pthread_detach(t);
}

// ---------------------------------------------------------------------------------------------
//  Tela cheia imersiva (esconde barras do sistema) via JNI
// ---------------------------------------------------------------------------------------------
static void enterImmersive(android_app* app) {
    JavaVM* vm = app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return;
    jobject activity = app->activity->clazz;
    jclass actCls = env->GetObjectClass(activity);
    jmethodID getWindow = env->GetMethodID(actCls, "getWindow", "()Landroid/view/Window;");
    jobject window = getWindow ? env->CallObjectMethod(activity, getWindow) : nullptr;
    if (window) {
        jclass winCls = env->GetObjectClass(window);
        jmethodID getDecor = env->GetMethodID(winCls, "getDecorView", "()Landroid/view/View;");
        jobject decor = getDecor ? env->CallObjectMethod(window, getDecor) : nullptr;
        if (decor) {
            jclass viewCls = env->GetObjectClass(decor);
            jmethodID setVis = env->GetMethodID(viewCls, "setSystemUiVisibility", "(I)V");
            // LAYOUT_STABLE | LAYOUT_HIDE_NAVIGATION | LAYOUT_FULLSCREEN | HIDE_NAVIGATION | FULLSCREEN | IMMERSIVE_STICKY
            if (setVis) env->CallVoidMethod(decor, setVis, 0x100 | 0x200 | 0x400 | 0x2 | 0x4 | 0x1000);
        }
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    vm->DetachCurrentThread();
}

// ---------------------------------------------------------------------------------------------
//  Conteúdo carregado em segundo plano (CPU): mundo, texturas procedurais e árvores
// ---------------------------------------------------------------------------------------------
struct Loaded {
    std::unique_ptr<TreeLib> trees;
    std::vector<TexGen::Image> terrainTex;
    TexGen::Image water, glitter;
};

static std::unique_ptr<Loaded> loadContent() {
    auto t0 = std::chrono::steady_clock::now();
    auto L = std::make_unique<Loaded>();
    World::init();
    auto fGrass = std::async(std::launch::async, [] { return TexGen::grass(); });
    auto fRock = std::async(std::launch::async, [] { return TexGen::rock(false); });
    auto fMoss = std::async(std::launch::async, [] { return TexGen::rock(true); });
    auto fSand = std::async(std::launch::async, [] { return TexGen::sand(); });
    auto fForest = std::async(std::launch::async, [] { return TexGen::forest(); });
    L->trees = std::make_unique<TreeLib>();
    L->terrainTex = {fSand.get(), fGrass.get(), fRock.get(), fMoss.get(), fForest.get()};
    TexGen::Image white;
    white.w = white.h = TexGen::S;
    white.rgba.assign((size_t)TexGen::S * TexGen::S * 4, 255);
    L->terrainTex.push_back(std::move(white));  // camada 5: "sem textura"
    L->water = TexGen::water();
    L->glitter = TexGen::glitter();
    LOGI("Mundo/texturas/árvores: %.2fs", std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
    return L;
}

// ---------------------------------------------------------------------------------------------
//  Estado do app + controles de toque
// ---------------------------------------------------------------------------------------------
enum Role { R_NONE = 0, R_STICK, R_LOOK, R_JUMP, R_TIME0, R_TIME1, R_TIME2, R_TIME3, R_FAST };

struct Ptr {
    int id = -1;
    Role role = R_NONE;
    float x = 0, y = 0, px = 0, py = 0;  // posição atual e anterior (pixels)
};

struct Layout {  // tudo em pixels, derivado da altura da tela
    float W, H, u;
    float jumpX, jumpY, jumpR;
    float btnR, btnY, btnX0, btnDX;  // fileira do topo: 4 horas + acelerar
    float stickX, stickY, stickR, knobR;
    float stickZoneX;
};

static Layout makeLayout(float W, float H) {
    Layout L;
    L.W = W; L.H = H; L.u = H;
    L.jumpR = 0.095f * H;
    L.jumpX = W - 0.16f * H;
    L.jumpY = H - 0.22f * H;
    L.btnR = 0.045f * H;
    L.btnY = 0.095f * H;
    L.btnDX = 0.115f * H;
    L.btnX0 = W - 0.09f * H - 4 * L.btnDX;  // primeiro botão (mais à esquerda)
    L.stickR = 0.15f * H;
    L.knobR = 0.065f * H;
    L.stickX = 0.24f * H;
    L.stickY = H - 0.26f * H;
    L.stickZoneX = W * 0.45f;
    return L;
}

static float timeBtnX(const Layout& L, int i) { return L.btnX0 + i * L.btnDX; }

struct App {
    android_app* app = nullptr;
    Renderer renderer;
    bool rendererReady = false;
    bool resumed = false;
    ANativeWindow* window = nullptr;

    std::future<std::unique_ptr<Loaded>> loading;
    std::unique_ptr<Loaded> loaded;

    SolidMap solids;
    std::unique_ptr<ChunkManager> chunks;
    Player player;
    SkyState sky;
    float yaw = std::atan2(-0.6f, 0.8f), pitch = 0.45f;

    Ptr ptrs[10];
    float stickOX = 0, stickOY = 0, stickDX = 0, stickDY = 0;  // origem do joystick (px) e deslocamento (-1..1)
    bool stickActive = false;
    bool jumpHeld = false, fastHeld = false;
    int timePressed = -1;  // botão de hora tocado neste quadro (consumido no loop)
    float lastLookDX = 0, lastLookDY = 0;
    float lookDX = 0, lookDY = 0;  // acumulado desde o último quadro (px)

    float time = 0.f;
    std::chrono::steady_clock::time_point last;
    double fpsT = 0;
    int fpsFrames = 0;
};
static App g;

static float dist2(float ax, float ay, float bx, float by) { return (ax - bx) * (ax - bx) + (ay - by) * (ay - by); }

static Role classify(const Layout& L, float x, float y) {
    if (dist2(x, y, L.jumpX, L.jumpY) < (L.jumpR * 1.35f) * (L.jumpR * 1.35f)) return R_JUMP;
    for (int i = 0; i < 4; i++)
        if (dist2(x, y, timeBtnX(L, i), L.btnY) < (L.btnR * 1.4f) * (L.btnR * 1.4f)) return (Role)(R_TIME0 + i);
    if (dist2(x, y, timeBtnX(L, 4), L.btnY) < (L.btnR * 1.4f) * (L.btnR * 1.4f)) return R_FAST;
    if (x < L.stickZoneX && y > L.H * 0.2f) return R_STICK;
    return R_LOOK;
}

static void recomputeHeld() {
    g.jumpHeld = g.fastHeld = false;
    g.stickActive = false;
    for (auto& p : g.ptrs) {
        if (p.id < 0) continue;
        if (p.role == R_JUMP) g.jumpHeld = true;
        if (p.role == R_FAST) g.fastHeld = true;
        if (p.role == R_STICK) g.stickActive = true;
    }
    if (!g.stickActive) g.stickDX = g.stickDY = 0.f;
}

static void touchDown(int id, float x, float y) {
    Layout L = makeLayout((float)std::max(1u, g.renderer.width()), (float)std::max(1u, g.renderer.height()));
    Ptr* slot = nullptr;
    for (auto& p : g.ptrs) {
        if (p.id == id) { slot = &p; break; }
        if (p.id < 0 && !slot) slot = &p;
    }
    if (!slot) return;
    Role r = classify(L, x, y);
    if (r == R_STICK && g.stickActive) r = R_LOOK;  // já tem um dedo no joystick
    slot->id = id; slot->role = r; slot->x = slot->px = x; slot->y = slot->py = y;
    if (r == R_STICK) {
        g.stickOX = std::clamp(x, L.stickR, L.stickZoneX);
        g.stickOY = std::clamp(y, L.stickR + L.H * 0.2f, L.H - L.stickR);
        g.stickDX = g.stickDY = 0.f;
    }
    if (r >= R_TIME0 && r <= R_TIME3) g.timePressed = r - R_TIME0;
    recomputeHeld();
}

static void touchMove(int id, float x, float y) {
    Layout L = makeLayout((float)std::max(1u, g.renderer.width()), (float)std::max(1u, g.renderer.height()));
    for (auto& p : g.ptrs) {
        if (p.id != id) continue;
        p.px = p.x; p.py = p.y; p.x = x; p.y = y;
        if (p.role == R_LOOK) { g.lookDX += p.x - p.px; g.lookDY += p.y - p.py; }
        if (p.role == R_STICK) {
            float dx = (x - g.stickOX) / L.stickR, dy = (y - g.stickOY) / L.stickR;
            float l = std::sqrt(dx * dx + dy * dy);
            if (l > 1.f) { dx /= l; dy /= l; }
            g.stickDX = dx; g.stickDY = dy;
        }
    }
}

static void touchUp(int id) {
    for (auto& p : g.ptrs)
        if (p.id == id) p.id = -1, p.role = R_NONE;
    recomputeHeld();
}

static int32_t onInput(android_app*, AInputEvent* ev) {
    if (AInputEvent_getType(ev) != AINPUT_EVENT_TYPE_MOTION) return 0;
    int32_t action = AMotionEvent_getAction(ev);
    int32_t act = action & AMOTION_EVENT_ACTION_MASK;
    size_t idx = (size_t)((action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT);
    switch (act) {
        case AMOTION_EVENT_ACTION_DOWN:
        case AMOTION_EVENT_ACTION_POINTER_DOWN:
            touchDown(AMotionEvent_getPointerId(ev, idx), AMotionEvent_getX(ev, idx), AMotionEvent_getY(ev, idx));
            break;
        case AMOTION_EVENT_ACTION_MOVE:
            for (size_t i = 0; i < AMotionEvent_getPointerCount(ev); i++)
                touchMove(AMotionEvent_getPointerId(ev, i), AMotionEvent_getX(ev, i), AMotionEvent_getY(ev, i));
            break;
        case AMOTION_EVENT_ACTION_UP:
        case AMOTION_EVENT_ACTION_POINTER_UP:
            touchUp(AMotionEvent_getPointerId(ev, idx));
            break;
        case AMOTION_EVENT_ACTION_CANCEL:
            for (auto& p : g.ptrs) p.id = -1, p.role = R_NONE;
            recomputeHeld();
            break;
        default: break;
    }
    return 1;
}

// ---------------------------------------------------------------------------------------------
//  HUD (desenhado pelo Renderer; sem texto, só formas coloridas)
// ---------------------------------------------------------------------------------------------
static void shape(std::vector<HudShape>& v, const Layout& L, float cx, float cy, float r, float R, float G, float B, float A, bool ring) {
    v.push_back({cx / L.W * 2.f - 1.f, cy / L.H * 2.f - 1.f, r * 2.f / L.W, r * 2.f / L.H, R, G, B, A, ring});
}

static void buildHud(std::vector<HudShape>& v) {
    Layout L = makeLayout((float)g.renderer.width(), (float)g.renderer.height());
    // joystick (dica fraca quando parado)
    float sx = g.stickActive ? g.stickOX : L.stickX, sy = g.stickActive ? g.stickOY : L.stickY;
    float a = g.stickActive ? 1.f : 0.45f;
    shape(v, L, sx, sy, L.stickR, 1, 1, 1, 0.10f * a, false);
    shape(v, L, sx, sy, L.stickR, 1, 1, 1, 0.45f * a, true);
    float kx = sx + g.stickDX * L.stickR, ky = sy + g.stickDY * L.stickR;
    bool run = std::sqrt(g.stickDX * g.stickDX + g.stickDY * g.stickDY) > 0.85f;
    if (g.stickActive) {
        if (run) shape(v, L, sx, sy, L.stickR * 1.12f, 1.f, 0.85f, 0.3f, 0.6f, true);  // anel dourado = correndo
        shape(v, L, kx, ky, L.knobR, 1, 1, 1, run ? 0.75f : 0.5f, false);
    } else {
        shape(v, L, sx, sy, L.knobR, 1, 1, 1, 0.22f, false);
    }
    // pular
    shape(v, L, L.jumpX, L.jumpY, L.jumpR, 1, 1, 1, g.jumpHeld ? 0.45f : 0.18f, false);
    shape(v, L, L.jumpX, L.jumpY, L.jumpR, 1, 1, 1, 0.55f, true);
    shape(v, L, L.jumpX, L.jumpY + L.jumpR * 0.05f, L.jumpR * 0.30f, 1, 1, 1, 0.55f, true);  // pictograma simples
    // hora do dia
    const float col[4][3] = {{1.0f, 0.62f, 0.30f}, {1.0f, 0.93f, 0.35f}, {0.95f, 0.38f, 0.25f}, {0.28f, 0.34f, 0.80f}};
    for (int i = 0; i < 4; i++) {
        shape(v, L, timeBtnX(L, i), L.btnY, L.btnR, col[i][0], col[i][1], col[i][2], 0.55f, false);
        shape(v, L, timeBtnX(L, i), L.btnY, L.btnR, 1, 1, 1, 0.65f, true);
    }
    shape(v, L, timeBtnX(L, 4), L.btnY, L.btnR, 0.75f, 0.9f, 1.f, g.fastHeld ? 0.85f : 0.35f, false);
    shape(v, L, timeBtnX(L, 4), L.btnY, L.btnR, 1, 1, 1, 0.65f, true);
    shape(v, L, timeBtnX(L, 4) - L.btnR * 0.25f, L.btnY, L.btnR * 0.28f, 1, 1, 1, 0.75f, false);  // "avançar"
    shape(v, L, timeBtnX(L, 4) + L.btnR * 0.30f, L.btnY, L.btnR * 0.28f, 1, 1, 1, 0.75f, false);
}

// ---------------------------------------------------------------------------------------------
//  Ciclo de vida
// ---------------------------------------------------------------------------------------------
static void initRendererIfPossible() {
    if (g.rendererReady || !g.window || !g.loading.valid()) return;
    if (g.loading.wait_for(std::chrono::seconds(0)) != std::future_status::ready) return;
    g.loaded = g.loading.get();

    auto t0 = std::chrono::steady_clock::now();
    if (!g.renderer.init(g.window, "shaders")) { LOGI("Falha ao iniciar o Vulkan"); ANativeActivity_finish(g.app->activity); return; }
    g.renderer.uploadStatic(*g.loaded->trees, g.loaded->terrainTex, g.loaded->water, g.loaded->glitter);
    g.loaded.reset();  // a CPU não precisa mais das cópias

    int nth = std::clamp((int)std::thread::hardware_concurrency() - 1, 1, 3);
    g.chunks = std::make_unique<ChunkManager>(g.renderer, g.solids, nth);
    g.player.place(RoadNet::startX, RoadNet::startZ, 0.f);
    g.chunks->warmup(g.player.pos.x, g.player.pos.z, 120.f);
    LOGI("Vulkan + chunks iniciais: %.2fs", std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
    g.rendererReady = true;
    g.last = std::chrono::steady_clock::now();
}

static void onCmd(android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            g.window = app->window;
            enterImmersive(app);
            if (g.rendererReady) {
                if (!g.renderer.attachSurface(g.window)) ANativeActivity_finish(app->activity);
            }
            break;
        case APP_CMD_TERM_WINDOW:
            if (g.rendererReady) g.renderer.releaseSurface();
            g.window = nullptr;
            break;
        case APP_CMD_WINDOW_RESIZED:
        case APP_CMD_CONFIG_CHANGED:
        case APP_CMD_CONTENT_RECT_CHANGED:
            if (g.rendererReady) g.renderer.setFramebufferResized();
            break;
        case APP_CMD_RESUME: g.resumed = true; g.last = std::chrono::steady_clock::now(); break;
        case APP_CMD_PAUSE:
            g.resumed = false;
            for (auto& p : g.ptrs) p.id = -1, p.role = R_NONE;
            recomputeHeld();
            break;
        case APP_CMD_GAINED_FOCUS: enterImmersive(app); break;
        default: break;
    }
}

static void frame() {
    auto now = std::chrono::steady_clock::now();
    float dt = std::min(std::chrono::duration<float>(now - g.last).count(), 0.05f);
    g.last = now;
    g.time += dt;

    Layout L = makeLayout((float)g.renderer.width(), (float)g.renderer.height());

    // ---- olhar ----
    const float sens = 3.2f / L.H;  // radianos por pixel: arrastar a altura da tela gira ~3.2 rad
    g.yaw += g.lookDX * sens;
    g.pitch = clampf(g.pitch + g.lookDY * sens, -0.9f, 1.2f);
    g.lookDX = g.lookDY = 0.f;

    // ---- hora do dia ----
    if (g.timePressed >= 0) {
        const float hours[4] = {6.2f, 12.f, 18.2f, 23.f};
        g.sky.tod = hours[g.timePressed];
        g.timePressed = -1;
    }

    // ---- movimento ----
    float fx = std::cos(g.yaw), fz = std::sin(g.yaw);
    float mvY = -g.stickDY, mvX = g.stickDX;  // tela: para cima = frente
    float mag = std::sqrt(mvX * mvX + mvY * mvY);
    if (mag > 0.12f) {
        float dx = fx * mvY - fz * mvX, dz = fz * mvY + fx * mvX;
        float dl = std::sqrt(dx * dx + dz * dz);
        float speed = mag > 0.85f ? 8.f : 4.2f;
        g.player.move(dx / dl, dz / dl, dt, speed, g.solids);
    }
    if (g.jumpHeld) g.player.jump();
    g.player.physics(dt);

    g.sky.update(dt * (g.fastHeld ? 40.f : 1.f), g.yaw);
    g.chunks->update(g.player.pos.x, g.player.pos.z);

    // ---- câmera em 3ª pessoa ----
    Vec3 target(g.player.pos.x, g.player.pos.y + 1.4f, g.player.pos.z);
    const float dist = 5.5f;
    float cp = std::cos(g.pitch), sp = std::sin(g.pitch);
    Vec3 cam(target.x - fx * cp * dist, target.y + sp * dist, target.z - fz * cp * dist);
    cam.y = std::max(cam.y, std::max(World::heightAt(cam.x, cam.z), 0.f) + 0.6f);

    FrameParams fp;
    fp.view = Mat4::lookAt(cam, target, Vec3(0, 1, 0));
    fp.proj = Mat4::perspective(67.f * PI_F / 180.f, g.renderer.aspect(), 0.4f, 1000.f);
    fp.camPos = cam;
    fp.playerPos = g.player.pos;
    fp.playerHeadingDeg = g.player.heading;
    fp.time = g.time;
    fp.sky = &g.sky;
    buildHud(fp.hud);
    if (!g.renderer.drawFrame(fp)) { LOGI("drawFrame falhou; encerrando"); ANativeActivity_finish(g.app->activity); }

    g.fpsFrames++;
    g.fpsT += dt;
    if (g.fpsT >= 3.0) {
        LOGI("%.0f FPS | hora %.1f | chunks %d+%d | árvores %d", g.fpsFrames / g.fpsT, g.sky.tod, g.renderer.stats().terrainChunks,
             g.renderer.stats().decoChunks, g.renderer.stats().drawnTreeInstances);
        g.fpsFrames = 0;
        g.fpsT = 0;
    }
}

void android_main(android_app* app) {
    redirectStdio();
    LOGI("Ilha Gigante iniciando");
    g.app = app;
    app->userData = &g;
    app->onAppCmd = onCmd;
    app->onInputEvent = onInput;
    Renderer::setAssetManager(app->activity->assetManager);
    g.loading = std::async(std::launch::async, loadContent);  // enquanto isso a janela já pode abrir

    while (true) {
        bool drawing = g.rendererReady && g.window && g.resumed && g.renderer.hasSurface();
        int events = 0;
        android_poll_source* src = nullptr;
        // desenhando: não espera; carregando/pausado: acorda a cada 50 ms (ou com eventos)
        while (ALooper_pollOnce(drawing ? 0 : 50, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) goto done;
            drawing = g.rendererReady && g.window && g.resumed && g.renderer.hasSurface();
        }
        if (app->destroyRequested) break;
        if (!g.rendererReady) initRendererIfPossible();
        else if (g.window && g.resumed && g.renderer.hasSurface()) frame();
    }
done:
    g.chunks.reset();
    if (g.rendererReady) { g.renderer.waitIdle(); g.renderer.shutdown(); }
    g.rendererReady = false;
    LOGI("Ilha Gigante encerrada");
}
