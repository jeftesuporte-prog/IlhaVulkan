# Ilha Gigante — C++ / Vulkan

Reescrita completa do projeto **IlhaFreeFire_v2** (Kotlin / LibGDX) em **C++17 + Vulkan**, mantendo
**o mesmo mapa, a mesma lógica, as mesmas cores e o mesmo design**, com gráficos bem mais bonitos.

## Compilar e rodar

Precisa de: **CMake ≥ 3.16**, compilador C++17, **Vulkan SDK** (traz o `glslc`) e **GLFW** (se não achar, o CMake baixa sozinho).

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
./build/ilha          # Windows: build\Release\ilha.exe
```

Os shaders `.glsl` são compilados para SPIR-V automaticamente (pasta `build/shaders`).
Para depurar com as camadas de validação: `ILHA_VALIDATION=1 ./build/ilha`.

Controles: **WASD** andar · **mouse** olhar · **Shift** correr · **Espaço** pular · **Esc** solta o mouse ·
**1/2/3/4** amanhecer / meio-dia / pôr do sol / noite · **T** (segurando) acelera o tempo · **F11** tela cheia.
O FPS, a hora e o nº de chunks aparecem no título da janela.

## O que foi mantido (port 1:1)

| Original (Kotlin) | Agora (C++) |
|---|---|
| `SimplexNoise.java` + `java.util.Random` | `core/Simplex.h`, `core/JavaRandom.h` — o gerador do Java foi reproduzido bit a bit, então **a ilha e a posição de cada árvore saem iguais** |
| `Cfg.kt`, `World.kt` (ilha, 4 montanhas, estrada em espiral, rio, ponte, píer, cores do terreno) | `core/Cfg.h`, `core/World.cpp` |
| `ChunkBuilder.kt` (terreno em 5 materiais, floresta, bananal, pomar em xadrez, coqueiros, arbustos, pedras, flores) | `core/ChunkBuilder.cpp` — mesma ordem de sorteios e mesmas regras de colocação |
| `TexGen.kt`, `Water.kt` (texturas procedurais) | `core/TexGen.cpp` (grama, pedra, pedra c/ musgo, areia, chão da floresta, água, brilho) |
| `Player.kt`, colisão de troncos/pedras, grades da ponte | `core/Game.cpp` |
| `Sky.kt` (ciclo de 10 min, tabela de cores por hora, sol, lua, estrelas, meteoros) | tabela em `core/Game.cpp`; desenho em `shaders/sky.frag` |
| Píer, ponte, barquinho, boneco de 1,75 m | `Props::pier/bridge/player` |

## O que ficou melhor

* **Árvores novas** (as das imagens de referência, mesmas espécies do app): árvore grande (TREE_01), macieira,
  laranjeira, bananeira, coqueiro reto e coqueiro torto. Troncos torcidos com raízes e casca facetada, galhos,
  copas cobertas de folhas em losango dobradas em 3 tons de verde, frutas redondas. **6 espécies × 3–6 variantes × 2 níveis de detalhe.**
* **Instanciamento**: 1 malha por variante, milhares de cópias (rotação, escala e tom por árvore) + **vento** balançando as copas.
  Perto do boneco usa o modelo detalhado (~1,5–5,6 mil triângulos), longe o leve (~0,5–1,4 mil).
* **Sombras** em tempo real do sol e da lua (mapa 2048², PCF suave, sem tremer quando o boneco anda).
* **MSAA 4×**, filtro anisotrópico 16× e texturas em **512 px** (original: 256) com mipmaps.
* Terreno com **o dobro de resolução** (células de 1,25 m; original 2,5 m).
* **Céu procedural por pixel**: nuvens que andam com o vento, estrelas que piscam, via láctea, lua low-poly com crateras hexagonais,
  sol com raios, brilho rosado no horizonte, estrelas cadentes — tudo com as cores originais.
* **Água** com ondulações animadas, reflexo do céu (fresnel) e brilho do sol/lua; espuma nos mesmos 3 anéis.
* As cores são escritas direto na tela (formato UNORM, sem sRGB), exatamente como no app, para o visual não mudar.

## Ajustes rápidos (`src/core/Cfg.h`)

`LOD0_DIST` (até onde as árvores ficam detalhadas) · `SHADOW_RES` / `SHADOW_EXTENT` (qualidade e alcance da sombra) ·
`MSAA` (1, 2, 4, 8) · `CELLS` (resolução do terreno) · `DECO_R` / `TERRAIN_R` (alcance de desenho).

## Estrutura

```
src/core/   lógica do jogo, SEM Vulkan (mundo, chunks, árvores, física, céu)  -> testável sozinha
src/vk/     Renderer (Vulkan), ChunkManager (threads de fundo)
shaders/    GLSL 450 (scene, tree, shadow, sky, water, foam, glitter)
tests/      testes do núcleo  (cmake -DILHA_TESTS=ON)
tools/      preview.py: rasteriza as árvores em PNG para conferir com as imagens de referência
```

## Android

Projeto em `android/` (NativeActivity + `android_native_app_glue`, sem código Java). O núcleo `src/core` e o `Renderer` são os **mesmos** do desktop;
o que muda fica atrás de `#ifdef __ANDROID__` (surface Android, shaders lidos dos assets, ciclo de vida) e em `src/android/main_android.cpp`.

**Compilar:** abra a pasta `android/` no **Android Studio** (Hedgehog ou mais novo). Em *SDK Manager → SDK Tools* instale **NDK (Side by side)** e
**CMake 3.22.1**. Conecte um celular com **Android 10+ e Vulkan 1.1** (depuração USB ligada) e clique em *Run*.
Para gerar o APK: *Build → Build Bundle(s) / APK(s) → Build APK(s)* (sai em `android/app/build/outputs/apk/`).

Os shaders de `shaders/` são compilados pelo Gradle (glslc do NDK) e vão para `assets/shaders/*.spv`.

**Controles de toque:** metade esquerda = joystick flutuante (até a borda = correr) · metade direita = arrastar para olhar ·
botão grande = pular · fileira de bolinhas no topo = amanhecer / meio-dia / pôr do sol / noite / (segurar) acelerar o tempo.

**Ajustes para celular** (só no Android, em `src/core/Cfg.h`): terreno 60×60 células por chunk, vegetação até 190 m, sombra 1024² com alcance 90 m,
detalhe alto das árvores até 55 m. MSAA 4× e filtro anisotrópico continuam (limitados pelo que o aparelho suporta). Se travar, baixe `MSAA`/`DECO_R`;
se sobrar desempenho, suba-os para os valores do desktop.

## Limitações conhecidas

* Desktop: **Windows / Linux** (GLFW + Vulkan). macOS exigiria MoltenVK + extensão de portabilidade.
* Sem HUD de texto (no desktop as informações ficam no título da janela; no Android, o FPS vai para o `logcat`, tag `IlhaVulkan`).
* Android: só `arm64-v8a` por padrão, tela travada na horizontal, sem margem de segurança para recortes de tela além do modo `shortEdges`.
