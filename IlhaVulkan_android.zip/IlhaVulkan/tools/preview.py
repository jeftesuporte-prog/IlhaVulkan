import numpy as np, sys
from PIL import Image
dt=np.dtype([('p','<f4',3),('n','u1',4),('c','u1',4),('uv','<f4',2)])
def load(fn): return np.fromfile(fn,dtype=dt)
def render(v,W=500,H=700,yaw=0.5,pitch=0.12):
    P=v['p'].astype(np.float64); N=v['n'].astype(np.int8).astype(np.float64)[:,:3]/127.0; C=v['c'][:,:3]/255.0
    lo=P.min(0); hi=P.max(0); ctr=(lo+hi)/2; size=max(hi[1]-lo[1],(hi[0]-lo[0])*1.2,(hi[2]-lo[2])*1.2)
    cy,sy=np.cos(yaw),np.sin(yaw)
    R=np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]])
    Pc=(P-ctr)@R.T; Nc=N@R.T
    scale=H*0.9/size
    X=Pc[:,0]*scale+W/2; Y=H/2-Pc[:,1]*scale; Z=Pc[:,2]
    L=np.array([0.5,0.8,0.4]); L/=np.linalg.norm(L)
    img=np.ones((H,W,3))*np.array([0.85,0.92,1.0]); zb=np.full((H,W),-1e9)
    for t in range(0,len(P),3):
        xs=X[t:t+3]; ys=Y[t:t+3]; zs=Z[t:t+3]
        x0=int(max(0,np.floor(xs.min()))); x1=int(min(W-1,np.ceil(xs.max())))
        y0=int(max(0,np.floor(ys.min()))); y1=int(min(H-1,np.ceil(ys.max())))
        if x1<x0 or y1<y0: continue
        d=(ys[1]-ys[2])*(xs[0]-xs[2])+(xs[2]-xs[1])*(ys[0]-ys[2])
        if abs(d)<1e-9: continue
        gx,gy=np.meshgrid(np.arange(x0,x1+1)+0.5,np.arange(y0,y1+1)+0.5)
        a=((ys[1]-ys[2])*(gx-xs[2])+(xs[2]-xs[1])*(gy-ys[2]))/d
        b=((ys[2]-ys[0])*(gx-xs[2])+(xs[0]-xs[2])*(gy-ys[2]))/d
        c=1-a-b
        m=(a>=0)&(b>=0)&(c>=0)
        if not m.any(): continue
        z=a*zs[0]+b*zs[1]+c*zs[2]
        sub=zb[y0:y1+1,x0:x1+1]
        mm=m&(z>sub)
        if not mm.any(): continue
        n=Nc[t]; lam=max(0,n@L)
        col=C[t]*(0.40+0.75*lam)
        sub[mm]=z[mm]
        img[y0:y1+1,x0:x1+1][mm]=np.clip(col,0,1)
    return Image.fromarray((img*255).astype(np.uint8))
names=sys.argv[2:]; out=sys.argv[1]
ims=[render(load(f'/tmp/tree_{n}.bin')) for n in names]
sheet=Image.new('RGB',(500*len(ims),700))
for i,im in enumerate(ims): sheet.paste(im,(i*500,0))
sheet.save(out)
