#version 450
// Anéis de espuma branca em volta da ilha (opacidade pulsando, vinda do push constant).
layout(location = 0) in vec3 vWorld;
layout(set = 0, binding = 0, std140) uniform Frame {
    mat4 viewProj;
    mat4 invViewProj;
    mat4 lightViewProj;
    vec4 camPos;
    vec4 lightDir;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 skyTop;
    vec4 skyHor;
    vec4 sunDir;
    vec4 moonDir;
    vec4 meteorA[4];
    vec4 meteorB[4];
    vec4 meteorC[4];
} F;
layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;
    vec4 p1;
} pc;
layout(location = 0) out vec4 outColor;
void main() {
    vec3 L = normalize(F.lightDir.xyz);
    vec3 col = min(vec3(1.0) * (F.ambient.rgb + F.lightColor.rgb * max(L.y, 0.0)), vec3(1.0));
    float d = length(vWorld - F.camPos.xyz);
    float fog = min(d * d / (F.ambient.w * F.ambient.w), 1.0);
    outColor = vec4(mix(col, F.fogColor.rgb, fog), pc.p0.w);
}
