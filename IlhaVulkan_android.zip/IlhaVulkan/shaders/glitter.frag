#version 450
layout(location = 0) in vec2 vUV;
layout(set = 0, binding = 4) uniform sampler2D uGlit;
layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;  // rgb = cor do brilho (já multiplicada pela força)
    vec4 p1;
} pc;
layout(location = 0) out vec4 outColor;
void main() { outColor = vec4(pc.p0.rgb, texture(uGlit, vUV).a); }  // mistura aditiva (SRC_ALPHA, ONE)
