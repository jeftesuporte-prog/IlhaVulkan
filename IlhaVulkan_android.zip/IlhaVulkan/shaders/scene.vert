#version 450
// Geometria estática (chunks de terreno/pedras/arbustos, píer, ponte, boneco).

layout(location = 0) in vec3 inPos;
layout(location = 1) in vec4 inNrm;  // snorm8x4 -> [-1,1]
layout(location = 2) in vec4 inCol;  // unorm8x4
layout(location = 3) in vec2 inUV;

layout(set = 0, binding = 0, std140) uniform Frame {
    mat4 viewProj;
    mat4 invViewProj;
    mat4 lightViewProj;
    vec4 camPos;
    vec4 lightDir;    // xyz = direção PARA a luz, w = tempo (s)
    vec4 lightColor;  // rgb, w = força da sombra
    vec4 ambient;     // rgb, w = distância da névoa (far)
    vec4 fogColor;    // rgb, w = noite (0..1)
    vec4 skyTop;      // rgb, w = elevação do sol
    vec4 skyHor;      // rgb, w = hora do dia
    vec4 sunDir;
    vec4 moonDir;
    vec4 meteorA[4];
    vec4 meteorB[4];
    vec4 meteorC[4];
} F;

layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;
    vec4 p1;
} pc;

layout(location = 0) out vec3 vWorld;
layout(location = 1) out vec3 vNrm;
layout(location = 2) out vec4 vCol;
layout(location = 3) out vec2 vUV;

void main() {
    vec4 w = pc.model * vec4(inPos, 1.0);
    vWorld = w.xyz;
    vNrm = mat3(pc.model) * inNrm.xyz;
    vCol = inCol;
    vUV = inUV;
    gl_Position = F.viewProj * w;
}
