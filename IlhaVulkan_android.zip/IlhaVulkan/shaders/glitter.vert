#version 450
// Faixa de brilho do sol/lua na água: um quadrado grande que fica na direção do astro.
layout(location = 0) in vec3 inPos;
layout(set = 0, binding = 0, std140) uniform Frame {
    mat4 viewProj;
    mat4 invViewProj;
    mat4 lightViewProj;
    vec4 camPos;
    vec4 lightDir;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 skyTop;
    vec4 skyHor;
    vec4 sunDir;
    vec4 moonDir;
    vec4 meteorA[4];
    vec4 meteorB[4];
    vec4 meteorC[4];
} F;
layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;
    vec4 p1;
} pc;
layout(location = 0) out vec2 vUV;
void main() {
    vUV = inPos.xz + 0.5;
    gl_Position = F.viewProj * (pc.model * vec4(inPos, 1.0));
}
