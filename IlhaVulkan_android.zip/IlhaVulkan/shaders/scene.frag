#version 450
// Iluminação do mundo: ambiente do céu + luz do sol/lua com sombras suaves (PCF) + textura procedural + névoa quadrática
// (a mesma névoa do libGDX original: (distância / far)^2).

layout(location = 0) in vec3 vWorld;
layout(location = 1) in vec3 vNrm;
layout(location = 2) in vec4 vCol;
layout(location = 3) in vec2 vUV;

layout(set = 0, binding = 0, std140) uniform Frame {
    mat4 viewProj;
    mat4 invViewProj;
    mat4 lightViewProj;
    vec4 camPos;
    vec4 lightDir;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 skyTop;
    vec4 skyHor;
    vec4 sunDir;
    vec4 moonDir;
    vec4 meteorA[4];
    vec4 meteorB[4];
    vec4 meteorC[4];
} F;

layout(set = 0, binding = 1) uniform sampler2DShadow uShadow;
layout(set = 0, binding = 2) uniform sampler2DArray uTex;

layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;  // x = camada da textura, y = força do brilho especular, z = brilho (shininess)
    vec4 p1;
} pc;

layout(location = 0) out vec4 outColor;

float shadowVis(vec3 wp, vec3 n) {
    vec4 lp = F.lightViewProj * vec4(wp + n * 0.10, 1.0);
    vec3 sc = vec3(lp.xy * 0.5 + 0.5, lp.z);
    if (sc.x < 0.0 || sc.x > 1.0 || sc.y < 0.0 || sc.y > 1.0 || sc.z > 1.0) return 1.0;
    sc.z -= 0.0007;
    vec2 texel = 1.0 / vec2(textureSize(uShadow, 0));
    float s = 0.0;
    for (int y = -1; y <= 1; y++)
        for (int x = -1; x <= 1; x++) s += texture(uShadow, vec3(sc.xy + vec2(x, y) * texel * 1.25, sc.z));
    s /= 9.0;
    vec2 e = min(sc.xy, 1.0 - sc.xy);
    float edge = smoothstep(0.0, 0.08, min(e.x, e.y));  // some a sombra suavemente na borda do mapa
    return mix(1.0, s, edge);
}

void main() {
    vec3 N = normalize(vNrm);
    vec3 L = normalize(F.lightDir.xyz);
    vec3 tex = texture(uTex, vec3(vUV, pc.p0.x)).rgb;
    vec3 base = vCol.rgb * tex;

    float ndl = max(dot(N, L), 0.0);
    float vis = 1.0;
    if (ndl > 0.0 && F.lightColor.w > 0.01) vis = mix(1.0, shadowVis(vWorld, N), F.lightColor.w);

    vec3 amb = F.ambient.rgb * mix(0.80, 1.06, N.y * 0.5 + 0.5);
    vec3 col = base * (amb + F.lightColor.rgb * ndl * vis);

    if (pc.p0.y > 0.0) {  // brilho da areia (especular do sol)
        vec3 V = normalize(F.camPos.xyz - vWorld);
        vec3 H = normalize(L + V);
        col += vec3(0.45, 0.42, 0.32) * pc.p0.y * pow(max(dot(N, H), 0.0), pc.p0.z) * ndl * vis * F.lightColor.rgb;
    }

    float d = length(vWorld - F.camPos.xyz);
    float fog = min(d * d / (F.ambient.w * F.ambient.w), 1.0);
    outColor = vec4(mix(col, F.fogColor.rgb, fog), 1.0);
}
