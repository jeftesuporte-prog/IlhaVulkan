#version 450
// HUD de toque: disco/anel unitário no plano XY, posicionado e escalado direto em NDC pela matriz do push constant.
layout(location = 0) in vec3 inPos;
layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;
    vec4 p1;
} pc;
void main() { gl_Position = pc.model * vec4(inPos, 1.0); }
