#version 450
// Plano do mar e anéis de espuma (posições já em coordenadas do mundo).
layout(location = 0) in vec3 inPos;
layout(set = 0, binding = 0, std140) uniform Frame {
    mat4 viewProj;
    mat4 invViewProj;
    mat4 lightViewProj;
    vec4 camPos;
    vec4 lightDir;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 skyTop;
    vec4 skyHor;
    vec4 sunDir;
    vec4 moonDir;
    vec4 meteorA[4];
    vec4 meteorB[4];
    vec4 meteorC[4];
} F;
layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;  // água: x,y = deslocamento da textura, z = escala, w = opacidade
    vec4 p1;  // x = altura Y da camada
} pc;
layout(location = 0) out vec3 vWorld;
void main() {
    vec3 w = inPos + vec3(0.0, pc.p1.x, 0.0);
    vWorld = w;
    gl_Position = F.viewProj * vec4(w, 1.0);
}
