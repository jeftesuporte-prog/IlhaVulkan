#version 450
// Passada de sombra das árvores instanciadas (mesmo balanço do vento, para a sombra acompanhar a copa).
layout(location = 0) in vec3 inPos;
layout(location = 4) in vec4 iPS;
layout(location = 5) in vec2 iRT;
layout(set = 0, binding = 0, std140) uniform Frame {
    mat4 viewProj;
    mat4 invViewProj;
    mat4 lightViewProj;
    vec4 camPos;
    vec4 lightDir;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 skyTop;
    vec4 skyHor;
    vec4 sunDir;
    vec4 moonDir;
    vec4 meteorA[4];
    vec4 meteorB[4];
    vec4 meteorC[4];
} F;
layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;
    vec4 p1;
} pc;
void main() {
    vec3 p = inPos * iPS.w;
    float h = max(p.y, 0.0);
    float ph = iPS.x * 0.37 + iPS.z * 0.53;
    float t = F.lightDir.w;
    p += vec3(sin(t * 1.3 + ph) + 0.4 * sin(t * 3.1 + ph * 2.0), 0.0, cos(t * 1.1 + ph * 1.7)) * 0.0035 * h * h;
    float c = cos(iRT.x), s = sin(iRT.x);
    vec3 r = vec3(c * p.x + s * p.z, p.y, -s * p.x + c * p.z);
    gl_Position = F.lightViewProj * vec4(iPS.xyz + r, 1.0);
}
