#version 450
// Passada de sombra (geometria estática): só profundidade, vista do sol/lua.
layout(location = 0) in vec3 inPos;
layout(set = 0, binding = 0, std140) uniform Frame {
    mat4 viewProj;
    mat4 invViewProj;
    mat4 lightViewProj;
    vec4 camPos;
    vec4 lightDir;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 skyTop;
    vec4 skyHor;
    vec4 sunDir;
    vec4 moonDir;
    vec4 meteorA[4];
    vec4 meteorB[4];
    vec4 meteorC[4];
} F;
layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;
    vec4 p1;
} pc;
void main() { gl_Position = F.lightViewProj * (pc.model * vec4(inPos, 1.0)); }
