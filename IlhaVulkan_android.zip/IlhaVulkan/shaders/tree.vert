#version 450
// Árvores INSTANCIADAS: 1 malha por variante, cada instância tem posição, escala, giro e tom. Balançam com o vento.

layout(location = 0) in vec3 inPos;
layout(location = 1) in vec4 inNrm;
layout(location = 2) in vec4 inCol;
layout(location = 3) in vec2 inUV;
layout(location = 4) in vec4 iPS;  // xyz = posição, w = escala
layout(location = 5) in vec2 iRT;  // x = giro (rad), y = tom

layout(set = 0, binding = 0, std140) uniform Frame {
    mat4 viewProj;
    mat4 invViewProj;
    mat4 lightViewProj;
    vec4 camPos;
    vec4 lightDir;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 skyTop;
    vec4 skyHor;
    vec4 sunDir;
    vec4 moonDir;
    vec4 meteorA[4];
    vec4 meteorB[4];
    vec4 meteorC[4];
} F;

layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;
    vec4 p1;
} pc;

layout(location = 0) out vec3 vWorld;
layout(location = 1) out vec3 vNrm;
layout(location = 2) out vec4 vCol;
layout(location = 3) out vec2 vUV;

void main() {
    vec3 p = inPos * iPS.w;
    float h = max(p.y, 0.0);
    float ph = iPS.x * 0.37 + iPS.z * 0.53;
    float t = F.lightDir.w;
    vec3 sway = vec3(sin(t * 1.3 + ph) + 0.4 * sin(t * 3.1 + ph * 2.0), 0.0, cos(t * 1.1 + ph * 1.7)) * 0.0035 * h * h;
    p += sway;
    float c = cos(iRT.x), s = sin(iRT.x);
    vec3 r = vec3(c * p.x + s * p.z, p.y, -s * p.x + c * p.z);
    vec3 n = vec3(c * inNrm.x + s * inNrm.z, inNrm.y, -s * inNrm.x + c * inNrm.z);
    vec3 w = iPS.xyz + r;
    vWorld = w;
    vNrm = n;
    vCol = vec4(inCol.rgb * iRT.y, 1.0);
    vUV = inUV;
    gl_Position = F.viewProj * vec4(w, 1.0);
}
