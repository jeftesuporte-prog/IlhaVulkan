#version 450
// Mar turquesa #00BFFF com a textura de ondas do original, iluminado como o resto do mundo,
// + brilho do sol/lua em ondulações animadas e reflexo do céu em ângulo rasante (fresnel).
layout(location = 0) in vec3 vWorld;
layout(set = 0, binding = 0, std140) uniform Frame {
    mat4 viewProj;
    mat4 invViewProj;
    mat4 lightViewProj;
    vec4 camPos;
    vec4 lightDir;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 skyTop;
    vec4 skyHor;
    vec4 sunDir;
    vec4 moonDir;
    vec4 meteorA[4];
    vec4 meteorB[4];
    vec4 meteorC[4];
} F;
layout(set = 0, binding = 3) uniform sampler2D uWater;
layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;
    vec4 p1;
} pc;
layout(location = 0) out vec4 outColor;

void main() {
    vec2 uv = vWorld.xz / 20.0 * pc.p0.z + pc.p0.xy;
    vec3 tex = texture(uWater, uv).rgb;
    float tm = F.lightDir.w;
    vec2 q = vWorld.xz;
    vec3 n = normalize(vec3(0.060 * sin(q.x * 0.55 + tm * 1.3) + 0.035 * sin(q.y * 1.10 - tm * 1.7) + 0.020 * sin((q.x + q.y) * 2.3 + tm * 2.9),
                            1.0,
                            0.060 * sin(q.y * 0.50 - tm * 1.1) + 0.035 * sin(q.x * 1.30 + tm * 1.9) + 0.020 * sin((q.x - q.y) * 2.1 - tm * 2.5)));
    vec3 V = normalize(F.camPos.xyz - vWorld);
    vec3 L = normalize(F.lightDir.xyz);

    vec3 lit = F.ambient.rgb + F.lightColor.rgb * max(L.y, 0.0);
    vec3 col = min(tex * lit, vec3(1.0));

    float fres = pow(1.0 - clamp(dot(V, n), 0.0, 1.0), 4.0);
    col = mix(col, F.skyHor.rgb, fres * 0.40);

    vec3 R = reflect(-V, n);
    float sunSpec = pow(max(dot(R, F.sunDir.xyz), 0.0), 260.0) * smoothstep(-0.02, 0.12, F.sunDir.y);
    float moonSpec = pow(max(dot(R, F.moonDir.xyz), 0.0), 260.0) * F.fogColor.w * smoothstep(0.0, 0.2, F.moonDir.y);
    col += vec3(1.0, 0.92, 0.75) * sunSpec * 0.9 + vec3(0.65, 0.75, 1.0) * moonSpec * 0.5;

    float d = length(vWorld - F.camPos.xyz);
    float fog = min(d * d / (F.ambient.w * F.ambient.w), 1.0);
    outColor = vec4(mix(col, F.fogColor.rgb, fog), pc.p0.w);
}
