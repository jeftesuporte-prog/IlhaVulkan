#version 450
layout(push_constant) uniform PC {
    mat4 model;
    vec4 p0;  // rgba
    vec4 p1;
} pc;
layout(location = 0) out vec4 outColor;
void main() { outColor = pc.p0; }
