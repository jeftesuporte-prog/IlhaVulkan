#version 450
// CÉU PROCEDURAL com as mesmas cores do original (tabela por hora vinda do CPU):
// degradê por elevação, brilho rosado do amanhecer/pôr do sol, sol com raios, lua low-poly com crateras hexagonais,
// estrelas que piscam, via láctea, estrelas cadentes e nuvens que andam com o vento.

layout(location = 0) in vec2 vNdc;

layout(set = 0, binding = 0, std140) uniform Frame {
    mat4 viewProj;
    mat4 invViewProj;
    mat4 lightViewProj;
    vec4 camPos;
    vec4 lightDir;    // w = tempo (s)
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;    // w = noite 0..1
    vec4 skyTop;      // w = elevação do sol
    vec4 skyHor;      // w = hora do dia
    vec4 sunDir;
    vec4 moonDir;
    vec4 meteorA[4];  // xyz = d0, w = velocidade
    vec4 meteorB[4];  // xyz = direção, w = idade
    vec4 meteorC[4];  // x = duração (0 = inativa)
} F;

layout(location = 0) out vec4 outColor;

const float TAU = 6.2831853;

float hash11(float n) { return fract(sin(n) * 43758.5453123); }
float hash21(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }
float hash31(vec3 p) {
    p = fract(p * 0.3183099 + 0.1);
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash21(i), b = hash21(i + vec2(1, 0)), c = hash21(i + vec2(0, 1)), d = hash21(i + vec2(1, 1));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
float fbm(vec2 p) {
    float s = 0.0, a = 0.5;
    for (int i = 0; i < 5; i++) {
        s += a * vnoise(p);
        p = p * 2.03 + vec2(17.1, 9.2);
        a *= 0.5;
    }
    return s;
}

// base tangente (direita/cima na tela) para um astro na direção m
void basis(vec3 m, out vec3 ex, out vec3 ey) {
    vec3 up = abs(m.y) < 0.99 ? vec3(0, 1, 0) : vec3(1, 0, 0);
    ex = normalize(cross(m, up));
    ey = cross(ex, m);
}

vec3 skyGradient(float e) {
    const float E[7] = float[7](0.0, 6.0, 14.0, 26.0, 42.0, 65.0, 90.0);
    vec3 hor = F.skyHor.rgb, top = F.skyTop.rgb;
    if (e <= 0.0) return hor;
    vec3 prev = hor;
    float pe = 0.0;
    for (int i = 1; i < 7; i++) {
        vec3 c = mix(hor, top, sqrt(min(E[i] / 65.0, 1.0)));
        if (e <= E[i]) return mix(prev, c, (e - pe) / (E[i] - pe));
        prev = c;
        pe = E[i];
    }
    return top;
}

vec3 starLayer(vec3 dir, vec3 col) {
    float nk = F.fogColor.w;
    if (nk < 0.01) return col;
    float hor = smoothstep(0.0, 0.18, dir.y);
    float rot = F.skyHor.w * 0.2617994;  // 1 volta por dia do jogo
    float cs = cos(rot), sn = sin(rot);
    vec3 d = vec3(dir.x * cs - dir.z * sn, dir.y, dir.x * sn + dir.z * cs);
    float t = F.lightDir.w;
    vec3 acc = vec3(0.0);
    for (int L = 0; L < 2; L++) {
        float N = (L == 0) ? 26.0 : 70.0;
        vec3 id = floor(d * N);
        vec3 f = d * N - id;
        float h = hash31(id + float(L) * 19.7);
        float present = (L == 0) ? 0.8 : 0.15;
        if (h < present) {
            vec3 sp = vec3(hash31(id + 3.1), hash31(id + 7.7), hash31(id + 11.3)) * 0.5 + 0.25;
            float dist = length(f - sp);
            float sz = (L == 0) ? (0.05 + 0.045 * hash31(id + 5.3)) : 0.085;
            float s = smoothstep(sz, 0.0, dist);
            float tw = 0.65 + 0.35 * sin(t * (0.8 + hash31(id + 1.3) * 2.6) + hash31(id + 9.9) * TAU);
            float br = 0.45 + 0.55 * hash31(id + 2.2);
            float ty = hash31(id + 4.4);
            vec3 sc = ty < 0.33 ? vec3(1.0) : (ty < 0.66 ? vec3(0.78, 0.88, 1.0) : vec3(1.0, 0.93, 0.75));
            acc += sc * s * tw * br * ((L == 0) ? 1.4 : 0.8);
        }
    }
    // via láctea: faixa difusa e fraca
    vec3 band = normalize(vec3(0.30, 0.62, -0.72));
    float bd = dot(d, band);
    float mw = exp(-pow(bd / 0.13, 2.0)) * (0.30 + 0.70 * fbm(vec2(atan(d.z, d.x) * 3.0, d.y * 9.0)));
    acc += vec3(0.55, 0.65, 1.0) * mw * 0.16;
    return col + acc * nk * hor;
}

vec3 meteorLayer(vec3 dir, vec3 col) {
    float nk = F.fogColor.w;
    if (dir.y < 0.02) return col;
    for (int m = 0; m < 4; m++) {
        float life = F.meteorC[m].x;
        if (life <= 0.0) continue;
        float age = F.meteorB[m].w, speed = F.meteorA[m].w;
        vec3 d0 = F.meteorA[m].xyz, tv = F.meteorB[m].xyz;
        float fade = sin(3.14159 * clamp(age / life, 0.0, 1.0));
        vec3 prev = vec3(0.0);
        bool have = false;
        for (int k = 0; k < 9; k++) {
            float tau = age - float(k) * 0.028;
            if (tau < 0.0) break;
            vec3 pk = d0 * cos(speed * tau) + tv * sin(speed * tau);
            if (have) {
                vec3 e = prev - pk;
                float t = clamp(dot(dir - pk, e) / max(dot(e, e), 1e-9), 0.0, 1.0);
                float dd = length(dir - (pk + e * t));
                float w = (3.6 - 0.35 * float(k)) * 0.00055;
                float a = (1.0 - float(k) / 9.0) * fade * nk * smoothstep(w, 0.0, dd);
                col = mix(col, vec3(1.0, 0.96, 0.85), clamp(a, 0.0, 1.0));
            }
            prev = pk;
            have = true;
        }
    }
    return col;
}

float hexD(vec2 q) { return max(abs(q.y), abs(q.x) * 0.866 + abs(q.y) * 0.5); }

vec3 moonLayer(vec3 dir, vec3 col) {
    float sunE = F.skyTop.w;
    float moonA = 1.0 - smoothstep(-0.25, 0.05, sunE);
    if (moonA < 0.02) return col;
    vec3 m = F.moonDir.xyz;
    if (dot(dir, m) < 0.2) return col;
    float low = 1.0 + 0.25 * (1.0 - smoothstep(0.0, 0.4, m.y));
    float r = 0.076 * low;
    vec3 ex, ey;
    basis(m, ex, ey);
    vec2 p = vec2(dot(dir, ex), dot(dir, ey)) / r;
    float rho = length(p);
    col += vec3(0.62, 0.74, 1.0) * 0.20 * moonA * exp(-pow(rho / 2.6, 2.0));  // halo azulado
    if (rho >= 1.0) return col;

    // facetas low-poly: 3 anéis, 10 setores (centro = 10 triângulos)
    float ang = atan(p.y, p.x);
    if (ang < 0.0) ang += TAU;
    int k = rho < 0.38 ? 1 : (rho < 0.72 ? 2 : 3);
    float r0 = k == 1 ? 0.0 : (k == 2 ? 0.38 : 0.72);
    float r1 = k == 1 ? 0.38 : (k == 2 ? 0.72 : 1.0);
    float off = float(k - 1) * 0.31;
    float da = TAU / 10.0;
    float a2 = ang - off;
    a2 -= TAU * floor(a2 / TAU);
    float s = floor(a2 / da);
    float ca = off + (s + 0.5) * da;
    vec2 cen = (k == 1 ? 0.67 * r1 : 0.5 * (r0 + r1)) * vec2(cos(ca), sin(ca));
    float idx = float(k) * 20.0 + s * 2.0 + ((k > 1 && fract(a2 / da) > 0.5) ? 1.0 : 0.0);
    float rho2 = min(1.0, dot(cen, cen));
    vec3 nn = normalize(vec3(cen, sqrt(1.0 - rho2)));
    float shade = 0.52 + 0.48 * max(0.0, dot(nn, vec3(-0.45, 0.55, 0.70)));
    float hv = hash11(idx);
    if (hv < 0.30) shade *= 0.80;
    else if (hv > 0.88) shade *= 1.05;
    vec3 mc = vec3(min(1.0, 0.97 * shade), min(1.0, 0.96 * shade), min(1.0, 0.88 * shade + 0.04));

    // crateras hexagonais: borda clara + fundo escuro
    const vec3 CR[5] = vec3[5](vec3(-0.30, 0.25, 0.17), vec3(0.35, -0.22, 0.21), vec3(0.12, 0.52, 0.10), vec3(-0.22, -0.42, 0.13), vec3(0.55, 0.25, 0.09));
    for (int i = 0; i < 5; i++) {
        vec2 q = (p - CR[i].xy) / CR[i].z;
        if (hexD(q) < 0.866) {
            mc = vec3(0.86, 0.85, 0.78);
            if (hexD((q - vec2(0.1, -0.1)) / 0.72) < 0.866) mc = vec3(0.55);
        }
    }
    return mix(col, mc, moonA);
}

vec3 sunLayer(vec3 dir, vec3 col) {
    float sunE = F.skyTop.w;
    if (sunE <= -0.12) return col;
    vec3 sd = F.sunDir.xyz;
    float cosA = dot(dir, sd);
    if (cosA < 0.2) return col;
    float warm = 1.0 - smoothstep(0.0, 0.4, sunE);
    float r = 0.064 * (1.0 + 0.3 * warm);
    float rho = acos(clamp(cosA, -1.0, 1.0)) / r;
    vec3 hcol = vec3(1.0, mix(0.92, 0.55, warm), mix(0.4, 0.3, warm));
    col = mix(col, hcol, 0.27 * (1.0 - smoothstep(1.0, 5.4, rho)));  // brilho no céu

    vec3 ex, ey;
    basis(sd, ex, ey);
    float phi = atan(dot(dir, ey), dot(dir, ex));
    float seg = TAU / 14.0;
    float rot = F.lightDir.w * 0.15;
    float kf = (phi - rot) / seg;
    float kk = floor(kf + 0.5);
    float delta = abs(phi - rot - kk * seg);
    float len = (mod(kk, 2.0) < 0.5) ? 2.4 : 1.8;
    float halfW = 0.09 * 1.15 / max(rho, 1.0) * (len - rho) / (len - 1.15);
    if (rho > 1.0 && rho < len && delta < halfW) col = mix(col, vec3(1.0, mix(0.84, 0.55, warm), mix(0.0, 0.1, warm)), 0.95);

    if (rho < 1.0) {
        col = vec3(1.0, mix(0.84, 0.50, warm), mix(0.0, 0.12, warm));
        if (rho < 0.72) col = vec3(1.0, mix(0.96, 0.78, warm), mix(0.55, 0.45, warm));
    }
    return col;
}

vec3 cloudLayer(vec3 dir, vec3 col) {
    const float A = 320.0;  // altura das nuvens (m)
    float t = (A - F.camPos.y) / dir.y;
    vec2 p = F.camPos.xz + dir.xz * t + vec2(1.0, 0.35) * F.lightDir.w * 6.0;  // vento
    vec2 q = p / 900.0;
    float n = fbm(q) * 0.8 + fbm(q * 3.0 + 7.0) * 0.35;
    float dens = smoothstep(0.50, 0.74, n);
    float fade = smoothstep(0.015, 0.14, dir.y);
    vec3 cc = min(vec3(1.0), F.ambient.rgb * 0.95 + F.lightColor.rgb * 0.55 + F.skyHor.rgb * 0.25);
    cc *= mix(1.0, 0.30, F.fogColor.w);
    cc *= 1.0 - 0.20 * smoothstep(0.60, 0.95, n);  // miolo mais denso = base mais escura
    float sunset = 1.0 - smoothstep(0.0, 0.35, F.skyTop.w);
    cc = mix(cc, cc * vec3(1.0, 0.74, 0.62) + F.skyHor.rgb * 0.20, sunset * 0.7);
    return mix(col, cc, dens * fade * 0.93);
}

void main() {
    vec4 w = F.invViewProj * vec4(vNdc, 1.0, 1.0);
    vec3 dir = normalize(w.xyz / w.w - F.camPos.xyz);
    float e = degrees(asin(clamp(dir.y, -1.0, 1.0)));
    vec3 col = skyGradient(e);

    // brilho rosado/laranja do amanhecer e pôr do sol, no horizonte, do lado do sol
    float glow = clamp(1.0 - abs(F.skyTop.w + 0.02) / 0.30, 0.0, 1.0);
    vec3 hd = normalize(vec3(dir.x, 0.0, dir.z) + vec3(1e-5));
    vec3 sh = normalize(vec3(F.sunDir.x, 0.0, F.sunDir.z) + vec3(1e-5));
    float facing = clamp((dot(hd, sh) + 0.3) / 1.3, 0.0, 1.0);
    col = mix(col, vec3(1.0, 0.45, 0.30), glow * facing * 0.68 * smoothstep(34.0, 0.0, e));

    if (dir.y > 0.0) {  // tudo que está no céu é cortado no horizonte: o sol/lua "afunda" no mar
        col = starLayer(dir, col);
        col = meteorLayer(dir, col);
        col = moonLayer(dir, col);
        col = sunLayer(dir, col);
        col = cloudLayer(dir, col);
    }
    outColor = vec4(col, 1.0);
}
